#!/usr/bin/env bash
set -euo pipefail
G1_LAB_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$G1_LAB_ROOT"
/usr/bin/python3 scripts/configure_local.py
G1_LAB_PYTHON="$(/usr/bin/python3 -c 'from g1_lab.common import local_settings; print(local_settings()["simulation_python"])')"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
exec "$G1_LAB_PYTHON" scripts/validate_full.py "$@"
