#!/usr/bin/env bash
set -euo pipefail
G1_LAB_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$G1_LAB_ROOT"
umask 077
G1_LAB_TERMINAL=true
G1_CHECK=false
G1_AGENT_ARGS=()
for arg in "$@"; do
  case "$arg" in
    --headless|--check|--help) G1_LAB_TERMINAL=false ;;
  esac
  case "$arg" in
    --check) G1_CHECK=true ;;
    --with-agent) G1_AGENT_ARGS=(--with-agent) ;;
    --help)
      echo '用法：bash 一键启动.sh [--check] [--with-agent] [--record-bag] [--map 地图包目录] [--no-rviz] [--headless --duration 20]'
      echo '默认：键盘建图与本地导航，不需要 OpenClaw 或 API Key。首次自动安装依赖。'
      exit 0 ;;
  esac
done
if [[ ! -t 0 && -n "${DISPLAY:-}" && "$G1_LAB_TERMINAL" == true ]]; then
  exec gnome-terminal -- bash "$G1_LAB_ROOT/一键启动.sh" "$@"
fi
trap 'echo "启动未完成。安装日志在 runs/setup，运行日志在 runs/session_*。"' ERR
/usr/bin/python3 scripts/configure_local.py
if [[ "$G1_CHECK" == true ]]; then exec /usr/bin/python3 scripts/doctor.py "${G1_AGENT_ARGS[@]}"; fi
if [[ ! -f /opt/ros/humble/setup.bash || ! -f ros_ws/install/setup.bash || ! -x .venv/bin/python ]]; then
  bash setup.sh
fi
/usr/bin/python3 scripts/doctor.py "${G1_AGENT_ARGS[@]}"
export PATH="/usr/bin:/bin:$PATH"
unset PYTHONHOME PYTHONPATH CONDA_PREFIX CONDA_DEFAULT_ENV
set +u
source /opt/ros/humble/setup.bash
source "$G1_LAB_ROOT/ros_ws/install/setup.bash"
set -u
export PYTHONPATH="$G1_LAB_ROOT:${PYTHONPATH:-}"
export ROS_LOCALHOST_ONLY=1 ROS_DOMAIN_ID="${G1_ROS_DOMAIN_ID:-73}"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONUTF8=1 PYTHONIOENCODING=utf-8
exec /usr/bin/python3 -m g1_lab.launcher "$@"
