#!/usr/bin/env bash
# Run in a normal Ubuntu terminal. Uses the official signed ROS apt repository.
set -euo pipefail
LAB_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$LAB_ROOT/runs/setup" "$LAB_ROOT/.runtime"
LOG="$LAB_ROOT/runs/setup/setup_$(date +%Y%m%d_%H%M%S).log"
exec > >(tee -a "$LOG") 2>&1
trap 'printf "\n安装未完成。日志：%s\n" "$LOG"' ERR
source /etc/os-release
if [[ "$ID" != ubuntu || "$VERSION_ID" != 22.04 ]]; then
  echo '该脚本针对 Ubuntu 22.04 / ROS 2 Humble；检测到其他系统，停止。'; exit 2
fi
echo '安装 ROS 2 Humble、RViz、SLAM Toolbox、Nav2 和编译工具。可能需要系统登录密码。'
sudo -v
sudo apt-get update
sudo apt-get install --no-remove -y curl ca-certificates software-properties-common git build-essential cmake python3-venv python3-pip
sudo add-apt-repository -y universe
if ! dpkg-query -W -f='${Status}' ros2-apt-source 2>/dev/null | grep -q 'install ok installed'; then
  curl --fail --location --retry 3 https://api.github.com/repos/ros-infrastructure/ros-apt-source/releases/latest -o "$LAB_ROOT/.runtime/ros-apt-release.json"
  ROS_SOURCE_TAG="$(/usr/bin/python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["tag_name"])' "$LAB_ROOT/.runtime/ros-apt-release.json")"
  [[ "$ROS_SOURCE_TAG" =~ ^[0-9A-Za-z._-]+$ ]] || { echo 'Unexpected release tag'; exit 2; }
  curl --fail --location --retry 3 "https://github.com/ros-infrastructure/ros-apt-source/releases/download/${ROS_SOURCE_TAG}/ros2-apt-source_${ROS_SOURCE_TAG}.jammy_all.deb" -o "$LAB_ROOT/.runtime/ros2-apt-source.deb"
  sudo dpkg -i "$LAB_ROOT/.runtime/ros2-apt-source.deb"
fi
sudo apt-get update
sudo apt-get install --no-remove -y \
  ros-humble-ros-base ros-humble-rviz2 ros-humble-slam-toolbox \
  ros-humble-navigation2 ros-humble-nav2-bringup ros-humble-nav2-simple-commander \
  ros-humble-tf2-ros ros-humble-tf2-geometry-msgs ros-humble-geometry2 \
  ros-humble-rosbag2-storage-default-plugins ros-humble-robot-state-publisher \
  ros-humble-eigen3-cmake-module ros-humble-nav2-rviz-plugins \
  python3-colcon-common-extensions python3-numpy python3-scipy python3-yaml \
  python3-pil python3-tk libeigen3-dev libboost-dev gnome-terminal fonts-noto-cjk \
  libegl1 libgl1-mesa-dri fontconfig libfontconfig1 libxft2
mkdir -p "$LAB_ROOT/ros_ws/src"
if [[ ! -d "$LAB_ROOT/ros_ws/src/rf2o_laser_odometry/.git" ]]; then
  git clone --branch ros2 --single-branch https://github.com/MAPIRlab/rf2o_laser_odometry.git "$LAB_ROOT/ros_ws/src/rf2o_laser_odometry"
  git -C "$LAB_ROOT/ros_ws/src/rf2o_laser_odometry" checkout --detach b38c68e46387b98845ecbfeb6660292f967a00d3
fi
G1_RF2O_COMMIT="$(git -C "$LAB_ROOT/ros_ws/src/rf2o_laser_odometry" rev-parse HEAD)"
if [[ "$G1_RF2O_COMMIT" != b38c68e46387b98845ecbfeb6660292f967a00d3 ]]; then
  echo '已有 RF2O 源码版本与教材不一致，停止以保护现有工作；请使用新的项目目录安装。'; exit 2
fi
/usr/bin/python3 "$LAB_ROOT/scripts/patch_rf2o.py" "$LAB_ROOT/ros_ws/src/rf2o_laser_odometry"
export PATH="/usr/bin:/bin:$PATH"
unset PYTHONHOME PYTHONPATH CONDA_PREFIX CONDA_DEFAULT_ENV
set +u
source /opt/ros/humble/setup.bash
set -u
cd "$LAB_ROOT/ros_ws"
colcon build --symlink-install --cmake-args -DCMAKE_BUILD_TYPE=Release -DPython3_EXECUTABLE=/usr/bin/python3
git -C src/rf2o_laser_odometry rev-parse HEAD > "$LAB_ROOT/.runtime/rf2o_commit.txt"
printf '{"ros":"humble","dependencies_installed":true,"full_stack_validated":false}\n' > "$LAB_ROOT/.runtime/dependencies_ready.json"
printf '\n依赖安装完成。项目：%s\n日志：%s\n若由启动器调用，将继续启动；否则运行项目中的 一键启动.sh。\n' "$LAB_ROOT" "$LOG"
