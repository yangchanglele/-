#!/usr/bin/env python3
"""Real wall-clock command expiry in the actual physics service."""
from pathlib import Path
import sys,time
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import numpy as np
from g1_lab.simulation import SimulationService
from g1_lab.common import write_json
out=ROOT/'runs/deadman_check';service=SimulationService(out,realtime=True);service.start()
try:
    time.sleep(2.3)
    deadline=time.monotonic()+1.5
    while time.monotonic()<deadline:
        write_json(out/'control.json',{'created_wall':time.time(),'velocity':[.2,0,0]});time.sleep(.05)
    with service.lock:before=float(np.linalg.norm(service.physics.command))
    # Stop renewing the command: service must expire it without ROS or a model.
    time.sleep(1.5)
    with service.lock:
        after=float(np.linalg.norm(service.physics.command));state=service.physics.state
    result={'command_before_expiry':before,'command_after_expiry':after,'physics_state':state,
            'passed':before>.1 and after<1e-8 and state=='STANDING','scope':'physics service wall-clock expiry only'}
    write_json(out/'result.json',result);print(result)
    if not result['passed']:raise SystemExit(1)
finally:service.quit.set();service.thread.join(3)
