#!/usr/bin/env python3
"""Real MuJoCo/laser checks possible before ROS installation. No API or truth odom."""
from pathlib import Path
import sys,json,math,time,csv
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import numpy as np
from g1_lab.simulation import Physics
from g1_lab.policy import yaw_of
from g1_lab.teaching import points,icp_point_to_line,compose,relative
from g1_lab.common import write_json
from g1_lab.gui import Renderer

out=ROOT/'runs/local_validation';out.mkdir(parents=True,exist_ok=True)
results=[]
for name,command in [('forward',[.2,0,0]),('backward',[-.18,0,0]),('left',[0,.18,0]),('right',[0,-.18,0]),('turn_left',[0,0,.25]),('turn_right',[0,0,-.25])]:
    sim=Physics();previous=None;estimate=np.zeros(3);velocity=None;first_truth=None
    records=[];errors=[];folder=out/name;folder.mkdir(exist_ok=True);start=time.monotonic()
    with (folder/'scans.jsonl').open('w') as stream:
        for i in range(500):
            desired=command if 100<=i<300 else [0.,0.,0.]
            sim.step(desired,velocity,estimate if previous is not None else None)
            if i%5==0:
                obs=sim.scan();stream.write(json.dumps(obs)+'\n');cloud=points(obs)
                truth=np.array([*sim.data.qpos[:2],yaw_of(sim.data.qpos[3:7])])
                if first_truth is None:first_truth=truth.copy()
                if previous is not None:
                    delta,rmse,fraction=icp_point_to_line(previous,cloud);estimate=compose(estimate,delta)
                    c=math.cos(delta[2]);s=math.sin(delta[2]);velocity=[(c*delta[0]+s*delta[1])/.1,(-s*delta[0]+c*delta[1])/.1,delta[2]/.1]
                previous=cloud;truth_relative=relative(first_truth,truth)
                errors.append(float(np.linalg.norm(estimate[:2]-truth_relative[:2])))
                records.append([obs['sim_time'],*truth_relative,*estimate])
    result={'probe':name,'physics_state':sim.state,'obstacle_contacts':sim.contacts,
            'sim_time_s':float(sim.data.time),'wall_s':time.monotonic()-start,'final_height_m':float(sim.data.qpos[2]),
            'final_truth_relative_for_evaluation':truth_relative.tolist(),'final_icp_pose':estimate.tolist(),
            'icp_position_rmse_m':float(np.sqrt(np.mean(np.square(errors)))),'icp_max_position_error_m':max(errors),
            'final_actual_speed_mps_for_evaluation':float(np.linalg.norm(sim.data.qvel[:2])),
            'estimator':'offline educational point-to-line ICP, NOT RF2O/SLAM Toolbox',
            'navigation_validated':False,'passed':sim.state!='FALLEN' and sim.contacts==0 and max(errors)<.2}
    np.savetxt(folder/'evaluation.csv',records,delimiter=',',header='t,truth_x,truth_y,truth_yaw,estimate_x,estimate_y,estimate_yaw',comments='')
    write_json(folder/'result.json',result);results.append(result)
    print(json.dumps(result,ensure_ascii=False),flush=True)
    if name=='forward':
        renderer=Renderer(sim.model,960,660)
        try:renderer.overview=True;renderer.frame(sim.data.qpos.copy()).save(out/'simulation_overview.png')
        finally:renderer.close()
write_json(out/'summary.json',{'physics_laser_probes':results,'all_passed':all(x['passed'] for x in results),
    'ROS2_SLAM_Nav2_validated':False,'OpenClaw_DeepSeek_end_to_end_validated':False,
    'note':'This report validates actual G1 dynamics and sensor observations plus a separate educational ICP; it is not evidence of ROS integration.'})
sys.exit(0 if all(x['passed'] for x in results) else 1)
