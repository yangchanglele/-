#!/usr/bin/env python3
"""Filter an actual rosbag into sensor/odometry inputs and compare loop closure.

Never replay a recorded map->odom alongside a new SLAM instance. Rebuild bag
timestamps from message simulation time, independent of recorder wall time.
"""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

def ns(t):return t.sec*1000000000+t.nanosec

def main():
    p=argparse.ArgumentParser();p.add_argument('--bag',required=True);p.add_argument('--out',required=True)
    p.add_argument('--loop',choices=['on','off'],default='on');p.add_argument('--rate',type=float,default=1.)
    p.add_argument('--domain',type=int,default=74);a=p.parse_args()
    os.environ['ROS_DOMAIN_ID']=str(a.domain);os.environ['ROS_LOCALHOST_ONLY']='1'
    import yaml
    import rosbag2_py
    import rclpy
    from rclpy.serialization import deserialize_message,serialize_message
    from rosidl_runtime_py.utilities import get_message
    from rosgraph_msgs.msg import Clock
    root=Path(__file__).resolve().parents[1];out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=False)
    input_dir=out/'filtered_input';reader=rosbag2_py.SequentialReader()
    reader.open(rosbag2_py.StorageOptions(uri=str(Path(a.bag).resolve()),storage_id='sqlite3'),rosbag2_py.ConverterOptions('cdr','cdr'))
    metadata={x.name:x for x in reader.get_all_topics_and_types()}
    allowed={'/scan','/odom','/tf','/tf_static'}
    if not {'/scan','/odom','/tf','/tf_static'}.issubset(metadata):raise ValueError('bag 缺少 scan/odom/TF 输入')
    writer=rosbag2_py.SequentialWriter();writer.open(rosbag2_py.StorageOptions(uri=str(input_dir),storage_id='sqlite3'),rosbag2_py.ConverterOptions('cdr','cdr'))
    for name in allowed:
        m=metadata[name]
        writer.create_topic(rosbag2_py.TopicMetadata(name=name,type=m.type,serialization_format='cdr',offered_qos_profiles=m.offered_qos_profiles))
    types={name:get_message(m.type) for name,m in metadata.items() if name in allowed|{'/clock'}}
    current=0;last=0;counts={k:0 for k in allowed}
    while reader.has_next():
        name,data,_=reader.read_next()
        if name not in types:continue
        msg=deserialize_message(data,types[name])
        if name=='/clock':current=ns(msg.clock);continue
        if name in ('/tf','/tf_static'):
            msg.transforms=[t for t in msg.transforms if (t.header.frame_id,t.child_frame_id) in
                [('odom','base_footprint'),('base_footprint','laser'),('base_footprint','pelvis')]]
            if not msg.transforms:continue
            when=max([ns(t.header.stamp) for t in msg.transforms]+[current if name=='/tf_static' else 0])
            data=serialize_message(msg)
        else:when=ns(msg.header.stamp)
        writer.write(name,data,when);last=max(last,when);counts[name]+=1
    del writer;del reader
    params=yaml.safe_load((root/'config/slam.yaml').read_text());params['slam_toolbox']['ros__parameters']['do_loop_closing']=a.loop=='on'
    config=out/'slam.yaml';config.write_text(yaml.safe_dump(params,sort_keys=False))
    log=(out/'slam.log').open('w');process=subprocess.Popen(['ros2','launch','slam_toolbox','online_async_launch.py',
       'use_sim_time:=true','slam_params_file:='+str(config)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    report={'loop_enabled':a.loop=='on','input_bag':str(Path(a.bag).resolve()),'input_counts':counts,
            'recorded_map_tf_removed':True,'timestamps':'message simulation time','status':'RUNNING'}
    try:
        time.sleep(2)
        subprocess.run(['ros2','bag','play',str(input_dir),'--clock','100','--rate',str(a.rate)],check=True)
        # Let the map publishing timer flush the final processed scans.
        rclpy.init();node=rclpy.create_node('g1_replay_tail_clock');publisher=node.create_publisher(Clock,'/clock',10)
        try:
            for i in range(30):
                value=last+int((i+1)*1e8);msg=Clock();msg.clock.sec=value//1000000000;msg.clock.nanosec=value%1000000000
                publisher.publish(msg);rclpy.spin_once(node,timeout_sec=.02);time.sleep(.08)
            subprocess.run(['ros2','run','nav2_map_server','map_saver_cli','-f',str(out/'map'),'--ros-args','-p','use_sim_time:=true','-p','map_subscribe_transient_local:=true'],check=True,timeout=30)
            subprocess.run(['ros2','service','call','/slam_toolbox/serialize_map','slam_toolbox/srv/SerializePoseGraph',json.dumps({'filename':str(out/'session')})],check=True,timeout=30)
        finally:node.destroy_node();rclpy.shutdown()
        if not (out/'session.posegraph').exists():raise RuntimeError('没有得到原生位姿图')
        report['status']='COMPLETED'
    except Exception as exc:report.update(status='FAILED',error=str(exc));raise
    finally:
        (out/'replay_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
        if process.poll() is None:
            os.killpg(process.pid,signal.SIGINT)
            try:process.wait(8)
            except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGTERM);process.wait(5)
        log.close()
    print('回放结果：'+str(out))

if __name__=='__main__':main()
