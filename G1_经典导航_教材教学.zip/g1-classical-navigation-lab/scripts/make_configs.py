from pathlib import Path
import yaml
ROOT=Path(__file__).resolve().parents[1]
s=yaml.safe_load((ROOT/'vendor/slam.upstream.yaml').read_text())
p=s['slam_toolbox']['ros__parameters'];p.update(use_sim_time=True,map_update_interval=1.0,
    minimum_time_interval=.1,minimum_travel_distance=.15,minimum_travel_heading=.15,
    max_laser_range=20.,resolution=.05,enable_interactive_mode=True)
(ROOT/'config/slam.yaml').write_text(yaml.safe_dump(s,sort_keys=False))
n=yaml.safe_load((ROOT/'vendor/nav2.upstream.yaml').read_text())
n['amcl']['ros__parameters'].update(robot_model_type='nav2_amcl::OmniMotionModel',
    update_min_d=.05,update_min_a=.08,transform_tolerance=.3,laser_max_range=20.,
    min_particles=400,max_particles=1500,alpha1=.1,alpha2=.1,alpha3=.1,alpha4=.1,alpha5=.1)
n['bt_navigator']['ros__parameters']['robot_base_frame']='base_footprint'
c=n['controller_server']['ros__parameters'];c.update(min_y_velocity_threshold=.001,failure_tolerance=.5)
c['progress_checker'].update(required_movement_radius=.15,movement_time_allowance=20.)
c['general_goal_checker'].update(xy_goal_tolerance=.25,yaw_goal_tolerance=.18)
c['FollowPath'].update(min_vel_x=-.2,min_vel_y=-.2,max_vel_x=.3,max_vel_y=.2,max_vel_theta=.3,
    max_speed_xy=.3,acc_lim_x=.25,acc_lim_y=.25,acc_lim_theta=.3,
    decel_lim_x=-.25,decel_lim_y=-.25,decel_lim_theta=-.3,vx_samples=11,vy_samples=7,
    vtheta_samples=11,sim_time=2.,trans_stopped_velocity=.05,
    **{'PathAlign.scale':16.,'GoalAlign.scale':12.,'RotateToGoal.scale':24.})
for k in ['local_costmap','global_costmap']:
    d=n[k][k]['ros__parameters'];d.update(robot_base_frame='base_footprint',robot_radius=.45,
        always_send_full_costmap=True,filters=['keepout_filter']+(['speed_filter'] if k=='local_costmap' else []))
    if k=='local_costmap':
        d.update(width=5,height=5,plugins=['obstacle_layer','inflation_layer'])
        d.pop('voxel_layer',None)
        d['obstacle_layer']={'plugin':'nav2_costmap_2d::ObstacleLayer','enabled':True,'observation_sources':'scan',
          'scan':{'topic':'/scan','data_type':'LaserScan','clearing':True,'marking':True,'max_obstacle_height':2.,
                  'raytrace_max_range':8.,'raytrace_min_range':.05,'obstacle_max_range':7.5,'obstacle_min_range':.05}}
    else:
        d['obstacle_layer']['scan'].update(raytrace_max_range=10.,obstacle_max_range=9.5)
    d['inflation_layer'].update(inflation_radius=.7,cost_scaling_factor=5.)
    d['keepout_filter']={'plugin':'nav2_costmap_2d::KeepoutFilter','enabled':True,'filter_info_topic':'/keepout_filter_info','transform_tolerance':.3}
    if k=='local_costmap':
        d['speed_filter']={'plugin':'nav2_costmap_2d::SpeedFilter','enabled':True,'filter_info_topic':'/speed_filter_info','speed_limit_topic':'/speed_limit','transform_tolerance':.3}
n['planner_server']['ros__parameters']['GridBased']={
    'plugin':'nav2_smac_planner/SmacPlanner2D','tolerance':.2,'allow_unknown':False,
    'downsample_costmap':False,'cost_travel_multiplier':2.,'max_planning_time':2.}
n['planner_server']['ros__parameters']['expected_planner_frequency']=2.
b=n['behavior_server']['ros__parameters'];b.update(robot_base_frame='base_footprint',max_rotational_vel=.3,min_rotational_vel=.12,rotational_acc_lim=.3)
v=n['velocity_smoother']['ros__parameters'];v.update(max_velocity=[.3,.2,.3],min_velocity=[-.2,-.2,-.3],
    max_accel=[.25,.25,.3],max_decel=[-.25,-.25,-.3],velocity_timeout=.3)
(ROOT/'config/nav2.yaml').write_text(yaml.safe_dump(n,sort_keys=False))
print('Wrote Humble SLAM and Nav2 configuration')
