#!/usr/bin/env python3
"""Read-only environment check. Agent credentials are optional for basic lessons."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from g1_lab.common import local_settings,write_json

def main():
    p=argparse.ArgumentParser();p.add_argument('--with-agent',action='store_true');args=p.parse_args()
    cfg=local_settings();checks=[]
    def add(name,ok,detail='',required=True):
        checks.append({'check':name,'ok':bool(ok),'detail':detail,'required':required})
    sim=Path(cfg['simulation_python']);add('仿真 Python',sim.is_file(),str(sim))
    if sim.is_file():
        r=subprocess.run([str(sim),'-c','import mujoco,onnx,numpy,scipy,PIL,yaml; print(mujoco.__version__)'],capture_output=True,text=True)
        add('仿真依赖',r.returncode==0,r.stdout.strip() if r.returncode==0 else r.stderr[-250:])
        r=subprocess.run([str(sim),'-m','g1_lab.tk_backend'],cwd=ROOT,capture_output=True,text=True,env={**os.environ,'PYTHONPATH':str(ROOT)})
        if r.returncode==0:
            d=json.loads(r.stdout);add('简体中文字体',d['xft_loaded'] and 'CJK SC' in d['fontconfig_family'],'系统 Tk '+d['tcl_version']+' / '+d['fontconfig_family'])
        else:add('简体中文字体',False,r.stderr.strip().splitlines()[-1] if r.stderr.strip() else '检查失败')
    add('ROS 2 Humble',Path('/opt/ros/humble/setup.bash').is_file())
    add('RF2O 工作空间',(ROOT/'ros_ws/install/setup.bash').is_file())
    add('G1 模型与策略',(ROOT/'assets/duet_policy.onnx').is_file() and (ROOT/'assets/duet_g1_23dof.xml').is_file())
    runtime=Path(cfg['openclaw_runtime'])
    add('OpenClaw（可选）',(runtime/'bin/openclaw').is_file(),required=args.with_agent)
    add('DeepSeek 插件（可选）',Path(cfg['provider_plugin']).is_dir(),required=args.with_agent)
    add('DeepSeek Key（可选）',bool(os.environ.get('DEEPSEEK_API_KEY')) or Path(cfg['key_file']).is_file(),'只检查是否存在，不显示内容',required=args.with_agent)
    ready=all(item['ok'] for item in checks if item['required'])
    for item in checks:
        label='OK' if item['ok'] else ('缺少' if item['required'] else '可跳过')
        print(label+'  '+item['check']+' '+item['detail'])
    write_json(ROOT/'runs/doctor.json',{'checks':checks,'ready':ready,'agent_enabled':args.with_agent,'full_stack_validated':False})
    if not ready:print('基础依赖运行 bash setup.sh；进阶依赖运行 bash 安装OpenClaw.sh。')
    return 0 if ready else 2

if __name__=='__main__':raise SystemExit(main())
