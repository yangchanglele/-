#!/usr/bin/env python3
"""Create the reader source ZIP after scanning its explicit file allowlist."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile
from check_release import ROOT,public_files,check

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path);args=parser.parse_args()
    version=(ROOT/'VERSION').read_text().strip();files=public_files();errors=check(files)
    if errors:raise SystemExit('发布检查失败：'+repr(errors))
    destination=args.out or ROOT/'dist'/f'g1-classical-navigation-lab-{version}.zip'
    destination=destination.resolve();destination.parent.mkdir(parents=True,exist_ok=True)
    manifest={'project':'g1-classical-navigation-lab','version':version,'format':'reader-source-release',
        'credentials_included':False,'dependencies_included':False,'ros_end_to_end_verified':False,
        'files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
    temporary=destination.with_suffix('.zip.tmp')
    with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for p in files:
            name=str(Path('g1-classical-navigation-lab')/p.relative_to(ROOT))
            info=zipfile.ZipInfo(name,date_time=(2026,11,19,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=((0o100755 if p.suffix=='.sh' else 0o100644)<<16)
            archive.writestr(info,p.read_bytes())
        archive.writestr('g1-classical-navigation-lab/RELEASE_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
    with zipfile.ZipFile(temporary) as archive:
        bad=archive.testzip()
        if bad:raise SystemExit('ZIP 校验失败：'+bad)
    temporary.replace(destination)
    digest=hashlib.sha256(destination.read_bytes()).hexdigest()
    destination.with_suffix('.zip.sha256').write_text(digest+'  '+destination.name+'\n')
    print(json.dumps({'zip':str(destination),'files':len(files)+1,'bytes':destination.stat().st_size,'sha256':digest},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
