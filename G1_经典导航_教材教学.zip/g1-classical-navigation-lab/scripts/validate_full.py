#!/usr/bin/env python3
"""Explicit regression mode: scripted teleop input, genuine ROS SLAM/Nav2.

Normal startup always leaves exploration to the user's keyboard.
"""
import argparse
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from g1_lab.common import read_json,write_json,rpc

def until(predicate,timeout,message):
    deadline=time.monotonic()+timeout
    while time.monotonic()<deadline:
        result=predicate()
        if result:return result
        time.sleep(.2)
    raise TimeoutError(message)

def main():
    p=argparse.ArgumentParser();p.add_argument('--cloud',action='store_true',help='另用 OpenClaw + 已配置 DeepSeek 通过地点别名提交并完成一次导航')
    a=p.parse_args()
    if not Path('/opt/ros/humble/setup.bash').exists() or not (ROOT/'ros_ws/install/setup.bash').exists():
        raise SystemExit('尚未安装 ROS/RF2O。先运行 scripts/install_dependencies.sh；本检查不会替换为假里程计或其他导航后端。')
    run=ROOT/'runs'/('integration_'+time.strftime('%Y%m%d_%H%M%S'));run.mkdir(parents=True)
    log=(run/'launcher.log').open('w');started=time.time();session=None
    process=subprocess.Popen(['bash',str(ROOT/'一键启动.sh'),'--headless','--no-rviz','--offline-agent','--record-bag','--duration','900'],
                             cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
    result={'status':'RUNNING','steps':[],'cloud_requested':a.cloud,'scripted_input_only_for_regression':True}
    try:
        def find_session():
            data=read_json(ROOT/'runs/latest.json',{});path=Path(data.get('session','/nonexistent'))
            if process.poll() is not None:raise RuntimeError('启动器退出，见 '+str(run/'launcher.log'))
            return path if path.exists() and path.stat().st_mtime>=started-1 else None
        session=until(find_session,45,'未创建会话')
        def state():return read_json(session/'status.json',{})
        until(lambda:state().get('pose_fresh') and state().get('odometry_fresh'),75,'SLAM 位姿或里程计未就绪')
        origin=list(state()['estimated_pose']);result['steps'].append({'step':'slam_started','initial_estimated_pose':origin})
        move_start=time.monotonic()
        while time.monotonic()-move_start<30:
            s=state()
            if s.get('physics_state')=='FALLEN':raise RuntimeError('回归驾驶时跌倒')
            if s.get('estimated_pose') and math.dist(origin[:2],s['estimated_pose'][:2])>=1.5:break
            write_json(session/'teleop.json',{'created_wall':time.time(),'active':True,'velocity':[.18,0,0]})
            time.sleep(.05)
        write_json(session/'teleop.json',{'created_wall':time.time(),'active':False,'velocity':[0,0,0]})
        write_json(session/'stop.json',{'created_wall':time.time()});time.sleep(3)
        if math.dist(origin[:2],state()['estimated_pose'][:2])<.8:raise RuntimeError('未确认实际移动')
        saved=rpc(session,'map_freeze_save',{'name':'validation_'+time.strftime('%Y%m%d_%H%M%S')},timeout=65)
        result['steps'].append({'step':'map_saved','bundle':saved['bundle']})
        loaded=rpc(session,'map_load',{'bundle':saved['bundle']},timeout=110)
        result['steps'].append({'step':'amcl_nav2_loaded','status':loaded['status']})
        capture=rpc(session,'pose_capture',{})
        end=rpc(session,'semantic_add_place',{'name':'验证终点','aliases':['目标站'],'snapshot_id':capture['snapshot_id']})
        selection=rpc(session,'selection_set',{'kind':'pose','coordinates':origin})
        home=rpc(session,'semantic_add_place',{'name':'验证起点','selection_id':selection['selection_id']})
        result['steps'].append({'step':'semantic_places_saved','ids':[home['id'],end['id']]})
        topology=rpc(session,'semantic_connect',{'from_id':end['id'],'to_id':home['id']})
        result['steps'].append({'step':'topology_verified','path_length_m':topology['length_m']})
        task=rpc(session,'mission_submit',{'goal_ids':[home['id']],'request_id':'integration_return_home'})
        def completed():
            data=read_json(session/'tasks'/(task['task_id']+'.json'))
            return data if data and data.get('status') in ('SUCCEEDED','FAILED','CANCELLED') else None
        finished=until(completed,260,'导航任务未在期限内结束');result['steps'].append({'step':'navigation','result':finished})
        if finished['status']!='SUCCEEDED':raise RuntimeError('导航未成功：'+finished.get('reason',''))
        if state().get('obstacle_contact_count',0):raise RuntimeError('检测到物理障碍接触，不能判为导航通过')
        if a.cloud:
            env={**os.environ,'PYTHONPATH':str(ROOT)}
            cloud_start=time.time()
            cloud=subprocess.run([sys.executable,'-m','g1_lab.console','--session',str(session),'--message','请使用地图查询和导航工具，前往地图中的“目标站”。只提交一次任务，提交后告知状态，不要只描述操作。'],
                                 cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=200)
            # Console already redacts credentials before emitting diagnostics.
            (run/'cloud.log').write_text(cloud.stdout+'\n'+cloud.stderr)
            if cloud.returncode:raise RuntimeError('OpenClaw/DeepSeek 检查未通过，见 cloud.log')
            calls=[]
            for audit in (session/'agent_turns').glob('*/tool_calls.jsonl'):
                if audit.stat().st_mtime<cloud_start-1:continue
                for line in audit.read_text().splitlines():
                    item=json.loads(line)
                    if item.get('operation')=='mission_submit' and item.get('response',{}).get('ok'):calls.append(item)
            if len(calls)!=1:raise RuntimeError('没有取得恰好一次成功导航工具提交的证据')
            cloud_task=calls[0]['response']['result']
            if cloud_task['goal_ids']!=[end['id']]:raise RuntimeError('语言别名没有解析到正确地点')
            cloud_result=until(lambda:read_json(session/'tasks'/(cloud_task['task_id']+'.json')),260,'云端提交的任务未完成')
            if cloud_result['status']!='SUCCEEDED':raise RuntimeError('云端提交的导航未成功：'+cloud_result.get('reason',''))
            result['steps'].append({'step':'OpenClaw_DeepSeek_semantic_navigation','passed':True,'result':cloud_result})
        result['status']='PASSED'
    except Exception as exc:
        result.update(status='FAILED',error=str(exc));raise
    finally:
        result['session']=str(session) if session else None;result['elapsed_wall_s']=time.time()-started
        write_json(run/'result.json',result)
        if session:write_json(session/'stop.json',{'created_wall':time.time()})
        if process.poll() is None:
            os.killpg(process.pid,signal.SIGINT)
            try:process.wait(timeout=50)
            except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
        log.close();print('完整检查报告：'+str(run/'result.json'))

if __name__=='__main__':main()
