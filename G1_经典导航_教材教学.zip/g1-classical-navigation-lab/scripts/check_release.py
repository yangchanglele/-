#!/usr/bin/env python3
"""Inspect the exact public file set, or Git's tracked file set, before release."""
import argparse
import ast
import json
from pathlib import Path
import re
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[1]
FOLDERS=('assets','g1_lab','scripts','openclaw_plugin','tests','docs','vendor','examples','.github')
SINGLES=('README.md','LICENSE','VERSION','requirements.txt','.gitignore','.gitattributes',
         'CONTRIBUTING.md','CHANGELOG.md','使用指南.html','setup.sh','一键启动.sh','一键验证.sh','实验回放.sh','安装OpenClaw.sh',
         'config/local.example.json','config/runtime_versions.json','config/slam.yaml','config/nav2.yaml','config/lab.rviz')
PRIVATE_PARTS={'.git','.venv','.runtime','.openclaw-state','ros_ws','runs','maps','dist','__pycache__','.pytest_cache','node_modules'}
SECRET=re.compile(rb'\bsk-[A-Za-z0-9_-]{20,}|\bgh[pousr]_[A-Za-z0-9]{30,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')
PERSONAL=re.compile(rb'/(?:home|Users)/[A-Za-z0-9_.-]+/')

def forbidden(relative):
    p=Path(relative)
    return any(x in PRIVATE_PARTS for x in p.parts) or p.suffix in ('.key','.pyc','.pyo') or p.name=='.env' or p.name.startswith('.env.') or str(p)=='config/local.json' or p.name.startswith('openclaw.') and p.suffix=='.json' and p.parent.name=='config'

def inspect_bytes(relative,data):
    errors=[]
    if SECRET.search(data):errors.append('credential-like bytes')
    if PERSONAL.search(data):errors.append('personal absolute home path')
    if forbidden(relative):errors.append('private/runtime file')
    return errors

def public_files(root=ROOT):
    files=[root/name for name in SINGLES]
    for folder in FOLDERS:
        files.extend(p for p in (root/folder).rglob('*') if p.is_file() and not forbidden(p.relative_to(root)))
    return sorted(set(files))

def check(files,root=ROOT):
    failures=[]
    for p in files:
        rel=str(p.relative_to(root))
        if not p.is_file():failures.append((rel,'missing required file'));continue
        if p.is_symlink():failures.append((rel,'symlink'));continue
        data=p.read_bytes()
        failures.extend((rel,msg) for msg in inspect_bytes(rel,data))
        if p.suffix=='.py':
            try:ast.parse(data.decode('utf-8'),filename=rel)
            except (SyntaxError,UnicodeError):failures.append((rel,'Python syntax/encoding'))
    return failures

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--tracked',action='store_true');args=parser.parse_args()
    if args.tracked:
        result=subprocess.run(['git','ls-files','-z'],cwd=ROOT,capture_output=True,check=True)
        files=[ROOT/p for p in result.stdout.decode().split('\0') if p]
        if not files:raise SystemExit('Git 尚未跟踪文件。先检查工作区，再添加待发布源码。')
    else:files=public_files()
    errors=check(files)
    if errors:
        for path,reason in errors:print(path+': '+reason)
        raise SystemExit('发布检查失败；不输出可能涉及的密钥内容。')
    print(json.dumps({'files_checked':len(files),'private_material_found':False,'syntax_checked':True},ensure_ascii=False))

if __name__=='__main__':main()
