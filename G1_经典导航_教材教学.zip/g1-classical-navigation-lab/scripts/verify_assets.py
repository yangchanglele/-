#!/usr/bin/env python3
"""Verify the distributed pretrained policy, model and mesh bytes."""
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def verify():
    data=json.loads((ROOT/'assets/manifest.json').read_text());bad=[]
    for item in data['files']:
        p=ROOT/item['path']
        if not p.is_file() or len(p.read_bytes())!=item['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:
            bad.append(item['path'])
    if bad:raise RuntimeError('模型/策略文件校验失败：'+', '.join(bad))
    return len(data['files'])

if __name__=='__main__':print('模型、策略与网格文件 SHA256 校验通过：'+str(verify())+' 个文件')
