#!/usr/bin/env python3
"""Install optional pinned CLI/provider privately. Makes no model API requests."""
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from g1_lab.common import local_settings,redact,write_json
from g1_lab.console import configure

def main():
    os.umask(0o077)
    subprocess.run(['/usr/bin/python3',str(ROOT/'scripts/configure_local.py')],check=True)
    cfg=local_settings();versions=json.loads((ROOT/'config/runtime_versions.json').read_text())
    runtime=Path(cfg['openclaw_runtime']);state=ROOT/'.openclaw-state';state.mkdir(exist_ok=True)
    downloads=ROOT/'.runtime/downloads';downloads.mkdir(parents=True,exist_ok=True)
    logs=ROOT/'runs/setup';logs.mkdir(parents=True,exist_ok=True)
    logfile=logs/('openclaw_'+time.strftime('%Y%m%d_%H%M%S')+'.log')
    bootstrap=ROOT/'config/openclaw.bootstrap.json';write_json(bootstrap,{'plugins':{'slots':{'memory':'none'}}})
    env={**os.environ,'OPENCLAW_STATE_DIR':str(state),'OPENCLAW_CONFIG_PATH':str(bootstrap),
         'PATH':str(runtime/'bin')+':'+str(runtime/'tools/node/bin')+':'+os.environ.get('PATH','')}
    env.pop('DEEPSEEK_API_KEY',None)
    binary=runtime/'bin/openclaw'
    with logfile.open('w',buffering=1) as log:
        def run(command):
            process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,errors='replace')
            for line in process.stdout:
                line=redact(line.rstrip());print(line,flush=True);log.write(line+'\n')
            if process.wait():raise RuntimeError('安装命令失败，检查 '+str(logfile))
        installed=''
        if binary.is_file():
            probe=subprocess.run([str(binary),'--version'],env=env,capture_output=True,text=True,timeout=45)
            if probe.returncode==0:installed=probe.stdout
        if not re.search(r'(?<!\d)'+re.escape(versions['openclaw'])+r'(?![\d.-])',installed):
            installer=downloads/'install-cli.sh'
            run(['curl','--fail','--show-error','--location','--proto','=https','--tlsv1.2','--retry','2',
                 'https://openclaw.ai/install-cli.sh','--output',str(installer)])
            run(['bash',str(installer),'--prefix',str(runtime),'--version',versions['openclaw'],
                 '--node-version',versions['node'],'--npm','--runtime-only','--no-onboard'])
        run([str(binary),'--version'])
        provider=Path(cfg['provider_plugin']);metadata=provider/'package.json'
        provider_version=json.loads(metadata.read_text()).get('version') if metadata.is_file() else None
        if provider_version!=versions['deepseek_provider']:
            if provider.exists():raise RuntimeError('已有 DeepSeek 插件版本不同。请保留原目录，使用新的项目副本安装固定版本。')
            run([str(binary),'plugins','install','@openclaw/deepseek-provider@'+versions['deepseek_provider']])
        generated,_,_=configure();env['OPENCLAW_CONFIG_PATH']=str(generated)
        result=subprocess.run([str(binary),'plugins','list','--json'],cwd=ROOT,env=env,capture_output=True,text=True,timeout=60)
        if result.returncode:raise RuntimeError('插件加载检查失败：'+redact(result.stderr[-1200:]))
        data=json.loads(result.stdout)
        selected=[{k:p.get(k) for k in ('id','version','status','toolNames','providerIds')} for p in data['plugins'] if p['id'] in ('g1-slam','deepseek')]
        if len(selected)!=2 or any(p['status']!='loaded' for p in selected):raise RuntimeError('未成功加载两个必需插件')
        write_json(ROOT/'runs/openclaw_install.json',{'plugins':selected,'cloud_api_called':False})
    print('OpenClaw 及插件已安装；未调用云模型。')
    print('下一步：python3 scripts/configure_local.py --key，然后 bash 一键启动.sh --with-agent')
    print('日志：'+str(logfile))

if __name__=='__main__':main()
