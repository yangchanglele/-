#!/usr/bin/env python3
"""Create portable reader settings; credentials are always user supplied."""
import argparse
import getpass
import json
import os
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def main():
    parser=argparse.ArgumentParser(description='创建本机配置；默认不要求 API Key')
    parser.add_argument('--key',action='store_true',help='交互输入自己的 DeepSeek Key，不回显')
    parser.add_argument('--model',help='例如 deepseek/deepseek-flash')
    args=parser.parse_args();target=ROOT/'config/local.json'
    cfg=json.loads(target.read_text()) if target.exists() else json.loads((ROOT/'config/local.example.json').read_text())
    if args.model:cfg['model']=args.model
    os.umask(0o077)
    target.write_text(json.dumps(cfg,ensure_ascii=False,indent=2)+'\n');target.chmod(0o600)
    if args.key:
        value=getpass.getpass('输入你自己的 DeepSeek API Key（不回显）：').strip()
        if not value:raise SystemExit('输入为空，原密钥保持不变。')
        path=Path(cfg['key_file']).expanduser()
        if not path.is_absolute():path=ROOT/path
        path.parent.mkdir(parents=True,exist_ok=True)
        if path.exists():path.chmod(0o600)
        with os.fdopen(os.open(path,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600),'w') as f:f.write(value+'\n')
        print('密钥已保存到被 Git 忽略的本地文件。')
    print('本机配置：config/local.json；基础实验不需要密钥。')

if __name__=='__main__':main()
