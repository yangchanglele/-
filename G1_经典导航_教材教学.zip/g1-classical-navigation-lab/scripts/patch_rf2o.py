"""Small, documented fixes to the author's ROS 2 branch, applied idempotently."""
from pathlib import Path
import sys
p=Path(sys.argv[1])/'src/CLaserOdometry2DNode.cpp'
s=p.read_text();changes=[]
old='initial_robot_pose.pose.pose.orientation.w = 0;'
if old in s:
    s=s.replace(old,'initial_robot_pose.pose.pose.orientation.w = 1; // G1 lab: valid identity quaternion')
    changes.append('Use identity quaternion instead of zero quaternion for zero-pose initialization')
old='      setLaserPoseFromTf();'
if old in s:
    s=s.replace(old,'      if (!setLaserPoseFromTf()) return; // G1 lab: retry until static TF arrives')
    changes.append('Wait for a valid laser extrinsic before initializing RF2O')
if 'new_scan_available = false; // G1 lab init' not in s:
    anchor='  rf2o_ref.first_laser_scan   = true;'
    if anchor in s:
        s=s.replace(anchor,anchor+'\n  new_scan_available = false; // G1 lab init')
        changes.append('Initialize pending-scan flag')
p.write_text(s)
cmake=Path(sys.argv[1])/'CMakeLists.txt';text=cmake.read_text()
if '# G1 lab: propagate Eigen include directories' not in text:
    text=text.replace('ament_package()',
        '# G1 lab: propagate Eigen include directories\n'
        'target_link_libraries(${EXECUTABLE_NAME} Eigen3::Eigen)\n'
        'target_link_libraries(${PROJECT_NAME} Eigen3::Eigen)\n\nament_package()')
    cmake.write_text(text);changes.append('Propagate Eigen3 include directories to both build targets')
for x in changes:print('RF2O patch:',x)
