#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
import sys
import math
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import numpy as np
from g1_lab.teaching import points,icp,icp_point_to_line,compose,OccupancyBuilder,optimize_pose_graph,relative
from g1_lab.common import write_json

p=argparse.ArgumentParser(description='离线 ICP / 栅格更新 / 小型位姿图实验；不替代 RF2O 和 SLAM Toolbox')
p.add_argument('experiment',choices=['occupancy','pose_graph']);p.add_argument('--scans');p.add_argument('--out',default=str(ROOT/'runs/teaching'))
p.add_argument('--resolution',type=float,default=.1);p.add_argument('--matcher',choices=['point','line'],default='line');args=p.parse_args();out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
if args.experiment=='occupancy':
    if not args.scans:p.error('occupancy 需要 --scans 指向一次会话的 scans.jsonl')
    previous=None;pose=np.zeros(3);records=[];builder=OccupancyBuilder(args.resolution,width=int(24/args.resolution),height=int(24/args.resolution))
    for line in Path(args.scans).read_text().splitlines():
        scan=json.loads(line);cloud=points(scan);rmse=0.
        if previous is not None:
            delta,rmse,fraction=(icp if args.matcher=='point' else icp_point_to_line)(previous,cloud);pose=compose(pose,delta)
        previous=cloud;builder.update(scan,pose);records.append([scan['sim_time'],*pose,rmse])
    builder.result().save(out/'occupancy');np.savetxt(out/'icp_trajectory.csv',records,delimiter=',',header='t,x,y,yaw,rmse',comments='')
    write_json(out/'result.json',{'algorithm':'offline '+args.matcher+' ICP + log-odds grid','not_rf2o':True,'not_production_slam':True,
               'input_scans':len(records),'resolution':args.resolution,'final_estimated_pose':pose.tolist()})
else:
    ideal=np.array([[0,0,0],[2,0,math.pi/2],[2,2,math.pi],[0,2,-math.pi/2],[0,0,0]],float)
    initial=ideal.copy();initial[:,0]+=np.arange(5)*.1;initial[:,1]+=np.arange(5)*.04
    edges=[(i,i+1,relative(initial[i],initial[i+1]),[.1,.1,.05]) for i in range(4)]
    edges.append((0,4,[0.,0.,0.],[.02,.02,.02]))
    optimized,result=optimize_pose_graph(initial,edges)
    write_json(out/'pose_graph.json',{'educational_synthetic_example':True,'initial':initial.tolist(),'optimized':optimized.tolist(),'metrics':result})
print('实验产物：'+str(out))
