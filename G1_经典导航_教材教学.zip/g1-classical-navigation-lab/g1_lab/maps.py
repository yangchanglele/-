"""Geometry, human semantics and rule maps. Has no simulation/ground-truth import."""
from copy import deepcopy
import hashlib
import heapq
import json
import math
from pathlib import Path
import time
import uuid

import numpy as np
from scipy.ndimage import distance_transform_edt, binary_dilation
from PIL import Image
import yaml
from .common import write_json, read_json, safe_id, finite


class Grid:
    def __init__(self, data, resolution, origin):
        self.data=np.asarray(data,dtype=np.int16)
        if self.data.ndim!=2:raise ValueError('地图必须是二维数组')
        if np.any((self.data < -1) | (self.data > 100)):raise ValueError('占据值超出 -1..100')
        self.resolution=finite(float(resolution),.005,1.)
        self.origin=[float(v) for v in origin]
        if len(self.origin)!=3 or not np.isfinite(self.origin).all():raise ValueError('地图原点无效')
        self.h,self.w=self.data.shape

    def cell(self, x, y):
        dx=x-self.origin[0];dy=y-self.origin[1];c=math.cos(self.origin[2]);s=math.sin(self.origin[2])
        return int(math.floor((c*dx+s*dy)/self.resolution)),int(math.floor((-s*dx+c*dy)/self.resolution))

    def world(self, ix, iy):
        a=(np.asarray(ix)+.5)*self.resolution;b=(np.asarray(iy)+.5)*self.resolution
        c=math.cos(self.origin[2]);s=math.sin(self.origin[2])
        return self.origin[0]+c*a-s*b,self.origin[1]+s*a+c*b

    def clearance(self):
        # Outside the finite grid and unknown cells are not known traversable.
        free=(self.data>=0)&(self.data<25)
        padded=np.pad(free,1,constant_values=False)
        return distance_transform_edt(padded)[1:-1,1:-1]*self.resolution

    def free(self, pose, radius=.45):
        ix,iy=self.cell(float(pose[0]),float(pose[1]))
        return 0<=ix<self.w and 0<=iy<self.h and self.clearance()[iy,ix]>=radius

    def polygon(self, vertices):
        if not isinstance(vertices,list) or not 3<=len(vertices)<=100:raise ValueError('多边形需要 3–100 个点')
        vs=np.asarray(vertices,dtype=float)
        if vs.shape!=(len(vertices),2) or not np.isfinite(vs).all():raise ValueError('多边形坐标无效')
        if abs(np.sum(vs[:,0]*np.roll(vs[:,1],-1)-np.roll(vs[:,0],-1)*vs[:,1]))<self.resolution**2:
            raise ValueError('多边形面积过小')
        yy,xx=np.indices(self.data.shape);x,y=self.world(xx,yy);inside=np.zeros_like(x,dtype=bool)
        for p,q in zip(vs,np.roll(vs,-1,axis=0)):
            if p[1]==q[1]:continue
            crossed=((p[1]>y)!=(q[1]>y)) & (x<(q[0]-p[0])*(y-p[1])/(q[1]-p[1])+p[0])
            inside ^= crossed
        if not inside.any():raise ValueError('区域在地图之外或太小')
        return inside

    def save(self, folder):
        folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
        np.save(folder/'occupancy.npy',self.data)
        pixels=np.full(self.data.shape,205,np.uint8)
        pixels[(self.data>=0)&(self.data<25)]=254;pixels[self.data>=65]=0
        Image.fromarray(np.flipud(pixels)).save(folder/'map.pgm')
        config={'image':'map.pgm','mode':'trinary','resolution':self.resolution,'origin':self.origin,
                'negate':0,'occupied_thresh':.65,'free_thresh':.196}
        (folder/'map.yaml').write_text(yaml.safe_dump(config,sort_keys=False))

    @classmethod
    def load(cls, folder):
        p=Path(folder);cfg=yaml.safe_load((p/'map.yaml').read_text())
        return cls(np.load(p/'occupancy.npy'),cfg['resolution'],cfg['origin'])

    def digest(self):
        h=hashlib.sha256(self.data.astype('<i2').tobytes())
        h.update(json.dumps([self.resolution,self.origin],separators=(',',':')).encode())
        return h.hexdigest()


class MapStore:
    def __init__(self, root):
        self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True)
        self.bundle=None;self.grid=None;self.manifest=None;self.document=None

    def create(self, name, grid):
        safe_id(name);base=self.root/name;base.mkdir(exist_ok=True)
        revisions=[int(p.name[4:]) for p in base.glob('rev_*') if p.name[4:].isdigit()]
        rev=max(revisions,default=0)+1
        bundle=base/f'rev_{rev:03d}'
        bundle.mkdir();grid.save(bundle/'occupancy')
        manifest={'schema_version':1,'map_id':name,'geometry_revision':rev,'geometry_hash':grid.digest(),
                  'created_wall':time.time(),'frame_id':'map','geometry_source':'slam_toolbox',
                  'complete':False,'semantic_revision':0,'rules_revision':0}
        manifest['file_hashes']={str(p.relative_to(bundle)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (bundle/'occupancy').iterdir()}
        write_json(bundle/'manifest.json',manifest)
        document={'places':[],'regions':[],'objects':[],'relations':[],'topology':{'nodes':[],'edges':[]}}
        write_json(bundle/'semantic.json',document)
        return bundle

    def activate(self, bundle):
        p=Path(bundle).resolve();p.relative_to(self.root.resolve())
        manifest=read_json(p/'manifest.json')
        if not manifest or not manifest.get('complete'):raise ValueError('地图包未完成保存')
        for name,expected in manifest.get('file_hashes',{}).items():
            file=(p/name).resolve();file.relative_to(p)
            if not file.is_file() or hashlib.sha256(file.read_bytes()).hexdigest()!=expected:raise ValueError('地图文件 hash 不一致：'+name)
        grid=Grid.load(p/'occupancy')
        if grid.digest()!=manifest['geometry_hash']:raise ValueError('地图 hash 不一致')
        self.bundle=p;self.grid=grid;self.manifest=manifest;self.document=read_json(p/'semantic.json')
        self.masks();return deepcopy(manifest)

    def versions(self):
        if not self.manifest:return None
        return {k:self.manifest[k] for k in ('map_id','geometry_revision','geometry_hash','semantic_revision','rules_revision')}

    def require(self, expected=None):
        if self.grid is None:raise ValueError('请先保存并加载一张地图')
        if expected:
            for k,v in expected.items():
                if k not in self.versions() or self.manifest[k]!=v:raise ValueError('STALE_MAP_VERSION：地图版本已经变化')

    def persist(self, rules=False):
        self.manifest['semantic_revision']+=1
        if rules:
            self.manifest['rules_revision']+=1
            for edge in self.document['topology']['edges']:edge['status']='pending_revalidation'
        write_json(self.bundle/'semantic.json',self.document);write_json(self.bundle/'manifest.json',self.manifest)
        self.masks(save=True)

    def add_place(self, name, aliases, pose, snapshot_id, expected=None):
        self.require(expected)
        if not isinstance(name,str) or not 1<=len(name.strip())<=80:raise ValueError('地点名称长度需要 1–80')
        if not isinstance(aliases,list) or len(aliases)>20 or any(not isinstance(a,str) or len(a)>80 for a in aliases):raise ValueError('别名格式无效')
        if self.query(name):raise ValueError('已有相同名称或别名；请用不同名称')
        if len(pose)!=3 or not all(math.isfinite(v) for v in pose):raise ValueError('位姿无效')
        if not self.grid.free(pose):raise ValueError('目标处的已知空闲空间不足以容纳机器人')
        ix,iy=self.grid.cell(*pose[:2]);keep,_=self.masks()
        if keep[iy,ix]:raise ValueError('目标落在禁行区或其身体缓冲区')
        item={'id':uuid.uuid4().hex[:12],'name':name.strip(),'aliases':aliases,'kind':'waypoint',
              'approach_pose':list(pose),'snapshot_id':snapshot_id,'source':'human_annotation',
              'geometry_revision':self.manifest['geometry_revision']}
        self.document['places'].append(item);self.document['topology']['nodes'].append(item['id']);self.persist()
        return deepcopy(item)

    def query(self, query=''):
        if not self.document:return []
        q=query.strip().casefold()
        return [deepcopy(p) for p in self.document['places'] if not q or q in [str(p['id']).casefold(),p['name'].casefold(),*[a.casefold() for a in p['aliases']]]]

    def resolve(self, identifier):
        items=self.query(identifier)
        if len(items)!=1:raise ValueError('UNKNOWN_OR_AMBIGUOUS_PLACE：未知地点或名称有歧义')
        return items[0]

    def region(self, name, kind, vertices, speed=None):
        self.require()
        if kind not in ('room','keepout','speed_limit'):raise ValueError('区域类型不支持')
        if not isinstance(name,str) or not 1<=len(name)<=80:raise ValueError('区域名称无效')
        self.grid.polygon(vertices)
        item={'id':uuid.uuid4().hex[:12],'name':name,'kind':kind,'polygon':vertices}
        if kind=='speed_limit':item['max_linear_mps']=finite(speed,.1,.3)
        self.document['regions'].append(item);self.persist(rules=kind!='room');return item

    def remove(self, identifier):
        self.require();changed=False;rule=False
        for group in ('places','regions','objects'):
            for item in list(self.document[group]):
                if item['id']==identifier:
                    rule |= item.get('kind') in ('keepout','speed_limit');self.document[group].remove(item);changed=True
        if not changed:raise ValueError('找不到实体 ID')
        self.document['topology']['nodes']=[x for x in self.document['topology']['nodes'] if x!=identifier]
        self.document['topology']['edges']=[x for x in self.document['topology']['edges'] if identifier not in (x['from'],x['to'])]
        self.document['relations']=[r for r in self.document['relations'] if identifier not in (r.get('subject'),r.get('object'))]
        for obj in self.document['objects']:
            if obj.get('approach_place_id')==identifier:obj['approach_place_id']=None
        self.persist(rules=rule)

    def add_object(self,name,position,approach_place_id,room_id=None):
        self.require();approach=self.resolve(approach_place_id)
        if not isinstance(name,str) or not 1<=len(name)<=80:raise ValueError('对象名称无效')
        if room_id and not any(r['id']==room_id and r['kind']=='room' for r in self.document['regions']):raise ValueError('未知房间 ID')
        obj={'id':uuid.uuid4().hex[:12],'name':name,'position':list(position[:2]),
             'approach_place_id':approach['id'],'room_id':room_id,'source':'human_annotation'}
        self.document['objects'].append(obj)
        if room_id:self.document['relations'].append({'subject':obj['id'],'predicate':'inside','object':room_id})
        self.persist();return deepcopy(obj)

    def connect(self, a,b,path):
        pa=self.resolve(a);pb=self.resolve(b)
        if len(path)<2:raise ValueError('规划路径为空')
        edge={'from':pa['id'],'to':pb['id'],'bidirectional':False,'path':path,
              'length_m':sum(math.dist(x,y) for x,y in zip(path,path[1:])),
              'status':'validated','validated_versions':self.versions()}
        self.document['topology']['edges'].append(edge);self.persist();return deepcopy(edge)

    def masks(self,save=False):
        if self.grid is None:return None,None
        keep=np.zeros(self.grid.data.shape,dtype=np.uint8);speed=keep.copy()
        for r in self.document['regions']:
            if r['kind']=='room':continue
            mask=self.grid.polygon(r['polygon'])
            if r['kind']=='keepout':keep[mask]=100
            else:
                value=int(round(100*r['max_linear_mps']))
                speed[mask]=np.where(speed[mask]==0,value,np.minimum(speed[mask],value))
        # Costmap filters run after normal inflation: expand the mask here.
        if keep.any():keep=(distance_transform_edt(keep==0)*self.grid.resolution<=.45).astype(np.uint8)*100
        if save:
            folder=self.bundle/'rules';folder.mkdir(exist_ok=True)
            np.save(folder/'keepout.npy',keep);np.save(folder/'speed.npy',speed)
            Image.fromarray(np.flipud(255-keep*2)).save(folder/'keepout_preview.png')
            Image.fromarray(np.flipud(255-speed*5)).save(folder/'speed_preview.png')
            write_json(folder/'encoding.json',{'frame_id':'map','resolution':self.grid.resolution,'origin':self.grid.origin,
                       'keepout':'OccupancyGrid 0/100; already expanded by 0.45 m',
                       'speed':'OccupancyGrid 0=no extra limit; value * 0.01 m/s; FilterInfo type=2',
                       'preview_images':'display only; runtime publishes masks from semantic polygons'})
        return keep,speed


def astar(grid,start,goal,radius=.45,blocked=None):
    """Small teaching/reference planner, not the ROS Nav2 execution backend."""
    free=grid.clearance()>=radius
    if blocked is not None:free &= np.asarray(blocked)==0
    a=grid.cell(*start);b=grid.cell(*goal)
    def valid(p):return 0<=p[0]<grid.w and 0<=p[1]<grid.h and free[p[1],p[0]]
    if not valid(a) or not valid(b):raise ValueError('起点或终点不可通行')
    heap=[(0.,a)];cost={a:0.};parent={}
    while heap:
        _,p=heapq.heappop(heap)
        if p==b:
            result=[p]
            while p!=a:p=parent[p];result.append(p)
            return [list(map(float,grid.world(*x))) for x in result[::-1]]
        for dx,dy in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)):
            q=(p[0]+dx,p[1]+dy)
            if not valid(q) or (dx and dy and (not valid((p[0]+dx,p[1])) or not valid((p[0],p[1]+dy)))):continue
            new=cost[p]+math.hypot(dx,dy)
            if new<cost.get(q,float('inf')):
                cost[q]=new;parent[q]=p;heapq.heappush(heap,(new+math.dist(q,b),q))
    raise ValueError('NO_PATH')
