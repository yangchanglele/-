"""Terminal conversation using the installed OpenClaw + DeepSeek provider."""
import argparse
import json
import os
from pathlib import Path
import queue
import signal
import subprocess
import threading
import time
import uuid

from .common import ROOT,read_json,write_json,key,redact,rpc,local_settings

TOOLS=['mapping_status','map_list','map_freeze_save','map_load','pose_capture','semantic_query','semantic_add_place',
       'semantic_set_region','semantic_connect','semantic_remove','semantic_add_object','mapping_resume','mission_submit','mission_status','mission_cancel']

def configure():
    settings=local_settings()
    model=settings.get('model','deepseek/deepseek-flash')
    config={'agents':{'defaults':{'model':{'primary':model}}},'tools':{'profile':'full','allow':TOOLS},
      'plugins':{'enabled':True,'allow':['deepseek','g1-slam'],'slots':{'memory':'none'},
        'load':{'paths':[str(ROOT/'openclaw_plugin')]},'entries':{'deepseek':{'enabled':True},'g1-slam':{'enabled':True}}}}
    if settings.get('provider_plugin') and Path(settings['provider_plugin']).is_dir():
        config['plugins']['load']['paths'].append(settings['provider_plugin'])
    path=ROOT/'config/openclaw.generated.json';write_json(path,config);path.chmod(0o600)
    runtime=Path(settings.get('openclaw_runtime',str(ROOT/'.runtime/openclaw')))
    return path,runtime,model

class Console:
    def __init__(self,session,offline=False):
        self.session=Path(session);self.offline=offline;self.history=[];self.queue=queue.Queue();self.closing=threading.Event()
        self.secret='' if offline else key();self.config,self.runtime,self.model=configure();self.active=None
        self.thread=threading.Thread(target=self.worker,daemon=True);self.thread.start()
        self.monitor=threading.Thread(target=self.watch,daemon=True);self.monitor.start()

    def say(self,s):print('\n'+redact(s,self.secret),flush=True)

    def agent_turn(self,text,epoch):
        state=read_json(self.session/'status.json',{})
        if state.get('epoch')!=epoch:raise RuntimeError('控制权已经变化，旧指令已丢弃，请重新发送')
        folder=self.session/'agent_turns'/uuid.uuid4().hex;folder.mkdir(parents=True)
        prompt=('你是 G1 手动 SLAM 与语义地图实践助手，使用已注册工具操作真实本地会话。'
          '用户通过独立键盘窗口手动建图。建图时不能代替用户自主探索。'
          '当前模式 MAPPING 时支持状态查询和 map_freeze_save；保存后 map_load 进入定位。'
          '用户说把当前位置记为某名称：先 pose_capture，再 semantic_add_place；用户说刚采集的位置时使用上下文的 latest_snapshot。'
          '用户说所画区域时先查 latest_selection，再 semantic_set_region，不能编造多边形或坐标。'
          '导航前 semantic_query 查询地点或别名，用真实地点 ID 提交 mission_submit；未知或歧义地点先说明并询问。'
          '多站点任务一次提交有序 goal_ids；经过某门口时把该门口作为中间地点。所有当前禁行/限速规则由本地执行器实施。'
          'QUEUED/RUNNING 只能说任务已提交/正在执行；只有 mission_status 返回 SUCCEEDED 才说已经到达。'
          '提交后不循环轮询，终端会异步报告结果；工具失败必须如实报告。'
          '取消使用 mission_cancel。不要调用 shell、修改文件、读取凭据、擅自创建地点或替用户解除规则。'
          '本项目当前导航使用 ROS2 Humble、RF2O、SLAM Toolbox/AMCL 和 Nav2，虚拟水平二维雷达是教学简化。'
          '当前上下文：'+json.dumps(state,ensure_ascii=False)+'\n近期对话：'+json.dumps(self.history[-8:],ensure_ascii=False)+'\n用户：'+text)
        env={**os.environ,'DEEPSEEK_API_KEY':self.secret,'G1_SLAM_SESSION':str(self.session),
             'G1_CONTROL_EPOCH':str(epoch),'G1_SLAM_AUDIT':str(folder/'tool_calls.jsonl'),
             'OPENCLAW_CONFIG_PATH':str(self.config),'OPENCLAW_STATE_DIR':str(ROOT/'.openclaw-state'),
             'PATH':str(self.runtime/'bin')+':'+str(self.runtime/'tools/node/bin')+':'+os.environ.get('PATH','')}
        binary=self.runtime/'bin/openclaw'
        if not binary.exists():raise RuntimeError('找不到已安装的 OpenClaw；检查 config/local.json 的 openclaw_runtime')
        cmd=[str(binary),'agent','exec',prompt,'--config',str(self.config),'--model',self.model,'--code-mode','direct','--json','--cwd',str(ROOT)]
        self.say('OpenClaw 正在处理：'+text)
        self.active=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
        try:out,err=self.active.communicate(timeout=180)
        except subprocess.TimeoutExpired:
            os.killpg(self.active.pid,signal.SIGTERM)
            try:out,err=self.active.communicate(timeout=4)
            except subprocess.TimeoutExpired:os.killpg(self.active.pid,signal.SIGKILL);out,err=self.active.communicate()
            raise RuntimeError('模型调用超时；机器人实际状态以本地窗口为准')
        finally:
            process=self.active;self.active=None
        out=redact(out,self.secret);err=redact(err,self.secret)
        (folder/'stdout.log').write_text(out);(folder/'stderr.log').write_text(err)
        envelope=None;decoder=json.JSONDecoder()
        for i,char in enumerate(out):
            if char!='{':continue
            try:item,_=decoder.raw_decode(out[i:])
            except ValueError:continue
            if isinstance(item,dict) and isinstance(item.get('ok'),bool) and 'status' in item:envelope=item;break
        if process.returncode or not envelope or not envelope.get('ok'):raise RuntimeError('OpenClaw/API 未完成，详见 '+str(folder))
        if envelope.get('provider')!='deepseek':raise RuntimeError('返回 provider 与 DeepSeek 配置不一致')
        reply=envelope.get('final','');self.history.extend([{'role':'user','content':text},{'role':'assistant','content':reply}])
        self.say('OpenClaw：'+reply)

    def worker(self):
        while not self.closing.is_set():
            try:text,epoch=self.queue.get(timeout=.2)
            except queue.Empty:continue
            try:self.agent_turn(text,epoch)
            except Exception as exc:self.say('未完成：'+str(exc))
            finally:self.queue.task_done()

    def watch(self):
        seen=set()
        while not self.closing.wait(.3):
            for p in (self.session/'tasks').glob('*.json'):
                if p.name in seen:continue
                value=read_json(p)
                if value:
                    seen.add(p.name);self.say('任务 '+value['status']+'：'+str(value.get('goal_names'))+'；'+value.get('reason',''))

    def handle(self,text):
        text=text.strip()
        if not text:return True
        if text in ('/quit','退出'):return False
        if text in ('/stop','停止','停下'):
            write_json(self.session/'stop.json',{'created_wall':time.time()});self.say('已发出本地停止，取消原任务。');return True
        if text=='/status':self.say(json.dumps(read_json(self.session/'status.json',{}),ensure_ascii=False,indent=2));return True
        if text.startswith('/save '):self.say(rpc(self.session,'map_freeze_save',{'name':text[6:].strip()},timeout=65));return True
        if text=='/load':self.say(rpc(self.session,'map_load',{},timeout=110));return True
        if text=='/capture':self.say(rpc(self.session,'pose_capture',{}));return True
        if text=='/help':self.say('/status /stop /save 地图ID /load /capture /quit；中文命令通过 OpenClaw。');return True
        if self.offline:self.say('当前 --offline-agent 模式不调用大模型；使用图形面板或本地 /命令。');return True
        state=read_json(self.session/'status.json',{});self.queue.put((text,state.get('epoch')));return True

    def run(self):
        self.say('终端已就绪。先在仿真窗口键盘建图；地图保存并加载后标注地点、执行语义导航。\n本地：/status /stop /save lab_floor_1 /load /capture /quit。输入 /help 查看帮助。')
        try:
            while not self.closing.is_set():
                try:line=input('你 > ')
                except (EOFError,KeyboardInterrupt):break
                try:
                    if not self.handle(line):break
                except Exception as exc:self.say('未完成：'+str(exc))
        finally:
            self.closing.set();write_json(self.session/'stop.json',{'created_wall':time.time()})
            if self.active and self.active.poll() is None:os.killpg(self.active.pid,signal.SIGTERM)

def main():
    p=argparse.ArgumentParser();p.add_argument('--session',required=True);p.add_argument('--offline-agent',action='store_true');p.add_argument('--message')
    args=p.parse_args();c=Console(args.session,args.offline_agent)
    if args.message:
        try:c.agent_turn(args.message,read_json(Path(args.session)/'status.json',{}).get('epoch'))
        finally:c.closing.set()
    else:c.run()

if __name__=='__main__':main()
