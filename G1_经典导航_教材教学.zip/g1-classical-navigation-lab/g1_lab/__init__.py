"""G1 sensor-based mapping and semantic navigation laboratory."""
