from pathlib import Path
import json
import math
import os
import re
import time
import uuid

ROOT = Path(__file__).resolve().parents[1]

def local_settings():
    """Resolve reader configuration against the repository, never a personal home."""
    defaults=read_json(ROOT/'config/local.example.json',{})
    settings={**defaults,**read_json(ROOT/'config/local.json',{})}
    for key_name in ('simulation_python','openclaw_runtime','provider_plugin','key_file'):
        if settings.get(key_name):
            path=Path(settings[key_name]).expanduser()
            settings[key_name]=str(path if path.is_absolute() else ROOT/path)
    if os.environ.get('G1_SIM_PYTHON'):
        settings['simulation_python']=str(Path(os.environ['G1_SIM_PYTHON']).expanduser().resolve())
    if os.environ.get('G1_DEEPSEEK_MODEL'):settings['model']=os.environ['G1_DEEPSEEK_MODEL']
    return settings

def write_json(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, allow_nan=False))
    temp.replace(path)

def read_json(path, default=None):
    try: return json.loads(Path(path).read_text())
    except (FileNotFoundError, json.JSONDecodeError): return default

def wrap(x): return math.atan2(math.sin(x), math.cos(x))
def yaw(q):
    x,y,z,w = q
    return math.atan2(2*(w*z+x*y), 1-2*(y*y+z*z))
def quat(theta): return [0., 0., math.sin(theta/2), math.cos(theta/2)]

def body_velocity_between(previous, current, dt):
    """Differentiate estimated SE(2) poses into the CURRENT child frame.

    RF2O's upstream ROS node publishes lateral twist as zero. Use its estimated
    positions, never simulator ground truth, to retain holonomic motion.
    """
    if not math.isfinite(dt) or not 0 < dt <= .5:
        raise ValueError('里程计时间间隔无效或已过期')
    if len(previous)!=3 or len(current)!=3 or not all(math.isfinite(x) for x in [*previous,*current]):
        raise ValueError('里程计位姿无效')
    dx=(current[0]-previous[0])/dt;dy=(current[1]-previous[1])/dt
    c=math.cos(current[2]);s=math.sin(current[2])
    return [c*dx+s*dy,-s*dx+c*dy,wrap(current[2]-previous[2])/dt]

def finite(value, lo, hi):
    if isinstance(value, bool) or not isinstance(value, (float,int)) or not math.isfinite(value) or not lo <= value <= hi:
        raise ValueError(f'数值必须在 {lo} 到 {hi} 之间')
    return float(value)

def safe_id(s):
    if not isinstance(s,str) or not re.fullmatch(r'[a-zA-Z0-9_-]{1,64}',s):
        raise ValueError('ID 只能包含字母、数字、下划线和短横线，长度 1–64')
    return s

def rpc(session, operation, parameters=None, timeout=20, epoch=None):
    session=Path(session); token=uuid.uuid4().hex
    status=read_json(session/'status.json', {})
    if not status.get('running') or time.time()-status.get('updated_wall',0)>5:
        raise RuntimeError('ROS 网关未运行或状态已过期')
    msg={'id':token,'operation':operation,'parameters':parameters or {},'created_wall':time.time(),
         'epoch':status.get('epoch') if epoch is None else epoch}
    write_json(session/'inbox'/(token+'.json'),msg)
    result=session/'responses'/(token+'.json'); deadline=time.monotonic()+timeout
    while time.monotonic()<deadline:
        if result.exists():
            value=read_json(result); result.unlink(missing_ok=True)
            if not value.get('ok'): raise RuntimeError(value.get('error','调用失败'))
            return value['result']
        time.sleep(.04)
    raise TimeoutError('等待本地网关超时；请检查 ros.log')

def key():
    value=os.environ.get('DEEPSEEK_API_KEY','').strip()
    if value:return value
    settings=local_settings()
    p=Path(settings.get('key_file',str(ROOT/'config/deepseek.key'))).expanduser()
    if p.is_file():return p.read_text().strip()
    raise RuntimeError('未找到 DeepSeek API Key；请配置 DEEPSEEK_API_KEY 或 config/local.json 中的 key_file')

def redact(value, secret=''):
    s=str(value)
    if secret:s=s.replace(secret,'[REDACTED]')
    return re.sub(r'\bsk-[A-Za-z0-9_-]{12,}', '[REDACTED]', s)
