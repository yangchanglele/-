"""Native Tk teleoperation, MuJoCo view and editable SLAM map layers."""
import math
import queue
import threading
import time
from pathlib import Path
from .tk_backend import prepare_tk
prepare_tk()
import tkinter as tk
from tkinter import ttk, filedialog

import mujoco
import numpy as np
from PIL import Image, ImageTk
from .common import ROOT, read_json, write_json, rpc
from .maps import Grid
from .egl import EGLContext
from .ui_style import configure_fonts, ScrollPanel, MODE_LABELS, OPERATION_LABELS


class Renderer:
    def __init__(self, model, width=640, height=440):
        self.model=model;self.data=mujoco.MjData(model);self.w=width;self.h=height
        model.vis.global_.offwidth=width;model.vis.global_.offheight=height
        self.egl=EGLContext(width,height);self.context=mujoco.MjrContext(model,mujoco.mjtFontScale.mjFONTSCALE_100)
        mujoco.mjr_setBuffer(mujoco.mjtFramebuffer.mjFB_OFFSCREEN,self.context)
        self.scene=mujoco.MjvScene(model,maxgeom=5000);self.camera=mujoco.MjvCamera();self.option=mujoco.MjvOption()
        self.option.geomgroup[3]=0
        self.rgb=np.empty((height,width,3),np.uint8);self.overview=False

    def frame(self,qpos):
        self.data.qpos[:]=qpos;mujoco.mj_forward(self.model,self.data)
        self.camera.type=mujoco.mjtCamera.mjCAMERA_FREE;self.camera.azimuth=120
        if self.overview:self.camera.lookat[:]=[3.5,2.5,0];self.camera.distance=18;self.camera.elevation=-75
        else:self.camera.lookat[:]=[qpos[0],qpos[1],.7];self.camera.distance=4.5;self.camera.elevation=-25
        mujoco.mjv_updateScene(self.model,self.data,self.option,None,self.camera,mujoco.mjtCatBit.mjCAT_ALL,self.scene)
        view=mujoco.MjrRect(0,0,self.w,self.h);mujoco.mjr_render(view,self.scene,self.context)
        mujoco.mjr_readPixels(self.rgb,None,view,self.context)
        return Image.fromarray(self.rgb[::-1].copy())

    def close(self):self.context.free();self.egl.close()


class Window:
    def __init__(self,service):
        self.service=service;self.session=service.session;self.root=tk.Tk()
        self.root.title('G1 人形机器人 · 手动建图与语义导航')
        width=min(1540,max(980,self.root.winfo_screenwidth()-80))
        height=min(1040,max(620,self.root.winfo_screenheight()-100))
        self.root.geometry(f'{width}x{height}');self.root.minsize(min(1180,width),min(740,height))
        self.root.configure(bg='#0c1828');self.fonts,self.font_family=configure_fonts(self.root)
        write_json(self.session/'ui_font.json',{'family':self.font_family,'body':self.fonts['Body'].actual(),'runtime':prepare_tk(),
            'language':'zh-CN','tk_scaling':float(self.root.tk.call('tk','scaling'))})
        self.status_var=tk.StringVar(value='正在启动传感与 ROS 2 …');self.message=tk.StringVar(value='先点击仿真画面获得键盘焦点，再按 W/A/S/D/Q/E。')
        ttk.Label(self.root,text='G1 手动建图与语义地图导航',font=self.fonts['Title']).pack(fill='x',padx=14,pady=(10,4))
        self.status_label=ttk.Label(self.root,textvariable=self.status_var,font=self.fonts['Small'],wraplength=width-36)
        self.status_label.pack(fill='x',padx=14)
        self.message_label=ttk.Label(self.root,textvariable=self.message,wraplength=width-36,foreground='#a0efd5',padding=(0,8))
        self.message_label.pack(side='bottom',fill='x',padx=14)
        body=ttk.Frame(self.root);body.pack(fill='both',expand=True,padx=12,pady=8)
        self.controls=ScrollPanel(body);self.controls.pack(side='left',fill='y',padx=(0,10))
        left=self.controls.content;right=ttk.Frame(body);right.pack(side='left',fill='both',expand=True)
        self.drive=tk.Canvas(left,width=640,height=360,bg='#172a40',highlightthickness=3,highlightbackground='#32516b',takefocus=True)
        self.drive.pack();self.image_item=self.drive.create_image(0,0,anchor='nw')
        self.drive.bind('<Button-1>',lambda _:self.drive.focus_set())
        self.drive.bind('<KeyPress>',self.keydown);self.drive.bind('<KeyRelease>',self.keyup)
        self.drive.bind('<FocusOut>',lambda _:self.clear_keys());self.drive.bind('<FocusIn>',lambda _:self.drive.configure(highlightbackground='#65ddb6'))
        self.keys=set();self.releases={};self.speed=tk.DoubleVar(value=.22);self.press_started=0.
        ttk.Label(left,text='键盘：W/S 前后 · A/D 侧移 · Q/E 转向 · 空格/ESC 停止').pack(anchor='w',pady=5)
        row=ttk.Frame(left);row.pack(fill='x')
        ttk.Button(row,text='立即停止',command=self.stop).pack(side='left',padx=3)
        ttk.Button(row,text='跟随 / 俯视',command=self.toggle_view).pack(side='left',padx=3)
        ttk.Scale(row,from_=.1,to=.3,variable=self.speed,length=180).pack(side='left',padx=8)
        ttk.Label(row,text='速度 0.1–0.3 米/秒',font=self.fonts['Small']).pack(side='left')
        group=ttk.LabelFrame(left,text='1 · 手动建图 → 保存 → 加载定位');group.pack(fill='x',pady=10)
        self.map_name=tk.StringVar(value='lab_floor_1');ttk.Entry(group,textvariable=self.map_name,width=18).pack(side='left',padx=5,pady=8)
        ttk.Button(group,text='保存地图与位姿图',command=self.save_map).pack(side='left',padx=3)
        ttk.Button(group,text='加载刚保存地图',command=lambda:self.call('map_load',{},'地图加载完成',timeout=100)).pack(side='left',padx=3)
        ttk.Button(left,text='加载其他地图包…（选择 rev_XXX 目录）',command=self.load_other).pack(fill='x')
        ttk.Button(left,text='在当前地图上继续手动建图（生成新版本）',command=lambda:self.call('mapping_resume',{},'已恢复建图；正式语义需在新地图冻结后复核。',timeout=60)).pack(fill='x',pady=3)
        sem=ttk.LabelFrame(left,text='2 · 采集地点与编辑语义');sem.pack(fill='x',pady=10)
        self.name=tk.StringVar(value='出发点');self.aliases=tk.StringVar();self.captured=None;self.selected=None
        r=ttk.Frame(sem);r.pack(fill='x',pady=5)
        ttk.Label(r,text='名称').pack(side='left');ttk.Entry(r,textvariable=self.name,width=18).pack(side='left',padx=5)
        ttk.Label(r,text='别名（逗号分隔）').pack(side='left');ttk.Entry(r,textvariable=self.aliases,width=16).pack(side='left',padx=5)
        r=ttk.Frame(sem);r.pack(fill='x',pady=5)
        ttk.Button(r,text='采集当前位置',command=self.capture).pack(side='left',padx=4)
        ttk.Button(r,text='保存为地点',command=self.add_place).pack(side='left',padx=4)
        self.places=tk.Listbox(sem,height=5,font=self.fonts['Body'],bg='#0b1727',fg='#edf4fc',selectbackground='#315d7c',selectforeground='#ffffff',exportselection=False)
        self.places.pack(fill='x',padx=5,pady=5)
        r=ttk.Frame(sem);r.pack(fill='x')
        ttk.Button(r,text='导航至选中地点',command=self.goto).pack(side='left',padx=4,pady=4)
        ttk.Button(r,text='删除选中地点',command=self.remove_place).pack(side='left',padx=4,pady=4)
        self.from_id=tk.StringVar();self.to_id=tk.StringVar()
        row=ttk.Frame(left);row.pack(fill='x')
        self.from_box=ttk.Combobox(row,textvariable=self.from_id,width=15,state='readonly');self.from_box.pack(side='left',padx=3)
        ttk.Label(row,text='→').pack(side='left');self.to_box=ttk.Combobox(row,textvariable=self.to_id,width=15,state='readonly');self.to_box.pack(side='left',padx=3)
        ttk.Button(row,text='校验并连接',command=self.connect).pack(side='left',padx=3)
        header=ttk.Frame(right);header.pack(fill='x')
        self.layer=tk.StringVar(value='占据地图');self.layers=['占据地图','SLAM 位姿图','全局代价地图','局部代价地图','语义地图','拓扑地图','规则地图']
        ttk.Combobox(header,textvariable=self.layer,values=self.layers,state='readonly',width=16).pack(anchor='w')
        help_label=ttk.Label(header,text='地图来自传感器估计与人工标注',font=self.fonts['Small'],wraplength=450)
        help_label.pack(anchor='w',pady=(5,0))
        header.bind('<Configure>',lambda e:help_label.configure(wraplength=max(100,e.width-8)))
        self.map_canvas=tk.Canvas(right,bg='#09131f',height=590,highlightthickness=0);self.map_canvas.pack(fill='both',expand=True,pady=6)
        self.map_canvas.bind('<Button-1>',self.map_click);self.map_canvas.bind('<Button-3>',lambda _:self.clear_selection())
        edit=ttk.LabelFrame(right,text='3 · 地图选区：左键加点，右键清空');edit.pack(fill='x')
        self.edit_kind=tk.StringVar(value='查看');self.heading=tk.DoubleVar(value=0);self.limit=tk.DoubleVar(value=.2)
        row=ttk.Frame(edit);row.pack(fill='x',pady=6)
        ttk.Combobox(row,textvariable=self.edit_kind,values=['查看','目标位姿','房间','禁行区','限速区'],state='readonly',width=12).pack(side='left',padx=4)
        ttk.Label(row,text='朝向（度）').pack(side='left');ttk.Spinbox(row,from_=-180,to=180,increment=15,textvariable=self.heading,width=6).pack(side='left',padx=4)
        row=ttk.Frame(edit);row.pack(fill='x',pady=6)
        ttk.Label(row,text='限速（米/秒）').pack(side='left',padx=4);ttk.Spinbox(row,from_=.1,to=.3,increment=.05,textvariable=self.limit,width=6).pack(side='left',padx=4)
        ttk.Button(row,text='提交选区',command=self.commit_selection).pack(side='left',padx=6)
        edit_help=ttk.Label(edit,text='名称填写在左侧。目标位姿提交后，再点击“保存为地点”。',font=self.fonts['Small'],wraplength=440)
        edit_help.pack(anchor='w',padx=6,pady=4)
        edit.bind('<Configure>',lambda e:edit_help.configure(wraplength=max(100,e.width-16)))
        self.controls.enable_wheel();self.root.bind('<Configure>',self.resize_text,add='+')
        self.renderer=Renderer(service.physics.model,640,360);self.events=queue.Queue();self.state={};self.grid=None;self.map_transform=None
        self.points=[];self.place_items=[];self.last_places=None;self.last_map_draw=0;self.frame_count=0
        self.root.bind('<Escape>',lambda _:self.stop());self.root.protocol('WM_DELETE_WINDOW',self.close)
        self.root.report_callback_exception=self.callback_error

    def resize_text(self,event):
        if event.widget==self.root:
            self.status_label.configure(wraplength=max(200,event.width-36))
            self.message_label.configure(wraplength=max(200,event.width-36))

    def callback_error(self,kind,value,tb):
        import traceback
        traceback.print_exception(kind,value,tb);self.message.set('界面错误：'+str(value));self.stop()

    def keydown(self,event):
        key=event.keysym.lower()
        if key in ('space','escape'):self.stop();return 'break'
        if key not in 'wasdqe' or len(key)!=1:return
        if key in self.releases:self.root.after_cancel(self.releases.pop(key))
        if not self.keys:self.press_started=time.time()
        self.keys.add(key);return 'break'

    def keyup(self,event):
        key=event.keysym.lower()
        if key in self.releases:self.root.after_cancel(self.releases[key])
        self.releases[key]=self.root.after(15,lambda k=key:self.release_key(k))

    def release_key(self,key):self.keys.discard(key);self.releases.pop(key,None)
    def clear_keys(self):
        self.keys.clear();self.drive.configure(highlightbackground='#32516b');self.teleop()
    def stop(self):
        self.clear_keys();write_json(self.session/'stop.json',{'created_wall':time.time()});self.message.set('停止请求已发出；机器人减速并保持站立。')
    def toggle_view(self):self.renderer.overview=not self.renderer.overview

    def teleop(self):
        s=self.speed.get();k=self.keys
        velocity=[s*(('w' in k)-('s' in k)),min(.2,s)*(('a' in k)-('d' in k)),.25*(('q' in k)-('e' in k))]
        write_json(self.session/'teleop.json',{'created_wall':time.time(),'active':bool(k),'velocity':velocity,'press_started':self.press_started})

    def call(self,operation,params,message='',callback=None,timeout=30):
        self.message.set('正在'+OPERATION_LABELS.get(operation,'处理请求')+'……')
        def work():
            try:self.events.put((True,rpc(self.session,operation,params,timeout=timeout),message,callback))
            except Exception as exc:self.events.put((False,str(exc),'',None))
        threading.Thread(target=work,daemon=True).start()

    def save_map(self):self.clear_keys();self.call('map_freeze_save',{'name':self.map_name.get()},'地图与原生位姿图已保存；点击加载地图进入定位。',timeout=60)
    def load_other(self):
        p=filedialog.askdirectory(initialdir=ROOT/'maps',title='选择包含 manifest.json 的 rev_XXX 地图包')
        if p:self.call('map_load',{'bundle':p},'地图加载完成',timeout=100)
    def capture(self):
        self.clear_keys()
        def done(result):self.captured=result['snapshot_id'];self.selected=None;self.message.set('位姿已采集。填写名称后保存地点，或在 OpenClaw 终端命名。')
        self.call('pose_capture',{},callback=done)
    def add_place(self):
        p={'name':self.name.get(),'aliases':[s.strip() for s in self.aliases.get().replace('，',',').split(',') if s.strip()]}
        if self.captured:p['snapshot_id']=self.captured
        elif self.selected:p['selection_id']=self.selected
        else:self.message.set('先采集当前位置，或在地图上选择目标位姿。');return
        self.call('semantic_add_place',p,'地点已保存')
    def chosen(self):
        indexes=self.places.curselection()
        if not indexes:raise ValueError('请先选中一个地点')
        return self.place_items[indexes[0]]
    def goto(self):
        try:p=self.chosen();self.call('mission_submit',{'goal_ids':[p['id']],'expected_versions':self.state.get('versions')},'导航任务已提交')
        except ValueError as exc:self.message.set(str(exc))
    def remove_place(self):
        try:self.call('semantic_remove',{'id':self.chosen()['id']},'地点已删除')
        except ValueError as exc:self.message.set(str(exc))
    def connect(self):self.call('semantic_connect',{'from_id':self.from_id.get(),'to_id':self.to_id.get()},'单向拓扑边已校验并保存；反向连接可交换起终点再提交')
    def clear_selection(self):self.points=[];self.selected=None

    def map_click(self,event):
        if self.edit_kind.get()=='查看' or not self.map_transform:return
        if self.layer.get() in ('全局代价地图','局部代价地图'):
            self.message.set('请切回占据/语义/规则地图后编辑，避免使用局部 odom 坐标。');return
        x0,y0,scale=self.map_transform;ix=(event.x-x0)/scale;iy=self.grid.h-(event.y-y0)/scale
        x,y=self.grid.world(ix-.5,iy-.5)
        if self.edit_kind.get()=='目标位姿':self.points=[[float(x),float(y)]]
        else:self.points.append([float(x),float(y)])

    def commit_selection(self):
        kind=self.edit_kind.get()
        if kind=='查看' or not self.points:return
        if kind=='目标位姿':coordinates=self.points[0]+[math.radians(self.heading.get())];selection_kind='pose'
        else:coordinates=list(self.points);selection_kind='polygon'
        name=self.name.get();speed=self.limit.get()
        def done(result):
            self.selected=result['selection_id'];self.captured=None
            if kind=='目标位姿':self.message.set('目标位姿已选择；填写名称后点击“存为地点”。')
            else:self.call('semantic_set_region',{'selection_id':self.selected,'name':name,'kind':{'房间':'room','禁行区':'keepout','限速区':'speed_limit'}[kind],'max_linear_mps':speed},'区域已保存；规则更新已停止原任务。')
        self.call('selection_set',{'kind':selection_kind,'coordinates':coordinates,'expected_versions':self.state.get('versions')},callback=done)

    def draw_map(self):
        layer=self.layer.get();file={'全局代价地图':'global_costmap.json','局部代价地图':'local_costmap.json'}.get(layer,'map_view.json')
        data=read_json(self.session/file)
        c=self.map_canvas;c.delete('all');w=max(c.winfo_width(),30);h=max(c.winfo_height(),30)
        if not data:
            c.create_text(w/2,h/2,text='等待'+layer+'\n先用键盘移动，观察扫描和建图。',fill='#cad9e9',font=self.fonts['Empty'],width=max(100,w-40));return
        g=Grid(data['data'],data['resolution'],data['origin']);self.grid=g
        scale=min((w-24)/g.w,(h-24)/g.h);dw=max(1,int(g.w*scale));dh=max(1,int(g.h*scale));x0=(w-dw)/2;y0=(h-dh)/2
        self.map_transform=(x0,y0,scale);arr=g.data
        rgb=np.zeros((*arr.shape,3),dtype=np.uint8);rgb[:]=[35,51,70]
        rgb[(arr>=0)&(arr<25)]=[201,216,224];rgb[arr>=65]=[13,24,36]
        middle=(arr>=25)&(arr<65);rgb[middle]=[105,129,150]
        if '代价' in layer:
            mask=arr>=0;rgb[mask,0]=np.clip(75+arr[mask]*1.8,0,255);rgb[mask,1]=np.clip(170-arr[mask]*1.2,0,255);rgb[mask,2]=100
        self.map_photo=ImageTk.PhotoImage(Image.fromarray(np.flipud(rgb)).resize((dw,dh),Image.Resampling.NEAREST))
        c.create_image(x0,y0,anchor='nw',image=self.map_photo)
        def pixel(p):
            dx=p[0]-g.origin[0];dy=p[1]-g.origin[1];co=math.cos(g.origin[2]);si=math.sin(g.origin[2])
            ix=(co*dx+si*dy)/g.resolution;iy=(-si*dx+co*dy)/g.resolution
            return x0+ix*scale,y0+(g.h-iy)*scale
        is_odom=data.get('frame_id')=='odom'
        pose=read_json(self.session/'odometry.json',{}).get('pose') if is_odom else self.state.get('estimated_pose')
        if pose:
            x,y=pixel(pose);c.create_oval(x-6,y-6,x+6,y+6,fill='#18a77e',outline='white',width=2)
            c.create_line(x,y,x+20*math.cos(pose[2]-g.origin[2]),y-20*math.sin(pose[2]-g.origin[2]),fill='#138c68',width=3)
        if not is_odom:
            if layer=='SLAM 位姿图':
                for item in read_json(self.session/'pose_graph_markers.json',[]):
                    pts=item['points']
                    if len(pts)>=2:
                        for a,b in zip(pts[::2],pts[1::2]):c.create_line(*pixel(a),*pixel(b),fill='#985de1',width=2)
                    else:
                        x,y=pixel(item['position']);c.create_oval(x-2,y-2,x+2,y+2,fill='#ae59e7',outline='')
            if layer in ('语义地图','拓扑地图','规则地图','占据地图'):
                for region in self.state.get('regions',[]):
                    color={'room':'#549dd7','keepout':'#e85b82','speed_limit':'#e3b44d'}[region['kind']]
                    c.create_polygon(*[v for p in region['polygon'] for v in pixel(p)],outline=color,fill=color,stipple='gray25',width=2)
                    x,y=pixel(region['polygon'][0]);self.map_label(x+5,y+12,region['name'])
                for place in self.state.get('places',[]):
                    x,y=pixel(place['approach_pose']);c.create_oval(x-4,y-4,x+4,y+4,fill='#087e9d',outline='white')
                    self.map_label(x+9,y-12,place['name'])
            if layer=='拓扑地图':
                for edge in self.state.get('topology',{}).get('edges',[]):
                    pts=edge.get('path',[])
                    if len(pts)>=2:c.create_line(*[v for p in pts for v in pixel(p)],fill='#a77413',width=3,arrow='last')
            path=self.state.get('path',[])
            if len(path)>=2:c.create_line(*[v for p in path for v in pixel(p)],fill='#de9d00',width=2)
            if self.points:
                flat=[v for p in self.points for v in pixel(p)]
                if len(self.points)>1:c.create_line(*flat,fill='#eb3f69',width=2)
                for p in self.points:
                    x,y=pixel(p);c.create_oval(x-4,y-4,x+4,y+4,fill='#eb3f69')
        frame_name={'map':'地图坐标系','odom':'里程计坐标系'}.get(data.get('frame_id','map'),'当前坐标系')
        self.map_label(12,12,f'{layer} · {frame_name}\n分辨率：{g.resolution:.2f} 米/格',anchor='nw',small=True,width=max(100,w-36))

    def map_label(self,x,y,text,anchor='w',small=False,width=0):
        c=self.map_canvas
        limit=max(100,c.winfo_width()-30)
        item=c.create_text(x,y,text=text,anchor=anchor,fill='#f3f8ff',font=self.fonts['Small' if small else 'Map'],width=width or min(280,limit))
        bounds=c.bbox(item)
        if bounds:
            x0,y0,x1,y1=bounds
            dx=max(0,8-x0)-max(0,x1-(c.winfo_width()-8))
            dy=max(0,8-y0)-max(0,y1-(c.winfo_height()-8))
            c.move(item,dx,dy);x0+=dx;x1+=dx;y0+=dy;y1+=dy
            backing=c.create_rectangle(x0-5,y0-3,x1+5,y1+3,fill='#13283d',outline='#45647d')
            c.tag_lower(backing,item)
        return item

    def tick(self):
        if self.service.quit.is_set():self.close();return
        self.teleop()
        while not self.events.empty():
            ok,result,message,callback=self.events.get()
            if ok:
                self.message.set(message or str(result)[:180])
                if callback:callback(result)
            else:self.message.set('未完成：'+str(result))
        self.state=read_json(self.session/'status.json',{})
        pose=self.state.get('estimated_pose');text='定位尚未就绪' if not pose else f'估计位置（{pose[0]:.2f}，{pose[1]:.2f}）米 · 朝向 {math.degrees(pose[2]):.1f} 度'
        mode=MODE_LABELS.get(self.state.get('mode'),'正在启动')
        self.status_var.set(f'{mode}  |  {text}  |  仿真时间 {self.service.physics.data.time:.1f} 秒  |  点击仿真画面后使用键盘')
        places=self.state.get('places',[])
        if places!=self.last_places:
            self.place_items=places;self.last_places=places;self.places.delete(0,'end')
            for p in places:self.places.insert('end',p['name'])
            names=[p['name'] for p in places];self.from_box['values']=names;self.to_box['values']=names
        with self.service.lock:qpos=self.service.physics.data.qpos.copy()
        frame=self.renderer.frame(qpos);self.photo=ImageTk.PhotoImage(frame);self.drive.itemconfigure(self.image_item,image=self.photo)
        if time.monotonic()-self.last_map_draw>.3:self.draw_map();self.last_map_draw=time.monotonic()
        if self.frame_count%100==0:frame.save(self.session/'simulation_preview.png')
        self.frame_count+=1;self.root.after(40,self.tick)

    def close(self):
        self.stop();self.service.quit.set()
        if self.root.winfo_exists():self.root.destroy()

    def run(self):
        try:self.tick();self.root.mainloop()
        finally:self.renderer.close()
