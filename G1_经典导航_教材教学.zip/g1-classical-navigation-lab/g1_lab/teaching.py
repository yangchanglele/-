"""Small offline exercises. Production navigation uses the ROS stack.

ICP here is point-to-point registration; it must not be called RF2O.
"""
import math
import numpy as np
from scipy.spatial import cKDTree
from scipy.optimize import least_squares
from .common import wrap
from .maps import Grid

def transform(pose, points):
    c=math.cos(pose[2]);s=math.sin(pose[2]);R=np.array([[c,-s],[s,c]])
    return np.asarray(points)@R.T+pose[:2]

def compose(a,b):
    xy=transform(a,np.array([b[:2]]))[0]
    return np.array([*xy,wrap(a[2]+b[2])])

def relative(a,b):
    c=math.cos(a[2]);s=math.sin(a[2]);d=np.asarray(b[:2])-a[:2]
    return np.array([c*d[0]+s*d[1],-s*d[0]+c*d[1],wrap(b[2]-a[2])])

def points(scan):
    r=np.asarray(scan['ranges']);a=scan['angle_min']+np.arange(len(r))*scan['angle_increment']
    valid=np.isfinite(r)&(r>scan['range_min'])&(r<scan['range_max']-.02)
    return np.column_stack((r[valid]*np.cos(a[valid]),r[valid]*np.sin(a[valid])))

def icp(previous,current,initial=None,iterations=30):
    """Return current-to-previous SE(2), RMSE and inlier fraction."""
    if len(previous)<20 or len(current)<20:raise ValueError('扫描点太少')
    estimate=np.zeros(3) if initial is None else np.array(initial,dtype=float)
    tree=cKDTree(previous);rmse=float('inf');fraction=0.
    for _ in range(iterations):
        moved=transform(estimate,current);d,indices=tree.query(moved)
        threshold=min(.5,max(.04,float(np.quantile(d,.85))));keep=d<threshold
        fraction=float(keep.mean())
        if keep.sum()<20:raise ValueError('ICP 有效匹配不足')
        a=moved[keep];b=previous[indices[keep]];ma=a.mean(axis=0);mb=b.mean(axis=0)
        u,_,vt=np.linalg.svd((a-ma).T@(b-mb));R=vt.T@u.T
        if np.linalg.det(R)<0:vt[-1]*=-1;R=vt.T@u.T
        t=mb-R@ma;delta=np.array([*t,math.atan2(R[1,0],R[0,0])])
        estimate=compose(delta,estimate);rmse=float(np.sqrt(np.mean(d[keep]**2)))
        if np.linalg.norm(delta)<1e-6:break
    return estimate,rmse,fraction

def icp_point_to_line(previous,current,initial=None,iterations=15):
    """Scan matching using local line normals; better wall-tangent invariance.

    Still an educational ICP implementation, not the range-flow RF2O method.
    """
    previous=np.asarray(previous);current=np.asarray(current)
    if len(previous)<30 or len(current)<30:raise ValueError('扫描点太少')
    tree=cKDTree(previous);_,neighbors=tree.query(previous,k=7)
    centered=previous[neighbors]-previous[neighbors].mean(axis=1,keepdims=True)
    covariance=np.einsum('nki,nkj->nij',centered,centered)
    eigenvalues,eigenvectors=np.linalg.eigh(covariance)
    normals=eigenvectors[:,:,0]
    line_quality=eigenvalues[:,0]/np.maximum(eigenvalues[:,1],1e-9)<.05
    estimate=np.zeros(3) if initial is None else np.asarray(initial,float).copy()
    rmse=float('inf');fraction=0.
    for _ in range(iterations):
        moved=transform(estimate,current);distance,index=tree.query(moved)
        n=normals[index];residual=np.sum(n*(moved-previous[index]),axis=1)
        keep=(distance<.6)&line_quality[index]&(np.abs(residual)<.3)
        if keep.sum()<25:raise ValueError('有效线面约束不足')
        v=moved[keep];n=n[keep];r=residual[keep]
        J=np.column_stack((n[:,0],n[:,1],-n[:,0]*v[:,1]+n[:,1]*v[:,0]))
        weights=np.sqrt(np.minimum(1.,.03/np.maximum(np.abs(r),1e-9)))
        delta,_,rank,_=np.linalg.lstsq(J*weights[:,None],-r*weights,rcond=1e-5)
        if rank<3:raise ValueError('扫描几何退化，无法约束完整 SE(2) 运动')
        estimate=compose(delta,estimate);rmse=float(np.sqrt(np.mean(r*r)));fraction=float(keep.mean())
        if np.linalg.norm(delta)<1e-6:break
    return estimate,rmse,fraction

def ray_cells(x0,y0,x1,y1):
    """Integer Bresenham traversal including both endpoints."""
    dx=abs(x1-x0);sx=1 if x0<x1 else -1;dy=-abs(y1-y0);sy=1 if y0<y1 else -1;err=dx+dy
    while True:
        yield x0,y0
        if x0==x1 and y0==y1:break
        e2=2*err
        if e2>=dy:err+=dy;x0+=sx
        if e2<=dx:err+=dx;y0+=sy

class OccupancyBuilder:
    def __init__(self,resolution=.1,width=240,height=240,origin=(-6.,-6.,0.)):
        self.grid=Grid(np.full((height,width),-1),resolution,origin)
        self.log_odds=np.zeros((height,width));self.observed=np.zeros((height,width),bool)
    def update(self,scan,pose):
        origin=self.grid.cell(*pose[:2])
        r=np.asarray(scan['ranges']);angles=scan['angle_min']+np.arange(len(r))*scan['angle_increment']
        for distance,angle in zip(r,angles):
            if not math.isfinite(distance) or distance<scan['range_min']:continue
            distance=min(distance,scan['range_max']);hit=distance<scan['range_max']-.02
            endpoint=transform(pose,[[distance*math.cos(angle),distance*math.sin(angle)]])[0]
            end=self.grid.cell(*endpoint);cells=list(ray_cells(*origin,*end))
            for x,y in cells[:-1]:
                if 0<=x<self.grid.w and 0<=y<self.grid.h:self.log_odds[y,x]-=.35;self.observed[y,x]=True
            x,y=cells[-1]
            if 0<=x<self.grid.w and 0<=y<self.grid.h:
                self.log_odds[y,x]+=.85 if hit else -.35;self.observed[y,x]=True
        np.clip(self.log_odds,-5,5,out=self.log_odds)
    def result(self):
        data=np.rint(100/(1+np.exp(-self.log_odds))).astype(np.int16);data[~self.observed]=-1
        return Grid(data,self.grid.resolution,self.grid.origin)

def optimize_pose_graph(initial,edges):
    """Fixed first pose, weighted relative constraints, robust least squares.

    Each edge is (i, j, measurement_SE2, sigma_xyz). Educational solver only.
    """
    initial=np.asarray(initial,float);first=initial[0].copy()
    def residual(x):
        poses=np.vstack((first,x.reshape(-1,3)));out=[]
        for i,j,z,sigma in edges:
            error=relative(poses[i],poses[j])-z;error[2]=wrap(error[2]);out.extend(error/np.asarray(sigma))
        return np.asarray(out)
    result=least_squares(residual,initial[1:].ravel(),loss='soft_l1',max_nfev=100)
    return np.vstack((first,result.x.reshape(-1,3))),{'cost_before':float(np.sum(residual(initial[1:].ravel())**2)),
                                                    'cost_after':float(np.sum(residual(result.x)**2)),'success':bool(result.success)}
