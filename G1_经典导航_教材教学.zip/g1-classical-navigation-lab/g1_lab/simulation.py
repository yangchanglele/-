"""Physics and ray sensor only. No world pose is supplied to navigation."""
import argparse
import csv
import math
from pathlib import Path
import threading
import time
import xml.etree.ElementTree as ET

import mujoco
import numpy as np
from .policy import Policy, build_model, yaw_of
from .common import write_json, read_json


def scene_xml(xml):
    root=ET.fromstring(xml); world=root.find('worldbody')
    # Group 2 is exclusively the physical environment: all robot geoms are
    # excluded from ray sensing, including nested limbs, not just the pelvis.
    for g in root.findall('.//geom'):
        if g.get('name')!='floor':
            collision=g.get('class') in ('collision','foot_capsule') or g.get('name','').endswith('_collision')
            g.set('group','3' if collision else '0')
    world.find("geom[@name='floor']").set('group','1')
    world.find("geom[@name='floor']").set('rgba','.22 .28 .35 1')
    walls=[('west',-2.5,2.5,.12,6.0),('east',10.5,2.5,.12,6.0),
           ('south',4.,-3.5,6.5,.12),('north',4.,8.5,6.5,.12),
           ('partition_a',3.5,-2.0,.10,1.4),('partition_b',3.5,3.4,.10,1.5),
           ('partition_c',3.5,7.3,.10,1.1),('room_top',7.,5.,3.4,.1)]
    for name,x,y,sx,sy in walls:
        ET.SubElement(world,'geom',name='wall_'+name,type='box',pos=f'{x} {y} .95',
                      size=f'{sx} {sy} .95',rgba='.55 .65 .74 1',group='2')
    for name,x,y,sx,sy,color in [('cabinet',7.,-1.5,.7,.5,'.25 .52 .8 1'),
                                ('pillar',.8,4.6,.4,.4,'.8 .55 .25 1'),
                                ('table',7.9,7.,.9,.5,'.55 .36 .25 1')]:
        ET.SubElement(world,'geom',name='obstacle_'+name,type='box',pos=f'{x} {y} .65',
                      size=f'{sx} {sy} .65',rgba=color,group='2')
    asset=root.find('asset')
    if asset is None:asset=ET.SubElement(root,'asset')
    ET.SubElement(world,'light',name='lab_light',pos='3 2 8',dir='0 0 -1',diffuse='.8 .8 .8')
    return ET.tostring(root,encoding='unicode')


class Physics:
    dt=.002
    control_dt=.02
    def __init__(self, seed=7, scan_noise=.006):
        self.policy=Policy('duet')
        _,xml=build_model(self.policy,self.dt)
        self.xml=scene_xml(xml);self.model=mujoco.MjModel.from_xml_string(self.xml)
        self.policy.bind(self.model);self.data=mujoco.MjData(self.model)
        self.data.qpos[2]=.8;self.data.qpos[3]=1
        self.data.qpos[self.policy.qids]=self.policy.default
        mujoco.mj_forward(self.model,self.data)
        self.command=np.zeros(3);self.integral=np.zeros(2)
        self.filtered_odometry=np.zeros(3);self.turn_anchor=None
        self.target=self.policy.default.copy();self.state='WARMUP';self.contacts=0;self.contact_active=False
        self.rng=np.random.default_rng(seed);self.noise=scan_noise
        self.angles=np.linspace(-math.pi,math.pi,360,endpoint=False)
        self.ray_group=np.array([0,0,1,0,0,0],dtype=np.uint8)
        self.ray_id=np.zeros(1,dtype=np.int32)
        self.last_scan=None

    def step(self, desired, odometry=None, odom_pose=None):
        desired=np.asarray(desired,dtype=float)
        if self.state=='FALLEN':return
        R=self.data.xmat[self.policy.pelvis].reshape(3,3)
        if self.data.qpos[2]<.45 or R[2,2]<math.cos(math.radians(55)):
            self.command[:]=0;self.state='FALLEN';return
        if self.data.time<2:desired=np.zeros(3)
        else:self.state='WALKING' if np.linalg.norm(desired)>.015 else 'STANDING'
        # Feedback is RF2O body velocity, never qvel's global translation.
        adjusted=desired.copy()
        pure_turn=np.linalg.norm(desired[:2])<.015 and abs(desired[2])>.08
        if pure_turn and odom_pose is not None:
            if self.turn_anchor is None:self.turn_anchor=np.asarray(odom_pose[:2]).copy()
            dx,dy=self.turn_anchor-np.asarray(odom_pose[:2]);c=math.cos(odom_pose[2]);s=math.sin(odom_pose[2])
            adjusted[:2]=np.clip(.8*np.array([c*dx+s*dy,-s*dx+c*dy]),-.2,.2)
        elif not pure_turn:self.turn_anchor=None
        # Pure yaw also needs translational feedback: the pretrained gait can
        # otherwise drift forward while DWB requests an in-place rotation.
        if odometry is not None and np.linalg.norm(desired)>.08:
            self.filtered_odometry+=.08*(np.asarray(odometry)-self.filtered_odometry)
            error=adjusted[:2]-self.filtered_odometry[:2]
            self.integral=np.clip(self.integral+.6*error*self.control_dt,-.20,.20)
            adjusted[:2]+=.7*error+self.integral
        else:self.integral[:]=0
        adjusted=np.clip(adjusted,[-.35,-.25,-.3],[.35,.25,.3])
        self.command+=np.clip(adjusted-self.command,-.005,.005)
        self.target=self.policy.infer(self.model,self.data,self.command)
        for _ in range(10):
            self.data.ctrl[self.policy.aids]=self.policy.kp*(self.target-self.data.qpos[self.policy.qids])-self.policy.kd*self.data.qvel[self.policy.vids]
            mujoco.mj_step(self.model,self.data)
        self.contact_active=False
        for c in self.data.contact:
            if any((self.model.geom(int(g)).name or '').startswith(('wall_','obstacle_')) for g in [c.geom1,c.geom2]):
                self.contacts+=1;self.contact_active=True

    def scan(self):
        psi=yaw_of(self.data.qpos[3:7]);origin=np.array([self.data.qpos[0],self.data.qpos[1],.8])
        ranges=[]
        for a in self.angles+psi:
            v=np.array([math.cos(a),math.sin(a),0.])
            distance=mujoco.mj_ray(self.model,self.data,origin,v,self.ray_group,1,-1,self.ray_id)
            ranges.append(float(np.clip((distance if distance>=0 else 20.)+self.rng.normal(0,self.noise),.05,20.)))
        R=self.data.xmat[self.policy.pelvis].reshape(3,3)
        # The body IMU uses ideal simulated angular velocity and gravity. The
        # scan is explicitly horizontal and instantaneous (teaching sensor).
        obs={'sim_time':float(self.data.time),'updated_wall':time.time(),'ranges':ranges,
             'angle_min':-math.pi,'angle_increment':2*math.pi/360,'range_min':.05,'range_max':20.,
             'scan_model':'virtual_horizontal_instantaneous_2d','angular_velocity':self.data.qvel[3:6].tolist(),
             'gravity_body':(R.T@np.array([0.,0.,-9.81])).tolist(),
             'joint_names':self.policy.names,'joint_positions':self.data.qpos[self.policy.qids].tolist(),
             'joint_velocities':self.data.qvel[self.policy.vids].tolist(),'physics_state':self.state,
             'obstacle_contact_count':self.contacts,'obstacle_contact_active':self.contact_active}
        self.last_scan=obs;return obs


class SimulationService:
    def __init__(self, session, realtime=True):
        self.session=Path(session);self.session.mkdir(parents=True,exist_ok=True)
        self.physics=Physics();self.lock=threading.Lock();self.quit=threading.Event();self.realtime=realtime
        self.error=None
        (self.session/'scene.xml').write_text(self.physics.xml)
        self.truth=(self.session/'evaluation_truth.csv').open('w',buffering=1)
        self.truth_writer=csv.writer(self.truth);self.truth_writer.writerow(['t','x','y','z','yaw'])
        self.observations=(self.session/'scans.jsonl').open('w',buffering=1)

    def loop(self):
        import json
        deadline=time.monotonic();count=0
        try:
            while not self.quit.is_set():
                control=read_json(self.session/'control.json',{})
                now=time.time()
                fresh=0<=now-control.get('created_wall',0)<.4
                desired=control.get('velocity',[0.,0.,0.]) if fresh else [0.,0.,0.]
                odom=read_json(self.session/'odometry.json',{})
                odom_v=odom.get('velocity') if 0<=now-odom.get('updated_wall',0)<.4 else None
                stop=read_json(self.session/'stop.json',{})
                if stop.get('created_wall',0)>control.get('created_wall',0):desired=[0.,0.,0.]
                with self.lock:
                    self.physics.step(desired,odom_v,odom.get('pose') if odom_v is not None else None)
                    if count%5==0:
                        obs=self.physics.scan();write_json(self.session/'observations.json',obs)
                        self.observations.write(json.dumps(obs,allow_nan=False)+'\n')
                        d=self.physics.data
                        self.truth_writer.writerow([d.time,*d.qpos[:3],yaw_of(d.qpos[3:7])])
                    count+=1
                if self.realtime:
                    deadline+=.02;delay=deadline-time.monotonic()
                    if delay>0:self.quit.wait(delay)
                    elif delay<-.5:deadline=time.monotonic()
                if self.physics.state=='FALLEN':self.quit.wait(.02)
        except Exception as exc:
            self.error=repr(exc);write_json(self.session/'simulation_error.json',{'error':self.error});self.quit.set()
            raise
        finally:self.truth.close();self.observations.close()

    def start(self):
        self.thread=threading.Thread(target=self.loop,daemon=True);self.thread.start()

def main():
    p=argparse.ArgumentParser();p.add_argument('--session',required=True);p.add_argument('--headless',action='store_true')
    p.add_argument('--fast',action='store_true');p.add_argument('--duration',type=float,default=0)
    args=p.parse_args();s=SimulationService(args.session,not args.fast);s.start()
    import signal
    signal.signal(signal.SIGTERM,lambda *_:s.quit.set());signal.signal(signal.SIGINT,lambda *_:s.quit.set())
    try:
        if args.headless:
            start=time.monotonic()
            while not s.quit.wait(.1):
                if args.duration and time.monotonic()-start>=args.duration:break
        else:
            from .gui import Window
            Window(s).run()
    finally:s.quit.set();s.thread.join(timeout=5)

if __name__=='__main__':main()
