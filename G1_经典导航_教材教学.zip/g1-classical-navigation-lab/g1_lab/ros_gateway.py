"""ROS 2 Humble bridge, map lifecycle, tool RPC and Nav2 task execution."""
import argparse
import hashlib
from copy import deepcopy
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import threading
import time
import uuid

import numpy as np
import yaml
import rclpy
from rclpy.node import Node
from rclpy.clock import Clock, ClockType
from rclpy.time import Time
from rclpy.executors import MultiThreadedExecutor
from rclpy.action import ActionClient
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, qos_profile_sensor_data
from builtin_interfaces.msg import Time as TimeMsg
from rosgraph_msgs.msg import Clock as ClockMsg
from sensor_msgs.msg import LaserScan, Imu, JointState
from geometry_msgs.msg import TransformStamped, Twist, PoseStamped, PoseWithCovarianceStamped, Point
from nav_msgs.msg import OccupancyGrid, Odometry, Path as NavPath
from nav2_msgs.msg import CostmapFilterInfo
from nav2_msgs.action import NavigateToPose, ComputePathToPose
from action_msgs.msg import GoalStatus
from visualization_msgs.msg import Marker, MarkerArray
from slam_toolbox.srv import SerializePoseGraph, DeserializePoseGraph
from tf2_ros import Buffer, TransformListener, StaticTransformBroadcaster, TransformBroadcaster

from .common import ROOT, read_json, write_json, quat, yaw, wrap, safe_id, finite, body_velocity_between
from .maps import Grid, MapStore


def stamp(t):
    sec,ns=divmod(int(round(t*1e9)),1000000000)
    return TimeMsg(sec=sec,nanosec=ns)

def wait_future(future, timeout=30):
    event=threading.Event();future.add_done_callback(lambda _:event.set())
    if not event.wait(timeout):raise TimeoutError('ROS 服务/Action 响应超时')
    if future.exception():raise future.exception()
    return future.result()


class Gateway(Node):
    def __init__(self, session, initial_map=None):
        super().__init__('g1_map_gateway')
        self.session=Path(session)
        for x in ['inbox','responses','tasks','snapshots']:(self.session/x).mkdir(parents=True,exist_ok=True)
        self.stop_event=threading.Event();self.lock=threading.RLock()
        self.mode='MAPPING';self.epoch=0;self.pose=None;self.pose_wall=0.;self.odom_wall=0.;self.amcl_wall=0.
        self.odom_velocity=[0.,0.,0.];self.previous_odom=None;self.current_scan=None;self.live_grid=None;self.graph=[]
        self.nav_velocity=[0.,0.,0.];self.nav_wall=0.;self.nav_lease=False
        self.last_obs_time=-1.;self.last_status=0.;self.last_masks=0.;self.last_stop=0.
        self.manual=False;self.block_held_keys=False;self.scans_paused=False;self.transitioning=False;self.task=None;self.task_cancel=threading.Event()
        self.goal_handle=None;self.tasks={};self.request_ids={};self.snapshots={};self.selections={}
        self.processes={};self.process_logs=[];self.errors=[];self.initial_map=initial_map
        self.failed_processes=set();self.rules_changed=0.;self.costmap_seen={'global':0.,'local':0.}
        self.contact_was_active=False
        self.store=MapStore(ROOT/'maps');self.keepout=None;self.speedmask=None;self.last_path=[]
        self.tf=Buffer();self.tf_listener=TransformListener(self.tf,self)
        self.static_tf=StaticTransformBroadcaster(self)
        self.dynamic_tf=TransformBroadcaster(self)
        tf=TransformStamped();tf.header.frame_id='base_footprint';tf.child_frame_id='laser'
        tf.transform.translation.z=.8;tf.transform.rotation.w=1.;self.static_tf.sendTransform(tf)
        self.laser_extrinsic=tf
        self.clock_pub=self.create_publisher(ClockMsg,'/clock',10)
        self.scan_pub=self.create_publisher(LaserScan,'/scan',qos_profile_sensor_data)
        self.imu_pub=self.create_publisher(Imu,'/imu/data',qos_profile_sensor_data)
        self.joint_pub=self.create_publisher(JointState,'/joint_states',qos_profile_sensor_data)
        self.initial_pub=self.create_publisher(PoseWithCovarianceStamped,'/initialpose',10)
        self.qos_map=QoSProfile(depth=1,reliability=ReliabilityPolicy.RELIABLE,durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.mask_pubs={x:self.create_publisher(OccupancyGrid,'/'+x+'_mask',self.qos_map) for x in ('keepout','speed')}
        self.info_pubs={x:self.create_publisher(CostmapFilterInfo,'/'+x+'_filter_info',self.qos_map) for x in ('keepout','speed')}
        self.semantic_pub=self.create_publisher(MarkerArray,'/semantic_markers',self.qos_map)
        self.odom_pub=self.create_publisher(Odometry,'/odom',10)
        self.create_subscription(Odometry,'/rf2o/odom',self.on_odom,qos_profile_sensor_data)
        self.create_subscription(OccupancyGrid,'/map',self.on_map,self.qos_map)
        self.create_subscription(Twist,'/cmd_vel',self.on_nav,1)
        self.create_subscription(PoseWithCovarianceStamped,'/amcl_pose',self.on_amcl,10)
        self.create_subscription(MarkerArray,'/slam_toolbox/graph_visualization',self.on_graph,10)
        self.create_subscription(NavPath,'/plan',self.on_path,10)
        for label in ('global','local'):
            self.create_subscription(OccupancyGrid,f'/{label}_costmap/costmap',lambda msg,lab=label:self.on_costmap(msg,lab),self.qos_map)
        self.serialize=self.create_client(SerializePoseGraph,'/slam_toolbox/serialize_map')
        self.navigate=ActionClient(self,NavigateToPose,'/navigate_to_pose')
        self.compute=ActionClient(self,ComputePathToPose,'/compute_path_to_pose')
        self.timer=self.create_timer(.02,self.tick,clock=Clock(clock_type=ClockType.STEADY_TIME))
        self.worker=threading.Thread(target=self.command_worker,daemon=True);self.worker.start()
        self.spawn('rf2o',['ros2','run','rf2o_laser_odometry','rf2o_laser_odometry_node','--ros-args',
            '-p','use_sim_time:=true','-p','laser_scan_topic:=/scan','-p','odom_topic:=/rf2o/odom',
            '-p','base_frame_id:=base_footprint','-p','odom_frame_id:=odom','-p','publish_tf:=true',
            '-p',"init_pose_from_topic:=''",'-p','freq:=10.0'])
        if initial_map:
            threading.Thread(target=self.start_saved,args=(initial_map,),daemon=True).start()
        else:self.start_slam()

    def spawn(self,name,args):
        if name in self.processes and self.processes[name].poll() is None:raise RuntimeError(f'{name} 已运行')
        log=(self.session/(name+'.log')).open('a',buffering=1);self.process_logs.append(log)
        self.processes[name]=subprocess.Popen(args,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)

    def stop_process(self,name):
        p=self.processes.pop(name,None)
        if p and p.poll() is None:
            os.killpg(p.pid,signal.SIGINT)
            try:p.wait(6)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid,signal.SIGTERM)
                try:p.wait(3)
                except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()

    def start_slam(self):
        self.failed_processes.discard('slam')
        self.spawn('slam',['ros2','launch','slam_toolbox','online_async_launch.py',
            'use_sim_time:=true','slam_params_file:='+str(ROOT/'config/slam.yaml')])

    def start_saved(self,bundle):
        try:
            time.sleep(2)
            self.load_map({'bundle':bundle,'initial_pose':[0.,0.,0.]})
        except Exception as exc:self.errors.append(str(exc));self.mode='STOPPED'

    def on_odom(self,msg):
        q=msg.pose.pose.orientation
        values=[msg.pose.pose.position.x,msg.pose.pose.position.y,q.x,q.y,q.z,q.w]
        if not np.isfinite(values).all() or abs(np.linalg.norm(values[2:])-1.)>.05:
            self.errors.append('里程计位姿无效');return
        pose=[values[0],values[1],yaw(values[2:])]
        sim_stamp=msg.header.stamp.sec+msg.header.stamp.nanosec*1e-9
        velocity=[0.,0.,0.]
        if self.previous_odom is not None:
            previous_stamp,previous_pose=self.previous_odom
            if sim_stamp<=previous_stamp:return
            try:velocity=body_velocity_between(previous_pose,pose,sim_stamp-previous_stamp)
            except ValueError:pass # Fresh pose after a gap; do not reuse a stale twist.
        self.previous_odom=(sim_stamp,pose)
        self.odom_wall=time.time()
        self.odom_velocity=velocity
        msg.twist.twist.linear.x,msg.twist.twist.linear.y,msg.twist.twist.angular.z=velocity
        self.odom_pub.publish(msg)
        write_json(self.session/'odometry.json',{'updated_wall':self.odom_wall,'velocity':self.odom_velocity,
            'pose':pose})

    def on_map(self,msg):
        q=msg.info.origin.orientation
        try:
            grid=Grid(np.asarray(msg.data).reshape(msg.info.height,msg.info.width),msg.info.resolution,
                [msg.info.origin.position.x,msg.info.origin.position.y,yaw([q.x,q.y,q.z,q.w])])
            self.live_grid=grid
            write_json(self.session/'map_view.json',{'data':grid.data.tolist(),'resolution':grid.resolution,'origin':grid.origin,'frame_id':msg.header.frame_id})
        except Exception as exc:self.errors.append('map: '+str(exc))

    def on_costmap(self,msg,label):
        self.costmap_seen[label]=time.time()
        q=msg.info.origin.orientation
        write_json(self.session/(label+'_costmap.json'),{'data':np.asarray(msg.data).reshape(msg.info.height,msg.info.width).tolist(),
            'resolution':msg.info.resolution,'origin':[msg.info.origin.position.x,msg.info.origin.position.y,yaw([q.x,q.y,q.z,q.w])],
            'frame_id':msg.header.frame_id})

    def on_nav(self,msg):
        self.nav_velocity=[msg.linear.x,msg.linear.y,msg.angular.z];self.nav_wall=time.time()

    def on_amcl(self,msg):
        self.amcl_wall=time.time()
        self.amcl_covariance=[msg.pose.covariance[i] for i in (0,7,35)]

    def on_graph(self,msg):
        self.graph=[{'id':m.id,'ns':m.ns,'type':m.type,'position':[m.pose.position.x,m.pose.position.y],
                     'points':[[p.x,p.y] for p in m.points]} for m in msg.markers if m.action!=Marker.DELETEALL]
        write_json(self.session/'pose_graph_markers.json',self.graph)

    def on_path(self,msg):self.last_path=[[p.pose.position.x,p.pose.position.y] for p in msg.poses]

    def estimated_pose(self):
        t=self.tf.lookup_transform('map','base_footprint',Time())
        age=self.last_obs_time-(t.header.stamp.sec+t.header.stamp.nanosec*1e-9)
        if not -1.<=age<=.6:raise ValueError('定位 TF 已过期')
        q=t.transform.rotation
        return [t.transform.translation.x,t.transform.translation.y,yaw([q.x,q.y,q.z,q.w])]

    def sensor_tick(self):
        obs=read_json(self.session/'observations.json')
        if not obs or time.time()-obs.get('updated_wall',0)>1:return
        if obs['sim_time']==self.last_obs_time:return
        if obs['sim_time']<self.last_obs_time:
            self.cancel('SIMULATION_TIME_RESET');self.mode='STOPPED';self.errors.append('仿真时间回退，请重启本次会话')
        self.last_obs_time=obs['sim_time'];self.current_scan=obs
        t=stamp(obs['sim_time']);clock=ClockMsg();clock.clock=t;self.clock_pub.publish(clock)
        if self.scans_paused:return
        scan=LaserScan();scan.header.frame_id='laser';scan.header.stamp=t
        scan.angle_min=float(obs['angle_min']);scan.angle_increment=float(obs['angle_increment'])
        scan.angle_max=scan.angle_min+scan.angle_increment*(len(obs['ranges'])-1)
        scan.range_min=float(obs['range_min']);scan.range_max=float(obs['range_max']);scan.scan_time=.1;scan.time_increment=0.
        scan.ranges=[float(x) for x in obs['ranges']];self.scan_pub.publish(scan)
        imu=Imu();imu.header.frame_id='pelvis';imu.header.stamp=t;imu.orientation_covariance[0]=-1.
        imu.angular_velocity.x,imu.angular_velocity.y,imu.angular_velocity.z=obs['angular_velocity']
        imu.linear_acceleration.x,imu.linear_acceleration.y,imu.linear_acceleration.z=[-x for x in obs['gravity_body']]
        # Gravity-only teaching IMU; not a full specific-force model for LIO.
        self.imu_pub.publish(imu)
        gx,gy,gz=obs['gravity_body'];roll=math.atan2(-gy,-gz);pitch=math.atan2(gx,math.hypot(gy,gz))
        body=TransformStamped();body.header.frame_id='base_footprint';body.child_frame_id='pelvis';body.header.stamp=t
        body.transform.translation.z=.73
        sr,cr=math.sin(roll/2),math.cos(roll/2);sp,cp=math.sin(pitch/2),math.cos(pitch/2)
        body.transform.rotation.x=sr*cp;body.transform.rotation.y=cr*sp;body.transform.rotation.z=-sr*sp;body.transform.rotation.w=cr*cp
        self.dynamic_tf.sendTransform(body)
        js=JointState();js.header.stamp=t;js.name=obs['joint_names'];js.position=obs['joint_positions'];js.velocity=obs['joint_velocities'];self.joint_pub.publish(js)

    def local_stop(self):
        obj=read_json(self.session/'stop.json',{})
        ts=obj.get('created_wall',0)
        if ts>self.last_stop:
            self.last_stop=ts;self.cancel('LOCAL_STOP')

    def tick(self):
        try:
            self.sensor_tick();self.local_stop();now=time.time()
            for name,process in list(self.processes.items()):
                if process.poll() is not None and name not in self.failed_processes:
                    self.failed_processes.add(name);self.cancel('ROS_COMPONENT_EXITED');self.mode='STOPPED';self.errors.append(name+' 已退出，检查对应日志')
            try:self.pose=self.estimated_pose();self.pose_wall=now
            except Exception:pass
            teleop=read_json(self.session/'teleop.json',{})
            active=teleop.get('active',False) and 0<=now-teleop.get('created_wall',0)<.3
            if not active:self.block_held_keys=False
            if self.block_held_keys:active=False
            if active and not self.manual:
                self.cancel('MANUAL_OVERRIDE');self.manual=True
            elif not active:self.manual=False
            velocity=[0.,0.,0.]
            if active and not self.transitioning and self.mode not in ('LOCALIZING','STOPPED'):
                velocity=teleop.get('velocity',velocity)
            elif self.nav_lease and self.mode=='NAVIGATING' and not self.task_cancel.is_set() and 0<=now-self.nav_wall<.3:
                velocity=self.nav_velocity
            if self.current_scan and self.current_scan['physics_state']=='FALLEN':
                if self.mode!='STOPPED':self.cancel('ROBOT_FALLEN')
                self.mode='STOPPED';velocity=[0.,0.,0.]
            contact=bool((self.current_scan or {}).get('obstacle_contact_active'))
            if contact and not self.contact_was_active:self.cancel('PHYSICAL_CONTACT');velocity=[0.,0.,0.]
            self.contact_was_active=contact
            if now-self.odom_wall>.5 or (self.mode in ('READY','NAVIGATING') and now-self.pose_wall>.5):
                velocity=[0.,0.,0.]
            velocity=self.constrain_velocity(velocity)
            write_json(self.session/'control.json',{'created_wall':now,'velocity':velocity,'epoch':self.epoch,'source':'manual' if active else 'nav2'})
            if now-self.last_status>.1:
                write_json(self.session/'status.json',self.status());self.last_status=now
            if self.store.grid is not None and now-self.last_masks>2:
                self.publish_maps();self.last_masks=now
        except Exception as exc:
            self.errors.append(str(exc));write_json(self.session/'control.json',{'created_wall':time.time(),'velocity':[0.,0.,0.]})

    def constrain_velocity(self,v):
        v=np.asarray(v,dtype=float)
        if v.shape!=(3,) or not np.isfinite(v).all():return [0.,0.,0.]
        v=np.clip(v,[-.2,-.2,-.3],[.3,.2,.3]);norm=np.linalg.norm(v[:2])
        if norm>.3:v[:2]*=.3/norm
        if self.store.grid is not None:
            if self.pose is None or time.time()-self.pose_wall>.5:return [0.,0.,0.]
            ix,iy=self.store.grid.cell(*self.pose[:2]);g=self.store.grid
            if not (0<=ix<g.w and 0<=iy<g.h):return [0.,0.,0.]
            if self.speedmask is not None:
                limit=self.speedmask[iy,ix]*.01
                if limit and norm>limit:v[:2]*=limit/max(norm,1e-9)
            if self.keepout is not None:
                theta=self.pose[2];c=math.cos(theta);s=math.sin(theta)
                # Check a stopping horizon on the already expanded rule mask.
                for dt in np.linspace(0,1.0,11):
                    px=self.pose[0]+dt*(c*v[0]-s*v[1]);py=self.pose[1]+dt*(s*v[0]+c*v[1]);cx,cy=g.cell(px,py)
                    if not (0<=cx<g.w and 0<=cy<g.h) or self.keepout[cy,cx]>0:return [0.,0.,0.]
        return v.tolist()

    def status(self):
        return {'running':not self.stop_event.is_set(),'updated_wall':time.time(),'mode':self.mode,'epoch':self.epoch,
            'estimated_pose':self.pose,'pose_fresh':self.pose is not None and time.time()-self.pose_wall<.5,
            'odometry_velocity':self.odom_velocity,'odometry_fresh':time.time()-self.odom_wall<.5,
            'physics_state':(self.current_scan or {}).get('physics_state','STARTING'),
            'obstacle_contact_count':(self.current_scan or {}).get('obstacle_contact_count',0),
            'sim_time':self.last_obs_time,'versions':self.store.versions(),
            'active_task':deepcopy(self.task),'places':self.store.query(),
            'regions':deepcopy(self.store.document['regions']) if self.store.document else [],
            'objects':deepcopy(self.store.document['objects']) if self.store.document else [],
            'topology':deepcopy(self.store.document['topology']) if self.store.document else {},
            'path':self.last_path,'latest_snapshot':next(reversed(self.snapshots),None),
            'latest_selection':next(reversed(self.selections),None),'errors':self.errors[-5:],
            'processes':{k:v.poll() for k,v in self.processes.items()},
            'backend':'ROS2 Humble / RF2O / SLAM Toolbox or AMCL / Nav2',
            'sensor_model':'virtual horizontal 2D scan; ideal gravity/gyro for existing policy'}

    def cancel(self,reason='USER_CANCELLED'):
        self.epoch+=1;self.nav_lease=False;self.task_cancel.set();self.nav_velocity=[0.,0.,0.]
        if reason!='MANUAL_OVERRIDE':self.block_held_keys=True
        if self.task and self.task.get('status') in ('QUEUED','RUNNING'):self.task['cancel_reason']=reason
        if self.goal_handle is not None:
            try:self.goal_handle.cancel_goal_async()
            except Exception:pass
        if self.mode=='NAVIGATING':self.mode='READY'
        write_json(self.session/'control.json',{'created_wall':time.time(),'velocity':[0.,0.,0.],'epoch':self.epoch})
        return {'status':'STOPPING','reason':reason,'epoch':self.epoch}

    def capture(self,params):
        self.store.require(params.get('expected_versions'))
        if self.mode!='READY' or self.pose is None or time.time()-self.odom_wall>.5 or time.time()-self.pose_wall>.5:raise ValueError('请先加载地图并完成定位')
        if math.hypot(*self.odom_velocity[:2])>.06 or abs(self.odom_velocity[2])>.08 or self.manual:raise ValueError('请先松开键盘，等待机器人停稳')
        token=uuid.uuid4().hex[:16]
        item={'snapshot_id':token,'pose':list(self.pose),'versions':self.store.versions(),'created_wall':time.time()}
        self.snapshots[token]=item;write_json(self.session/'snapshots'/(token+'.json'),item);return item

    def save_map(self,params):
        if self.mode!='MAPPING':raise ValueError('仅建图模式可以保存新的几何地图版本')
        name=safe_id(params.get('name','lab_floor_1'));self.cancel('MAP_FREEZE');self.transitioning=True
        try:
            deadline=time.monotonic()+15;stable=0
            while time.monotonic()<deadline:
                if time.time()-self.odom_wall<.5 and math.hypot(*self.odom_velocity[:2])<.06 and abs(self.odom_velocity[2])<.08:stable+=1
                else:stable=0
                if stable>=10:break
                time.sleep(.1)
            else:raise ValueError('未确认里程计反馈下的停稳状态，未保存')
            self.scans_paused=True;time.sleep(1.5)
            if self.live_grid is None or self.pose is None:raise ValueError('尚未得到 SLAM 地图和位姿')
            if not self.serialize.wait_for_service(timeout_sec=5):raise RuntimeError('SLAM 序列化服务不可用')
            grid=Grid(self.live_grid.data.copy(),self.live_grid.resolution,list(self.live_grid.origin))
            bundle=self.store.create(name,grid);(bundle/'slam').mkdir()
            req=SerializePoseGraph.Request();req.filename=str(bundle/'slam/session')
            result=wait_future(self.serialize.call_async(req),30)
            if result.result!=0:raise RuntimeError('位姿图保存失败，地图包保持未完成状态')
            if not (bundle/'slam/session.posegraph').exists() or not (bundle/'slam/session.data').exists():
                raise RuntimeError('未发现完整的位姿图和数据文件')
            write_json(bundle/'slam/markers.json',self.graph)
            m=read_json(bundle/'manifest.json');m.update(complete=True,saved_pose=list(self.pose),session=str(self.session),
                 sensor_model='virtual_horizontal_2d',native_graph_saved=True)
            for file in (bundle/'slam').iterdir():m['file_hashes'][str(file.relative_to(bundle))]=hashlib.sha256(file.read_bytes()).hexdigest()
            write_json(bundle/'manifest.json',m)
            write_json(self.session/'last_saved_map.json',{'bundle':str(bundle)})
            return {'status':'SAVED','bundle':str(bundle),'manifest':m,'next':'加载此地图，开始定位和语义标注'}
        finally:self.scans_paused=False;self.transitioning=False

    def load_map(self,params):
        bundle=params.get('bundle')
        if not bundle:
            last=read_json(self.session/'last_saved_map.json',{});bundle=last.get('bundle')
        if not bundle:raise ValueError('未指定地图包；请先保存地图')
        candidate=MapStore(ROOT/'maps');manifest=candidate.activate(bundle)
        initial=params.get('initial_pose')
        if initial is None:
            m=candidate.manifest
            initial=m.get('saved_pose',[0.,0.,0.]) if m.get('session')==str(self.session) else [0.,0.,0.]
        if not isinstance(initial,list) or len(initial)!=3:raise ValueError('初始位姿需要 x,y,yaw 三个值')
        initial=[finite(x,-1000,1000) for x in initial];initial[2]=wrap(initial[2])
        self.cancel('MAP_LOAD');self.transitioning=True;self.mode='LOCALIZING'
        try:
            self.stop_process('slam');self.stop_process('nav2')
            self.store=candidate;self.pose=None;self.pose_wall=0.;self.amcl_wall=0.
            self.tf.clear();self.keepout,self.speedmask=self.store.masks(save=True);self.publish_maps()
            self.static_tf.sendTransform(self.laser_extrinsic);self.failed_processes.discard('nav2')
            self.spawn('nav2',['ros2','launch','nav2_bringup','bringup_launch.py',
                'slam:=False','use_sim_time:=True','use_composition:=False','autostart:=True',
                'map:='+str(self.store.bundle/'occupancy/map.yaml'),'params_file:='+str(ROOT/'config/nav2.yaml')])
            start=time.monotonic()
            while time.monotonic()-start<75:
                if self.stop_event.is_set():raise RuntimeError('会话结束')
                self.publish_initial(initial)
                if self.navigate.wait_for_server(timeout_sec=1.) and self.pose is not None and self.amcl_wall>0 and time.time()-self.odom_wall<.5:
                    self.mode='READY';return {'status':'READY','versions':manifest,'initial_pose':initial}
                time.sleep(1.)
            raise TimeoutError('Nav2/AMCL 未在 75 秒内就绪；请检查 nav2.log，并在 RViz 设置初始位姿')
        except Exception:
            self.mode='STOPPED';raise
        finally:self.transitioning=False

    def resume_mapping(self,params):
        if self.mode!='READY' or not self.pose or time.time()-self.pose_wall>.5:raise ValueError('请先加载地图并完成定位')
        source=self.store.bundle;pose=list(self.pose)
        MapStore(ROOT/'maps').activate(source)
        self.cancel('RESUME_MAPPING');self.transitioning=True;self.mode='LOCALIZING'
        try:
            self.stop_process('nav2');self.store=MapStore(ROOT/'maps');self.keepout=None;self.speedmask=None
            self.tf.clear();self.static_tf.sendTransform(self.laser_extrinsic);self.start_slam()
            client=self.create_client(DeserializePoseGraph,'/slam_toolbox/deserialize_map')
            try:
                if not client.wait_for_service(timeout_sec=15):raise RuntimeError('恢复建图服务不可用')
                req=DeserializePoseGraph.Request();req.filename=str(source/'slam/session');req.match_type=2
                req.initial_pose.x=pose[0];req.initial_pose.y=pose[1];req.initial_pose.theta=pose[2]
                wait_future(client.call_async(req),30)
            finally:self.destroy_client(client)
            self.mode='MAPPING';self.pose=None;self.pose_wall=0.;self.snapshots.clear();self.selections.clear()
            return {'status':'MAPPING','source_bundle':str(source),'note':'继续键盘建图；保存为新几何版本后重新审核语义标注。'}
        except Exception:self.mode='STOPPED';raise
        finally:self.transitioning=False

    def publish_initial(self,pose):
        m=PoseWithCovarianceStamped();m.header.frame_id='map';m.header.stamp=self.get_clock().now().to_msg()
        m.pose.pose.position.x=float(pose[0]);m.pose.pose.position.y=float(pose[1]);q=quat(pose[2])
        m.pose.pose.orientation.x,m.pose.pose.orientation.y,m.pose.pose.orientation.z,m.pose.pose.orientation.w=q
        m.pose.covariance[0]=.16;m.pose.covariance[7]=.16;m.pose.covariance[35]=.07;self.initial_pub.publish(m)

    def pose_msg(self,p):
        m=PoseStamped();m.header.frame_id='map';m.header.stamp=self.get_clock().now().to_msg()
        m.pose.position.x=float(p[0]);m.pose.position.y=float(p[1]);q=quat(p[2] if len(p)>2 else 0.)
        m.pose.orientation.x,m.pose.orientation.y,m.pose.orientation.z,m.pose.orientation.w=q
        return m

    def get_path(self,goal,start=None):
        if not self.compute.wait_for_server(timeout_sec=3):raise RuntimeError('Nav2 路径查询不可用')
        req=ComputePathToPose.Goal();req.goal=self.pose_msg(goal);req.planner_id='GridBased';req.use_start=start is not None
        if start is not None:req.start=self.pose_msg(start)
        handle=wait_future(self.compute.send_goal_async(req),10)
        if not handle.accepted:raise ValueError('路径查询被拒绝')
        result=wait_future(handle.get_result_async(),15)
        if result.status!=GoalStatus.STATUS_SUCCEEDED or not result.result.path.poses:raise ValueError('NO_PATH：当前地图与规则下不可达')
        return [[p.pose.position.x,p.pose.position.y] for p in result.result.path.poses]

    def submit(self,params,epoch):
        request_id=params.get('request_id') or uuid.uuid4().hex
        if request_id in self.request_ids:
            task=self.tasks[self.request_ids[request_id]]
            if params.get('goal_ids')!=task.get('request_goal_ids'):raise ValueError('REQUEST_ID_CONFLICT')
            return deepcopy(task)
        if self.mode!='READY' or self.manual or self.transitioning:raise ValueError('请先加载地图并结束手动控制')
        if self.task and self.task['status'] in ('QUEUED','RUNNING'):raise ValueError('已有任务，请先取消或等待完成')
        self.store.require(params.get('expected_versions'))
        if time.time()-self.odom_wall>.5 or time.time()-self.pose_wall>.5:raise ValueError('定位或里程计已过期')
        if time.time()-self.rules_changed<3 or min(self.costmap_seen.values())<self.rules_changed:raise ValueError('规则地图正在更新，请稍后重试')
        ids=params.get('goal_ids',[])
        if not isinstance(ids,list) or not 1<=len(ids)<=12:raise ValueError('任务需要 1–12 个已标注地点')
        goals=[self.store.resolve(x) for x in ids]
        self.get_path(goals[0]['approach_pose'])
        if epoch!=self.epoch or self.manual or self.mode!='READY':raise ValueError('路径查询期间控制权发生变化，未提交旧任务')
        task={'task_id':uuid.uuid4().hex,'status':'QUEUED','goal_ids':[g['id'] for g in goals],
              'goal_names':[g['name'] for g in goals],'versions':self.store.versions(),'completed':0,'epoch':epoch}
        task['request_goal_ids']=list(ids)
        self.task=task;self.tasks[task['task_id']]=task;self.request_ids[request_id]=task['task_id']
        self.task_cancel=threading.Event();self.mode='NAVIGATING'
        threading.Thread(target=self.run_mission,args=(task,goals,self.task_cancel),daemon=True).start()
        return deepcopy(task)

    def run_mission(self,task,goals,cancel):
        try:
            task['status']='RUNNING'
            for i,place in enumerate(goals):
                if cancel.is_set() or self.epoch!=task['epoch']:raise InterruptedError('任务被停止或手动接管')
                self.store.require(task['versions']);self.get_path(place['approach_pose'])
                req=NavigateToPose.Goal();req.pose=self.pose_msg(place['approach_pose'])
                handle=wait_future(self.navigate.send_goal_async(req),10)
                if not handle.accepted:raise RuntimeError('Nav2 拒绝任务')
                self.goal_handle=handle
                if cancel.is_set():handle.cancel_goal_async();raise InterruptedError('任务已取消')
                self.nav_lease=True;result_future=handle.get_result_async();started=time.monotonic()
                while not result_future.done():
                    if cancel.wait(.1) or self.epoch!=task['epoch']:
                        handle.cancel_goal_async();raise InterruptedError('任务被停止或手动接管')
                    if time.monotonic()-started>240:handle.cancel_goal_async();raise TimeoutError('单段导航超时')
                    if self.pose:task['remaining_distance_m']=math.dist(self.pose[:2],place['approach_pose'][:2])
                result=result_future.result();self.nav_lease=False
                if result.status!=GoalStatus.STATUS_SUCCEEDED:raise RuntimeError(f'Nav2 结束状态 {result.status}')
                stable=0;deadline=time.monotonic()+8
                while time.monotonic()<deadline:
                    if cancel.wait(.1):raise InterruptedError('任务已取消')
                    good=self.pose is not None and time.time()-self.odom_wall<.5 and math.dist(self.pose[:2],place['approach_pose'][:2])<=.30 and abs(wrap(self.pose[2]-place['approach_pose'][2]))<=.22 and math.hypot(*self.odom_velocity[:2])<.06
                    stable=stable+1 if good else 0
                    if stable>=5:break
                else:raise RuntimeError('Nav2 返回到达，但估计位姿/停稳复核未通过')
                task['completed']=i+1
            if cancel.is_set() or self.epoch!=task['epoch']:raise InterruptedError('任务已取消')
            task.update(status='SUCCEEDED',reason='Nav2 success plus estimated pose and settling checks')
        except InterruptedError as exc:
            reason=task.get('cancel_reason',str(exc))
            task.update(status='FAILED' if reason in ('PHYSICAL_CONTACT','ROBOT_FALLEN','ROS_COMPONENT_EXITED') else 'CANCELLED',reason=reason)
        except Exception as exc:task.update(status='FAILED',reason=str(exc))
        finally:
            self.nav_lease=False;self.goal_handle=None
            if self.mode=='NAVIGATING':self.mode='READY'
            task['finished_wall']=time.time();task['final_estimated_pose']=self.pose
            write_json(self.session/'tasks'/(task['task_id']+'.json'),task)

    def publish_maps(self):
        if self.store.grid is None:return
        grid=self.store.grid
        for label,arr in [('keepout',self.keepout),('speed',self.speedmask)]:
            if arr is None:continue
            msg=OccupancyGrid();msg.header.frame_id='map';msg.header.stamp=self.get_clock().now().to_msg()
            msg.info.resolution=grid.resolution;msg.info.width=grid.w;msg.info.height=grid.h
            msg.info.origin.position.x=grid.origin[0];msg.info.origin.position.y=grid.origin[1]
            q=quat(grid.origin[2]);msg.info.origin.orientation.z=q[2];msg.info.origin.orientation.w=q[3]
            msg.data=arr.astype(np.int8).ravel().tolist();self.mask_pubs[label].publish(msg)
            info=CostmapFilterInfo();info.header=msg.header;info.type=0 if label=='keepout' else 2
            info.filter_mask_topic='/'+label+'_mask';info.base=0.;info.multiplier=1. if label=='keepout' else .01
            self.info_pubs[label].publish(info)
        markers=MarkerArray();clear=Marker();clear.action=Marker.DELETEALL;markers.markers.append(clear)
        for i,p in enumerate(self.store.query()):
            m=Marker();m.header.frame_id='map';m.header.stamp=self.get_clock().now().to_msg();m.id=i;m.ns='places'
            m.type=Marker.TEXT_VIEW_FACING;m.action=Marker.ADD;m.pose.position.x=p['approach_pose'][0];m.pose.position.y=p['approach_pose'][1]
            m.pose.position.z=.3;m.pose.orientation.w=1.;m.scale.z=.25;m.color.r=.2;m.color.g=1.;m.color.b=.7;m.color.a=1.;m.text=p['name'];markers.markers.append(m)
        for i,r in enumerate(self.store.document['regions']):
            m=Marker();m.header.frame_id='map';m.id=i;m.ns='regions';m.type=Marker.LINE_STRIP;m.action=Marker.ADD;m.pose.orientation.w=1.;m.scale.x=.04
            m.color.r=1.;m.color.g=.3 if r['kind']=='keepout' else .8;m.color.b=.5;m.color.a=1.
            m.points=[Point(x=float(x),y=float(y),z=.05) for x,y in r['polygon']+[r['polygon'][0]]];markers.markers.append(m)
        self.semantic_pub.publish(markers)

    def dispatch(self,op,p,epoch):
        readonly=('status','mapping_status','semantic_query','mission_status','map_list')
        if op not in readonly+('mission_cancel',) and epoch!=self.epoch:raise ValueError('STALE_CONTROL_EPOCH：控制权已变化，请重新发送')
        if op in ('status','mapping_status'):return self.status()
        if op=='mission_cancel':return self.cancel()
        if op=='mission_status':return deepcopy(self.tasks.get(p.get('task_id'),self.task))
        if op=='map_list':return [{'bundle':str(f.parent),**read_json(f)} for f in (ROOT/'maps').glob('*/rev_*/manifest.json') if read_json(f,{}).get('complete')]
        if op=='map_freeze_save':return self.save_map(p)
        if op=='map_load':return self.load_map(p)
        if op=='mapping_resume':return self.resume_mapping(p)
        if op=='pose_capture':return self.capture(p)
        if op=='selection_set':
            self.store.require(p.get('expected_versions'));kind=p.get('kind','polygon');coords=p.get('coordinates')
            if kind=='polygon':self.store.grid.polygon(coords)
            elif kind=='pose':
                if not isinstance(coords,list) or len(coords)!=3:raise ValueError('位姿选择需要 x y yaw')
                coords=[finite(v,-1000,1000) for v in coords]
            else:raise ValueError('选区类型无效')
            token=uuid.uuid4().hex[:16];self.selections[token]={'kind':kind,'coordinates':coords,'versions':self.store.versions()}
            return {'selection_id':token,**self.selections[token]}
        if op=='semantic_query':return {'places':self.store.query(p.get('query','')),'regions':self.store.document['regions'] if self.store.document else [],'objects':self.store.document['objects'] if self.store.document else [],'versions':self.store.versions()}
        if op=='semantic_add_place':
            token=p.get('snapshot_id');selection=p.get('selection_id')
            if token:
                item=self.snapshots.get(token)
                if not item:raise ValueError('未知位姿快照')
                pose=item['pose'];version=item['versions']
            elif selection:
                item=self.selections.get(selection)
                if not item or item['kind']!='pose':raise ValueError('请选择一个目标位姿')
                pose=item['coordinates'];version=item['versions'];token=selection
            else:raise ValueError('需要本地采集的 snapshot_id 或编辑器 selection_id')
            # Geometric binding survives unrelated semantic changes, not map changes.
            self.store.require({k:version[k] for k in ('map_id','geometry_revision','geometry_hash')})
            if self.mode!='READY':raise ValueError('请先结束当前运动任务')
            self.get_path(pose)
            return self.store.add_place(p['name'],p.get('aliases',[]),pose,token,p.get('expected_versions'))
        if op=='semantic_set_region':
            item=self.selections.get(p.get('selection_id'))
            if not item or item['kind']!='polygon':raise ValueError('请选择一个多边形区域')
            self.store.require({k:item['versions'][k] for k in ('map_id','geometry_revision','geometry_hash')})
            self.cancel('MAP_RULES_UPDATED')
            self.rules_changed=time.time()
            result=self.store.region(p['name'],p['kind'],item['coordinates'],p.get('max_linear_mps'))
            self.keepout,self.speedmask=self.store.masks();self.publish_maps();return result
        if op=='semantic_remove':
            self.cancel('MAP_EDIT');self.rules_changed=time.time();self.store.remove(p['id']);self.keepout,self.speedmask=self.store.masks();self.publish_maps();return {'removed':p['id']}
        if op=='semantic_add_object':
            selection=self.selections.get(p.get('selection_id'))
            if not selection or selection['kind']!='pose':raise ValueError('请先在地图选择对象位置')
            self.store.require({k:selection['versions'][k] for k in ('map_id','geometry_revision','geometry_hash')})
            return self.store.add_object(p['name'],selection['coordinates'],p['approach_place_id'],p.get('room_id'))
        if op=='semantic_connect':
            a=self.store.resolve(p['from_id']);b=self.store.resolve(p['to_id']);path=self.get_path(b['approach_pose'],a['approach_pose'])
            return self.store.connect(a['id'],b['id'],path)
        if op=='mission_submit':return self.submit(p,epoch)
        if op=='initial_pose':self.publish_initial([finite(v,-1000,1000) for v in p['pose']]);return {'status':'INITIAL_POSE_SENT'}
        raise ValueError('未知操作 '+op)

    def command_worker(self):
        while not self.stop_event.wait(.04):
            for file in sorted((self.session/'inbox').glob('*.json')):
                req=None
                try:
                    req=read_json(file)
                    if not isinstance(req,dict):raise ValueError('请求必须是 JSON 对象')
                    if req['id']!=file.stem or not 0<=time.time()-req['created_wall']<15:raise ValueError('请求已过期或 ID 不匹配')
                    result=self.dispatch(req['operation'],req.get('parameters',{}),req.get('epoch'))
                    reply={'ok':True,'result':result}
                except Exception as exc:reply={'ok':False,'error':str(exc)}
                write_json(self.session/'responses'/file.name,reply)
                with (self.session/'rpc_audit.jsonl').open('a') as f:f.write(json.dumps({'operation':req.get('operation') if isinstance(req,dict) else None,'response':reply,'wall':time.time()},ensure_ascii=False)+'\n')
                file.unlink(missing_ok=True)

    def close(self):
        self.stop_event.set();self.cancel('SESSION_CLOSED')
        for name in list(self.processes):self.stop_process(name)
        write_json(self.session/'status.json',self.status())
        for log in self.process_logs:log.close()


def main():
    p=argparse.ArgumentParser();p.add_argument('--session',required=True);p.add_argument('--map')
    a,rosargs=p.parse_known_args();rclpy.init(args=rosargs)
    node=Gateway(a.session,a.map);executor=MultiThreadedExecutor(num_threads=4);executor.add_node(node)
    try:executor.spin()
    except KeyboardInterrupt:pass
    finally:
        node.close();executor.shutdown(timeout_sec=3);node.destroy_node()
        if rclpy.ok():rclpy.shutdown()

if __name__=='__main__':main()
