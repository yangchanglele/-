"""Consistent Simplified Chinese fonts for every Tk/ttk surface."""
from .tk_backend import prepare_tk
prepare_tk()
import tkinter as tk
from tkinter import font as tkfont, ttk

CJK_FAMILIES=('Noto Sans CJK SC','Source Han Sans SC','Source Han Sans CN',
              'WenQuanYi Micro Hei','WenQuanYi Zen Hei','Microsoft YaHei',
              'SimHei','Droid Sans Fallback')

MODE_LABELS={'MAPPING':'手动建图','LOCALIZING':'正在定位','READY':'就绪',
             'NAVIGATING':'正在导航','STOPPED':'已停止'}
OPERATION_LABELS={'map_freeze_save':'保存地图与位姿图','map_load':'加载地图并定位',
    'mapping_resume':'恢复手动建图','pose_capture':'采集当前位置',
    'semantic_add_place':'保存地点','semantic_remove':'删除标注',
    'semantic_connect':'校验拓扑连接','mission_submit':'提交导航任务',
    'selection_set':'保存地图选区','semantic_set_region':'保存区域规则'}

def configure_fonts(root):
    available={name.casefold():name for name in tkfont.families(root)}
    family=next((available[name.casefold()] for name in CJK_FAMILIES if name.casefold() in available),None)
    if family is None:
        raise RuntimeError('系统 Tk 未找到中文字体；请运行 scripts/install_dependencies.sh，安装字体后重新启动。')
    # Named fonts also cover dialogs, legacy Listbox widgets and combo popups.
    for name in tkfont.names(root):
        if name.startswith('Tk'):
            tkfont.nametofont(name,root=root).configure(family=family,size=12)
    fonts={name:tkfont.Font(root=root,name='G1'+name+'Font',family=family,size=size,weight=weight)
           for name,size,weight in [('Body',12,'normal'),('Small',11,'normal'),
               ('Heading',12,'bold'),('Title',20,'bold'),('Map',12,'bold'),('Empty',16,'normal')]}
    root.option_add('*Font',str(fonts['Body']))
    root.option_add('*TCombobox*Listbox.font',str(fonts['Body']))
    root.option_add('*Listbox.font',str(fonts['Body']))
    style=ttk.Style(root);style.theme_use('clam')
    style.configure('.',font=fonts['Body'])
    style.configure('TFrame',background='#102137')
    style.configure('TLabel',background='#102137',foreground='#edf4fc',font=fonts['Body'])
    style.configure('TButton',font=fonts['Body'],padding=(10,7),foreground='#edf4fc',background='#274660')
    style.map('TButton',background=[('active','#355d7c'),('pressed','#1d354c')],foreground=[('disabled','#a0b0c0')])
    for name in ('TEntry','TCombobox','TSpinbox'):
        style.configure(name,font=fonts['Body'],padding=5,foreground='#f1f6fc',fieldbackground='#192d44')
        style.map(name,fieldbackground=[('readonly','#192d44')],foreground=[('readonly','#f1f6fc')])
    style.configure('TLabelframe',background='#102137',bordercolor='#385670')
    style.configure('TLabelframe.Label',font=fonts['Heading'],foreground='#8ce7c7',background='#102137')
    return fonts,family

class ScrollPanel(ttk.Frame):
    """Keep controls accessible when the display is short or text is scaled."""
    def __init__(self,parent,width=666):
        super().__init__(parent)
        self.canvas=tk.Canvas(self,width=width,background='#102137',highlightthickness=0)
        bar=ttk.Scrollbar(self,orient='vertical',command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=bar.set)
        bar.pack(side='right',fill='y');self.canvas.pack(side='left',fill='both',expand=True)
        self.content=ttk.Frame(self.canvas)
        self.window=self.canvas.create_window(0,0,anchor='nw',window=self.content)
        self.content.bind('<Configure>',lambda _:self.canvas.configure(scrollregion=self.canvas.bbox('all')))
        self.canvas.bind('<Configure>',lambda e:self.canvas.itemconfigure(self.window,width=e.width))
        self.wheel_tag='G1Scroll'+str(id(self))
        self.bind_class(self.wheel_tag,'<Button-4>',lambda e:self.scroll(-1))
        self.bind_class(self.wheel_tag,'<Button-5>',lambda e:self.scroll(1))
        self.bind_class(self.wheel_tag,'<MouseWheel>',lambda e:self.scroll(-1 if e.delta>0 else 1))

    def enable_wheel(self):
        def visit(widget):
            # Entry/dropdown/list scrolling keeps its normal editing behavior.
            if widget.winfo_class() not in ('Entry','TEntry','TCombobox','TSpinbox','Listbox'):
                widget.bindtags((self.wheel_tag,*widget.bindtags()))
            for child in widget.winfo_children():visit(child)
        visit(self.content)

    def scroll(self,steps):
        if self.canvas.yview()!=(0.0,1.0):self.canvas.yview_scroll(steps*3,'units')
        return 'break'
