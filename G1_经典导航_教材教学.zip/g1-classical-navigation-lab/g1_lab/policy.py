"""CPU MuJoCo G1-23DoF validation. Uses actual joint torques and physics.

No root-pose writes after initialization. Community policies, never mislabeled
as Unitree-issued 23DoF pretrained weights. See asset provenance in report.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
import time
import xml.etree.ElementTree as ET
from pathlib import Path

import mujoco
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'assets'


def wrap(a):
    return math.atan2(math.sin(a), math.cos(a))


def yaw_of(q):
    w, x, y, z = q
    return math.atan2(2*(w*z+x*y), 1-2*(y*y+z*z))


class Policy:
    def __init__(self, kind):
        self.kind = kind
        if kind == 'duet':
            import onnx
            from onnx.reference import ReferenceEvaluator
            self.weights = ASSETS/'duet_policy.onnx'
            model = onnx.load(self.weights)
            meta = {p.key: p.value for p in model.metadata_props}
            cfg = json.loads((ASSETS/'duet_contract.json').read_text())
            self.names = cfg['joint_names']
            self.default = np.array(cfg['default_joint_pos'], dtype=np.float64)
            self.kp = np.array(cfg['joint_stiffness'])
            self.kd = np.array(cfg['joint_damping'])
            self.scale = np.array(cfg['action_scale'])
            self.action_indices = np.array([self.names.index(n) for n in cfg['action_joint_names']])
            self.net = ReferenceEvaluator(model)
            self.last = np.zeros(13, dtype=np.float32)
            assert len(self.names) == 23 and int(meta['obs_dim']) == 71
        else:
            raise ValueError(kind)
        self.sha256 = hashlib.sha256(self.weights.read_bytes()).hexdigest()

    def bind(self, m):
        self.jids = np.array([m.joint(n).id for n in self.names])
        self.qids = m.jnt_qposadr[self.jids]
        self.vids = m.jnt_dofadr[self.jids]
        self.aids = np.array([m.actuator(n).id for n in self.names])
        self.pelvis = m.body('pelvis').id

    def infer(self, m, d, cmd):
        r = d.xmat[self.pelvis].reshape(3, 3)
        gravity = r.T @ np.array([0., 0., -1.])
        # MuJoCo free-joint rotational qvel is in the body frame.
        omega = d.qvel[3:6].copy()
        q = d.qpos[self.qids] - self.default
        dq = d.qvel[self.vids]
        phase = 2*math.pi*(d.time % 0.6)/0.6
        phase_obs = [0., 0.] if np.linalg.norm(cmd) < .1 else [math.sin(phase), math.cos(phase)]
        obs = np.concatenate([omega, gravity, cmd, phase_obs,
                              q, dq, self.last, [0.73]]).astype(np.float32)
        assert obs.shape == (71,)
        action = self.net.run(None, {'obs': obs[None]})[0][0]
        if not np.all(np.isfinite(action)):
            raise RuntimeError('Non-finite policy output')
        self.last = action.copy()
        target = self.default.copy()
        target[self.action_indices] += self.scale * action
        return target


def build_model(policy, dt):
    tree = ET.parse(ASSETS/'duet_g1_23dof.xml')
    root = tree.getroot()
    root.find('compiler').set('meshdir', str(ASSETS/'meshes'))
    ET.SubElement(root, 'option', timestep=str(dt), integrator='implicitfast',
                  gravity='0 0 -9.81', iterations='50')
    world = root.find('worldbody')
    ET.SubElement(world, 'geom', name='floor', type='plane', size='30 30 0.1',
                  rgba='0.32 0.39 0.46 1', friction='0.6 0.005 0.0001', condim='3')
    actuators = ET.SubElement(root, 'actuator')
    for i, n in enumerate(policy.names):
        if 'hip_roll' in n or 'knee' in n: effort = 139
        elif 'hip_' in n or 'waist_' in n: effort = 88
        elif 'ankle_' in n: effort = 50 if policy.kind == 'duet' else 35
        else: effort = 25
        j = root.find(".//joint[@name='%s']" % n)
        armature = policy.kp[i]/((20*math.pi)**2) if policy.kind == 'duet' else .01
        j.set('armature', str(armature))
        j.set('damping', '0')
        j.set('frictionloss', '0')
        ET.SubElement(actuators, 'motor', name=n, joint=n, ctrllimited='true',
                      ctrlrange=f'{-effort} {effort}')
    for g in root.findall('.//geom'):
        name = g.get('name', '')
        if name.endswith('_collision'):
            g.set('condim', '3' if 'foot' in name else '1')
            g.set('friction', '0.6 0.005 0.0001')
    xml = ET.tostring(root, encoding='unicode')
    m = mujoco.MjModel.from_xml_string(xml)
    assert m.nu == 23 and m.nq == 30 and m.nv == 29
    policy.bind(m)
    return m, xml

