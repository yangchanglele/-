"""Mesa EGL context, reused from the existing G1 rendering implementation."""
import ctypes as C

class EGLContext:
    def __init__(self, width, height):
        e = self.e = C.CDLL('libEGL.so.1')
        e.eglGetProcAddress.argtypes = [C.c_char_p]
        e.eglGetProcAddress.restype = C.c_void_p
        get_platform = C.CFUNCTYPE(C.c_void_p,C.c_uint,C.c_void_p,C.POINTER(C.c_int))(
            e.eglGetProcAddress(b'eglGetPlatformDisplayEXT'))
        self.display = get_platform(0x31DD,None,None)  # Mesa surfaceless platform
        e.eglInitialize.argtypes=[C.c_void_p,C.POINTER(C.c_int),C.POINTER(C.c_int)]
        e.eglInitialize.restype=C.c_uint
        ma,mi=C.c_int(),C.c_int()
        if not e.eglInitialize(self.display,C.byref(ma),C.byref(mi)):raise RuntimeError('EGL initialization failed')
        e.eglBindAPI.argtypes=[C.c_uint];e.eglBindAPI.restype=C.c_uint
        if not e.eglBindAPI(0x30A2):raise RuntimeError('OpenGL API unavailable')
        attrs=(C.c_int*17)(0x3033,1,0x3040,8,0x3024,8,0x3023,8,0x3022,8,0x3021,8,0x3025,24,0x3026,8,0x3038)
        config=C.c_void_p();count=C.c_int()
        e.eglChooseConfig.argtypes=[C.c_void_p,C.POINTER(C.c_int),C.POINTER(C.c_void_p),C.c_int,C.POINTER(C.c_int)]
        e.eglChooseConfig.restype=C.c_uint
        if not e.eglChooseConfig(self.display,attrs,C.byref(config),1,C.byref(count)) or count.value<1:raise RuntimeError('No EGL config')
        e.eglCreateContext.argtypes=[C.c_void_p,C.c_void_p,C.c_void_p,C.POINTER(C.c_int)];e.eglCreateContext.restype=C.c_void_p
        self.context=e.eglCreateContext(self.display,config,None,(C.c_int*1)(0x3038))
        e.eglCreatePbufferSurface.argtypes=[C.c_void_p,C.c_void_p,C.POINTER(C.c_int)];e.eglCreatePbufferSurface.restype=C.c_void_p
        self.surface=e.eglCreatePbufferSurface(self.display,config,(C.c_int*5)(0x3057,width,0x3056,height,0x3038))
        e.eglMakeCurrent.argtypes=[C.c_void_p,C.c_void_p,C.c_void_p,C.c_void_p];e.eglMakeCurrent.restype=C.c_uint
        if not e.eglMakeCurrent(self.display,self.surface,self.surface,self.context):raise RuntimeError('EGL make-current failed')
    def close(self):
        e=self.e;e.eglMakeCurrent(self.display,None,None,None)
        e.eglDestroySurface.argtypes=[C.c_void_p,C.c_void_p];e.eglDestroySurface(self.display,self.surface)
        e.eglDestroyContext.argtypes=[C.c_void_p,C.c_void_p];e.eglDestroyContext(self.display,self.context)
        e.eglTerminate.argtypes=[C.c_void_p];e.eglTerminate(self.display)

