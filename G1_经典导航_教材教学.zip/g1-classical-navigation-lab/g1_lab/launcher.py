"""Own all subprocesses; a closed window or terminal ends this session."""
import argparse
from datetime import datetime
import fcntl
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import uuid
from .common import ROOT,read_json,write_json,redact,local_settings

def main():
    p=argparse.ArgumentParser(description='G1 键盘 SLAM、多层地图与 OpenClaw')
    p.add_argument('--headless',action='store_true')
    agent=p.add_mutually_exclusive_group()
    agent.add_argument('--with-agent',action='store_true',help='启用已配置的 OpenClaw + DeepSeek')
    agent.add_argument('--offline-agent',action='store_true',help='仅本地操作，也是默认模式')
    p.add_argument('--map',help='已保存 rev_XXX 地图包目录；默认从空白开始手动建图')
    p.add_argument('--duration',type=float,default=0,help='自动运行指定墙钟秒数后退出，用于检查')
    p.add_argument('--no-rviz',action='store_true');p.add_argument('--record-bag',action='store_true')
    a=p.parse_args();a.offline_agent=not a.with_agent;(ROOT/'runs').mkdir(exist_ok=True)
    lockfile=(ROOT/'runs/session.lock').open('w')
    try:fcntl.flock(lockfile,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise SystemExit('已有本项目会话运行。请先关闭原窗口/终端。')
    settings=local_settings();sim_python=settings.get('simulation_python',str(ROOT/'.venv/bin/python'))
    session=ROOT/'runs'/('session_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6]);session.mkdir()
    write_json(ROOT/'runs/latest.json',{'session':str(session)})
    env={**os.environ,'PYTHONPATH':str(ROOT)+':'+os.environ.get('PYTHONPATH',''),'PYTHONUNBUFFERED':'1',
         'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','ROS_LOCALHOST_ONLY':'1','ROS_DOMAIN_ID':os.environ.get('G1_ROS_DOMAIN_ID','73')}
    env.pop('DEEPSEEK_API_KEY',None)
    processes=[];logs=[];closing=False
    def start(name,cmd,process_env=env):
        log=(session/(name+'.log')).open('w',buffering=1);logs.append(log)
        process=subprocess.Popen(cmd,cwd=ROOT,env=process_env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        processes.append((name,process));return process
    def stop(*_):
        nonlocal closing
        closing=True
    signal.signal(signal.SIGINT,stop);signal.signal(signal.SIGTERM,stop)
    def failure(name):
        path=session/(name+'.log')
        lines=path.read_text(errors='replace').strip().splitlines() if path.exists() else []
        detail=redact('\n'.join(lines[-6:]))
        return RuntimeError(f'{name} 启动失败。日志：{path}\n{detail}')
    try:
        if not a.headless:
            # Check the actual display and font enumeration before starting physics.
            check_env={**env,'PYTHONPATH':str(ROOT)}
            checked=subprocess.run([sim_python,'-m','g1_lab.tk_backend','--window'],cwd=ROOT,
                env=check_env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
            (session/'ui_preflight.log').write_text(redact(checked.stdout))
            if checked.returncode:raise failure('ui_preflight')
        command=['/usr/bin/python3','-m','g1_lab.ros_gateway','--session',str(session)]
        if a.map:command+=['--map',str(Path(a.map).resolve())]
        command+=['--ros-args','-p','use_sim_time:=true']
        gateway=start('ros',command)
        sim_env={**env,'PYTHONPATH':str(ROOT)}
        command=[sim_python,'-m','g1_lab.simulation','--session',str(session)]
        if a.headless:command.append('--headless')
        simulation=start('simulation',command,sim_env)
        if not a.headless and not a.no_rviz:
            start('rviz',['ros2','run','rviz2','rviz2','-d',str(ROOT/'config/lab.rviz'),'--ros-args','-p','use_sim_time:=true'])
        if a.record_bag:
            start('bag',['ros2','bag','record','-o',str(session/'rosbag'),'/clock','/scan','/rf2o/odom','/odom','/tf','/tf_static','/map',
                         '/amcl_pose','/particle_cloud','/plan','/cmd_vel','/slam_toolbox/graph_visualization','/semantic_markers','/keepout_mask','/speed_mask'])
        print('项目正在启动。日志目录：'+str(session),flush=True)
        deadline=time.monotonic()+60
        while not closing and time.monotonic()<deadline:
            if gateway.poll() is not None:raise failure('ros')
            if simulation.poll() is not None:raise failure('simulation')
            state=read_json(session/'status.json',{})
            if state.get('physics_state') in ('STANDING','WALKING') and state.get('odometry_fresh'):break
            time.sleep(.2)
        else:
            if not closing:raise RuntimeError('未取得新鲜的传感/里程计反馈。请查看 ros.log、rf2o.log 和 simulation.log')
        started=time.monotonic()
        if not a.duration and not closing:
            command=[sim_python,'-m','g1_lab.console','--session',str(session)]
            if a.offline_agent:command.append('--offline-agent')
            console_env={**os.environ,'PYTHONPATH':str(ROOT),'PYTHONUNBUFFERED':'1'}
            console=subprocess.Popen(command,cwd=ROOT,env=console_env)
            processes.append(('console',console))
        else:console=None
        while not closing:
            if simulation.poll() is not None:
                if simulation.returncode:raise failure('simulation')
                break
            if gateway.poll() is not None:
                if gateway.returncode:raise failure('ros')
                break
            if console and console.poll() is not None:break
            if a.duration and time.monotonic()-started>=a.duration:break
            time.sleep(.2)
    finally:
        write_json(session/'stop.json',{'created_wall':time.time()});time.sleep(.5)
        # Stop gateway first so it can reap RF2O, SLAM, and Nav2 process groups.
        for name,process in sorted(processes,key=lambda x:0 if x[0]=='ros' else 1):
            if process.poll() is not None:continue
            try:
                if name=='console':process.terminate()
                else:os.killpg(process.pid,signal.SIGINT)
                process.wait(timeout=45 if name=='ros' else 6)
            except subprocess.TimeoutExpired:
                if name=='console':process.kill()
                else:os.killpg(process.pid,signal.SIGKILL)
                process.wait()
            except ProcessLookupError:pass
        for log in logs:log.close()
        print('本次会话结束。数据和日志：'+str(session),flush=True)

if __name__=='__main__':main()
