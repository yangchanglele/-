"""Use Ubuntu's Xft-enabled Tk within this process, without altering Conda.

The existing simulation environment ships a Tk built without Xft/fontconfig.
That backend can only enumerate legacy X fonts, even when Noto CJK is installed.
Load the matching system Tcl/Tk libraries before importing _tkinter, and point
them at their matching Tcl scripts. This only changes the current process.
"""
import argparse
import ctypes
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

_handles=[]
_prepared=None

def loaded_font_libraries():
    maps=Path('/proc/self/maps')
    if not maps.exists():return []
    return sorted({line.split()[-1] for line in maps.read_text().splitlines()
                   if any(name in line for name in ('libtcl8.6','libtk8.6','libXft.so','libfontconfig.so'))})

def prepare_tk():
    global _prepared
    if _prepared is not None:return _prepared
    if not sys.platform.startswith('linux'):
        _prepared={'backend':'platform_default'};return _prepared
    arch={'x86_64':'x86_64-linux-gnu','aarch64':'aarch64-linux-gnu'}.get(platform.machine())
    libdir=Path('/usr/lib')/arch if arch else Path('/usr/lib')
    tcl=libdir/'libtcl8.6.so';tk=libdir/'libtk8.6.so'
    tcl_scripts=Path('/usr/share/tcltk/tcl8.6');tk_scripts=Path('/usr/share/tcltk/tk8.6')
    if not all(p.exists() for p in (tcl,tk,tcl_scripts/'init.tcl',tk_scripts/'tk.tcl')):
        raise RuntimeError('缺少系统 Tcl/Tk 8.6。请运行项目依赖安装脚本安装 python3-tk。')
    if '_tkinter' in sys.modules:
        loaded=loaded_font_libraries()
        if str(tk.resolve()) not in loaded or not any('libXft.so' in p for p in loaded):
            raise RuntimeError('当前进程已加载不支持中文字体的 Tk。请使用本项目一键启动脚本重新启动。')
    else:
        # Use identical SONAMEs so _tkinter reuses these native libraries.
        # Keep references alive and load Tcl before its Tk dependent.
        _handles.append(ctypes.CDLL(str(tcl),mode=ctypes.RTLD_GLOBAL))
        _handles.append(ctypes.CDLL(str(tk),mode=ctypes.RTLD_GLOBAL))
    os.environ['TCL_LIBRARY']=str(tcl_scripts)
    os.environ['TK_LIBRARY']=str(tk_scripts)
    _prepared={'backend':'system_tk_xft','tcl_library':str(tcl),'tk_library':str(tk),
               'tcl_scripts':str(tcl_scripts),'tk_scripts':str(tk_scripts)}
    return _prepared

def inspect_backend(window=False):
    report=dict(prepare_tk())
    import tkinter as tk
    interp=tk.Tcl();report['tcl_version']=str(interp.call('info','patchlevel'))
    report['loaded_libraries']=loaded_font_libraries()
    report['xft_loaded']=any('libXft.so' in p for p in report['loaded_libraries'])
    report['fontconfig_loaded']=any('libfontconfig.so' in p for p in report['loaded_libraries'])
    match=subprocess.run(['fc-match','-f','%{family}\n%{file}\n','Noto Sans CJK SC'],capture_output=True,text=True,check=True).stdout.splitlines()
    report['fontconfig_family']=match[0] if match else ''
    report['font_file']=match[1] if len(match)>1 else ''
    report['display_checked']=False
    if window:
        from .ui_style import configure_fonts
        root=tk.Tk();root.withdraw()
        try:
            fonts,family=configure_fonts(root)
            root.update_idletasks()
            report.update(display_checked=True,tk_family=family,body_font=fonts['Body'].actual(),
                          sample_width=fonts['Body'].measure('简体中文：手动建图、语义导航'))
        finally:root.destroy()
    if sys.platform.startswith('linux') and not (report['xft_loaded'] and report['fontconfig_loaded']):
        raise RuntimeError('系统 Tk 字体渲染组件未加载，检查 python3-tk 与 libxft2。')
    return report

def main():
    p=argparse.ArgumentParser();p.add_argument('--window',action='store_true')
    a=p.parse_args();print(json.dumps(inspect_backend(a.window),ensure_ascii=False,indent=2))

if __name__=='__main__':main()
