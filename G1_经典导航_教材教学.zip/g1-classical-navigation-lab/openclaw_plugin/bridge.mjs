import {readFile,writeFile,rename,unlink,appendFile} from 'node:fs/promises';
import {join} from 'node:path';
import {randomUUID} from 'node:crypto';
const delay=ms=>new Promise(r=>setTimeout(r,ms));
export async function rpc(operation,parameters={}) {
  const dir=process.env.G1_SLAM_SESSION;
  if(!dir)throw new Error('请先启动 G1 SLAM 实践项目');
  const status=JSON.parse(await readFile(join(dir,'status.json'),'utf8'));
  if(!status.running || Date.now()/1000-status.updated_wall>5)throw new Error('ROS 网关未运行或状态已过期');
  const id=randomUUID();
  const epoch=process.env.G1_CONTROL_EPOCH===undefined?status.epoch:Number(process.env.G1_CONTROL_EPOCH);
  const payload={id,operation,parameters,epoch,created_wall:Date.now()/1000};
  const tmp=join(dir,'inbox',id+'.tmp');await writeFile(tmp,JSON.stringify(payload));await rename(tmp,join(dir,'inbox',id+'.json'));
  const response=join(dir,'responses',id+'.json');const deadline=Date.now()+(operation==='map_load'?110000:['map_freeze_save','mapping_resume'].includes(operation)?65000:30000);
  while(Date.now()<deadline){
    let raw;
    try{raw=await readFile(response,'utf8');}catch(e){if(e.code!=='ENOENT')throw e;await delay(50);continue;}
    const value=JSON.parse(raw);await unlink(response);
    if(process.env.G1_SLAM_AUDIT)await appendFile(process.env.G1_SLAM_AUDIT,JSON.stringify({operation,parameters,response:value,wall:Date.now()/1000})+'\n');
    if(!value.ok)throw new Error(value.error);
    return value.result;
  }
  throw new Error('工具等待超时；请查看项目 ros.log，不能据此宣称执行成功');
}
