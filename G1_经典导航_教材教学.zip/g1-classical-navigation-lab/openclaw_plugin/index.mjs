import {definePluginEntry} from 'openclaw/plugin-sdk/plugin-entry';
import {rpc} from './bridge.mjs';
const str={type:'string'};
const arr={type:'array',items:str};
const versions={type:'object',properties:{map_id:str,geometry_revision:{type:'integer'},geometry_hash:str,semantic_revision:{type:'integer'},rules_revision:{type:'integer'}},additionalProperties:false};
const definitions=[
 ['mapping_status','查询当前建图/定位模式、估计位姿、已有地点、版本、最近位姿快照和选区 ID。全局坐标来自 SLAM/AMCL。',{},[]],
 ['map_list','列出已完整保存的地图包及版本。',{},[]],
 ['map_freeze_save','仅在手动建图模式，停稳后保存占据地图和原生位姿图。不会自动导航。name 使用字母数字下划线。',{name:str},['name']],
 ['map_load','加载已保存地图并启动 AMCL/Nav2。bundle 应来自 map_list 或保存结果；省略时加载刚保存的地图。可能需要约一分钟。',{bundle:str},[]],
 ['mapping_resume','在已定位的当前地图上继续手动建图。保存将生成新几何版本，旧语义不会自动复制。',{},[]],
 ['pose_capture','在已加载地图中采集当前估计位姿快照。机器人必须停稳。返回 snapshot_id，供人工地点命名。',{},[]],
 ['semantic_query','查询已标注地点、别名与区域。没有匹配项就是未知地点，不能猜坐标。',{query:str},[]],
 ['semantic_add_place','将本地位姿快照或地图编辑器选定目标保存为地点。坐标只能来自 snapshot_id 或 selection_id。',{name:str,aliases:arr,snapshot_id:str,selection_id:str,expected_versions:versions},['name']],
 ['semantic_set_region','给用户已在地图面板画好的多边形命名并设置房间、禁行或限速规则。不能自行编造选区。更新会停止原运动任务。',{name:str,selection_id:str,kind:{type:'string',enum:['room','keepout','speed_limit']},max_linear_mps:{type:'number',minimum:.1,maximum:.3}},['name','selection_id','kind']],
 ['semantic_connect','查询实际 Nav2 路径并保存两个已标注地点之间的单向拓扑连接。',{from_id:str,to_id:str},['from_id','to_id']],
 ['semantic_remove','按用户要求删除一个地点或区域；ID 必须来自地图查询。',{id:str},['id']],
 ['semantic_add_object','标注对象的位置，并关联另一个已存在的可达停靠点。对象位置可在占据区，机器人只能前往 approach_place_id。选区必须由用户在地图编辑器选择。',{name:str,selection_id:str,approach_place_id:str,room_id:str},['name','selection_id','approach_place_id']],
 ['mission_submit','提交依次访问已存在地点的任务。先查语义地图，将用户别名解析为明确的地点 ID。所有当前禁行和限速规则自动生效。返回 QUEUED/RUNNING 不代表完成。',{goal_ids:{type:'array',items:str,minItems:1,maxItems:12},expected_versions:versions,request_id:str},['goal_ids']],
 ['mission_status','查询任务执行结果。只有 SUCCEEDED 表示 Nav2 与估计位姿/停稳复核均成功。',{task_id:str},[]],
 ['mission_cancel','停止并取消当前导航；窗口保持打开，机器人继续平衡。',{},[]]
];
export default definePluginEntry({id:'g1-slam',name:'G1 SLAM Semantic Navigation',register(api){
  for(const [name,description,properties,required] of definitions){
    api.registerTool({name,description,parameters:{type:'object',properties,required,additionalProperties:false},
      async execute(callId,params){
        const input={...params};if(name==='mission_submit'&&!input.request_id)input.request_id=callId;
        const details=await rpc(name,input);
        return {content:[{type:'text',text:JSON.stringify(details)}],details};
      }});
  }
}});
