# 方案可行性与实现依据

核对日期：2026-11-19。结论：组件的算法职责和 ROS 2 Humble 接口能够组成目标实践链路，已经提供相应适配；**接口可组合不等于整链路已经通过**。读者版增加了独立安装和相对路径配置，具体检查记录与待验收项目以 `VALIDATION.md` 为准。

## 为什么选择这条路线

| 学习目标 | 采用的组件 | 本项目中的实际职责 |
|---|---|---|
| 从两帧扫描理解相对运动 | [RF2O，作者 ROS 2 分支](https://github.com/MAPIRlab/rf2o_laser_odometry/tree/ros2) | 输入虚拟水平 `/scan`，估计平面运动和 `odom→base_footprint` |
| 观察建图、位姿图、回环与优化 | [SLAM Toolbox，Humble](https://github.com/SteveMacenski/slam_toolbox/tree/humble) | 手动探索时维护地图；保存/恢复原生图 |
| 区分建图与已知地图定位 | [Nav2 AMCL](https://github.com/ros-navigation/navigation2/tree/humble/nav2_amcl) | 冻结地图后仅估计机器人在地图中的位姿 |
| 区分几何图、代价图、路线与速度 | [Nav2，Humble](https://github.com/ros-navigation/navigation2/tree/humble) | SmacPlanner2D 查询路径，DWB 生成平面速度，代价过滤器施加禁行/限速规则 |
| 自己构建语义与拓扑 | 本项目 `maps.py`、`gui.py` | 人工采集地点、别名和接近位姿，画区域，使用 Nav2 验证连接 |
| 自然语言调度地图工具 | [OpenClaw 工具插件](https://docs.openclaw.ai/plugins/sdk-overview/tools-and-commands) | DeepSeek 调用查询、标注、地图生命周期和导航工具，实际控制由本地 ROS 网关执行 |
| 人形机器人承接速度命令 | [DUET](https://github.com/bae-air-lab/DUET) | 已选社区 G1 23DoF 预训练速度策略，关节 PD 接入 MuJoCo |

不是轮式机器人直接换外形：G1 有步态震荡、侧移耦合、原地转向漂移和停稳延迟。本版用水平虚拟雷达隔离二维 SLAM 学习问题，保留真实关节物理与步态。并未解决真实机身雷达去畸变、上下楼和足步规划。

## 逐项源码核对后做的适配

1. RF2O 作者 ROS 2 节点的默认零位姿四元数 `w=0` 无效；补丁设为 1。扫描初始化必须等静态激光 TF 可用，不能忽略 TF 查询失败。编译显式链接 `Eigen3::Eigen`。
2. RF2O 原节点发布 `twist.linear.y=0`，不适合 G1 的侧移反馈。网关接收 `/rf2o/odom`，用相邻**估计位姿**差分并旋转到当前机器人坐标系，发布完整 `/odom`。这项数学转换已做独立检查，RF2O 编译及真实消息联调仍待运行。
3. Humble SLAM Toolbox 原生 `SerializePoseGraph` 返回结果码；地图保存同时检查 `.posegraph` 和 `.data` 文件。`DeserializePoseGraph` 请求的 `START_AT_GIVEN_POSE=2` 用于恢复建图。Humble 恢复接口没有结果字段，所以不能假造一个成功码。
4. 建图进程与 AMCL 互斥，避免两个节点同时发布 `map→odom`。加载新地图前先验证地图包文件 hash；换地图取消旧任务。
5. Humble Nav2 参数使用该分支的插件名称和消息类型。AMCL 使用 `OmniMotionModel`，DWB 开启横向速度采样。RViz 粒子显示使用 `nav2_rviz_plugins/ParticleCloud`。
6. 禁行过滤器位于普通代价层之后，不能假设原有 inflation 层会自动扩大禁区；本项目生成掩膜时按 0.45 m 半径扩边。
7. PGM 的未知灰度 205 配合 `free_thresh=0.196`，避免地图重新加载时把未知格子变成自由空间。地图图像、元数据、数组和原生图均校验哈希。
8. OpenClaw 使用当前机器真实 CLI 与 SDK 的工具注册接口，已验证插件和 DeepSeek provider 被加载。工具调用记录、控制权代次、超时与异步任务状态都有独立记录；没有用直接 API 请求冒充 OpenClaw。

## 论文如何落实到练习

- [Planar Odometry from a Radial Laser Scanner: A Range Flow-based Approach，ICRA 2016](https://mapir.uma.es/papersrepo/2016/2016_Jaimez_ICRA_RF2O.pdf)：扫描变化如何约束运动。先看实际 RF2O，再用仓库中的点到点/点到线 ICP 作对照；ICP 不是 RF2O 的实现。
- [SLAM Toolbox: SLAM for the dynamic world，JOSS 2021](https://doi.org/10.21105/joss.02783)：实际二维建图、原生位姿图序列化与持续建图。
- [3D Dynamic Scene Graphs，RSS 2020](https://roboticsproceedings.org/rss16/p079.html)：借鉴地点、房间、对象及关系的分层表达。本版由学生人工标注，不声称复现自动三维场景图。
- [SayPlan，CoRL 2023](https://proceedings.mlr.press/v229/rana23a.html)：借鉴语言规划查询结构化空间表示、再调用执行工具的分工。本版只实现人工二维语义地图上的有限工具，不声称达到原论文开放环境能力。

更广泛阅读见 `research/论文清单_19篇.csv`。前期方案里列出的三维点云、OctoMap、高程图、接触辅助 InEKF 和自动视觉语言语义地图保留为后续课题；这次先完成二维经典导航的学习主线。

## 交付边界与判定

- 已实际验证：G1 物理与射线测距、地图数据一致性、教学配准和图优化、OpenClaw 插件加载、本地工具 RPC、控制命令过期归零、EGL 渲染。
- 读者版待验收：全新安装、ROS TF/时钟与消息联调、SLAM 保存恢复、AMCL/Nav2 到达闭环、DeepSeek 真正提交导航、Tk/RViz 桌面交互。
- `一键验证.sh` 必须取得真实导航到达、停稳且无物理障碍接触，才写 `PASSED`。`--cloud` 还必须取得模型调用正确地点 ID 的工具记录并完成第二次导航。
- 地图恢复、GUI 编辑和 bag 回放仍需按照 `EXPERIMENTS.md` 手动验收。单个回归脚本成功不能代表所有教学实验都已验收。

环境安装使用 [ROS 官方 Humble Ubuntu 文档](https://docs.ros.org/en/humble/Installation/Ubuntu-Install-Debs.html) 的软件源方式。安装成功后保存 RF2O commit；不执行系统整机升级，不把依赖存在写成应用验证通过。
