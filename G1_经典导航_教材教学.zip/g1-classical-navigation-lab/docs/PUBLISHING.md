# 上传 GitHub 与发行 ZIP

这个目录就是仓库根目录。公开发布前运行：

```bash
python3 scripts/check_release.py
python3 scripts/verify_assets.py
```

基础安装会生成 `.venv`、`ros_ws`、`runs` 和 `config/local.json`，它们由 `.gitignore` 排除。Key、OpenClaw 状态、个人地图和运行日志不进入公开源码。发布扫描会检测常见凭据格式及个人绝对主目录路径，但不能替代维护者对新增材料的审阅。

## 创建 GitHub 仓库

在自己的 GitHub 账号下创建空仓库，建议名称 `g1-classical-navigation-lab`。不要勾选生成另一份 README 或许可证，随后在本目录操作：

```bash
git init -b main
git add .
git status --short
python3 scripts/check_release.py --tracked
git commit -m "Add G1 classical navigation teaching project"
```

把新仓库页面提供的地址用于 `git remote add origin 仓库地址`，然后执行 `git push -u origin main`。首次提交前自行配置 Git 的作者身份；项目不预填作者的账号信息。

如果用 GitHub 网页上传，应上传解压后的文件与目录，并包含 `.github`、`.gitignore`、`.gitattributes`。只上传一个 ZIP 不会让 GitHub 直接显示源码与执行 CI。

## 生成读者下载包

```bash
python3 scripts/package_project.py
```

产物在 `dist/`，包含源码、参数、模型/权重、教学资料、检查证据和 `RELEASE_MANIFEST.json`。另有 ZIP 的 SHA256 文件；运行环境和凭据不包含在内。发布脚本使用明确的文件清单，不会把整个工作目录直接压缩进去。

## 教材版本验收

目前标为 `0.2.0-preview`。GitHub Actions 只配置离线检查；实际上传后才会有远端执行结果。建议在教材正式版中固定通过试课的 tag，而不是让学生长期跟随变化中的 main。

正式标为稳定版前，至少在一台全新 Ubuntu 22.04 电脑完成：从零安装、中文窗口与键盘、手动闭合路线、保存/恢复、AMCL、Nav2 到达、六类地图操作、规则更新与停止。使用自己申请的测试凭据单独验收 OpenClaw 任务；保留脱敏结果。不要把原型本机的部分检查当作每位读者环境都已验收。
