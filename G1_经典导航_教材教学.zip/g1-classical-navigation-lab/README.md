# G1 人形机器人经典导航实践

**书籍配套教学项目：亲手建图，理解定位，再实现路径规划和语义导航。**

使用 G1 23DoF、MuJoCo 和社区预训练行走策略，自己用键盘驾驶机器人采集激光扫描；观察 RF2O 里程计、SLAM Toolbox 的地图与位姿图；保存后切换 AMCL 和 Nav2。进一步由学生标注地点、房间、对象、拓扑连接、禁行区和限速区，用可选的 OpenClaw + DeepSeek 实现高层任务控制。

**版本：0.2.0-preview。** 代码、安装入口、教学资料和离线检查已整理。新电脑从零安装、完整 ROS 导航及修改后的桌面窗口仍需课堂试运行验收；不将已有物理检查写成完整导航已经通过。具体证据见 [验证说明](docs/VALIDATION.md)。

![实践架构](docs/images/architecture.svg)

## 开始前

目标环境为 **Ubuntu 22.04 桌面版、x86_64、Python 3.10、ROS 2 Humble**。物理和策略推理使用 CPU，画面需要可用的 OpenGL/EGL；无需先训练策略。建议准备 16 GB 内存和足够的安装空间，这是教学环境建议，尚未测定最低配置。首次安装需要网络及 sudo 权限。

Windows、macOS、WSL 和 ARM 尚未作为本版教学环境验收。先在指定 Ubuntu 环境完成实验，再考虑迁移。

## 三步开始基础实验

下载并解压本项目，进入解压后的根目录。来自 GitHub 的源码 ZIP 可能多一个 `-main` 后缀，以实际目录为准。

```bash
cd g1-classical-navigation-lab
bash setup.sh
bash 一键启动.sh
```

也可以直接运行 `bash 一键启动.sh`，缺少基础环境时会进入安装。**默认模式不需要 OpenClaw，也不需要 API Key。** 安装器使用 ROS 官方软件源，创建项目自己的 `.venv`，下载固定提交的 RF2O 并应用补丁；不会查找作者电脑上的 Python 路径。

启动后会出现仿真与地图面板、RViz 和本地命令终端：

1. 等待显示“手动建图”，点击仿真画面，然后用 `W/S` 前后、`A/D` 侧移、`Q/E` 转向。
2. 自己探索房间和走廊，经过不同路线回到旧位置，观察地图与位姿图变化。
3. 松开键盘并停稳，点击“保存地图与位姿图”，再点击“加载刚保存地图”。
4. 等待“就绪”，采集位置，命名地点；在地图上画房间、禁行区和限速区。
5. 选择一个已标注地点，点击“导航至选中地点”，观察路径、代价地图和实际到达情况。

空格或 `ESC` 停止；失去驾驶焦点、松开按键或命令过期都会归零。键盘接管取消当前导航。保存正式语义之前必须先冻结并加载几何地图。

[第一次完整操作](docs/QUICKSTART.md) · [12 个实验](docs/EXPERIMENTS.md) · [课程安排与思考题](docs/TEACHING_GUIDE.md)

## 可选：接入 OpenClaw + DeepSeek

先完成基础实验，再安装模型工具运行时：

```bash
bash 安装OpenClaw.sh
python3 scripts/configure_local.py --key
bash 一键启动.sh --with-agent
```

每位读者使用自己的 DeepSeek Key。输入时不回显，保存在被 Git 忽略的 `config/deepseek.key`；也支持 `DEEPSEEK_API_KEY` 环境变量。发行包不含作者凭据。

安装器固定 OpenClaw `2026.11.5`、Node `24.22.1` 和 DeepSeek provider `2026.11.5`。当前配置的模型为 `deepseek/deepseek-flash`；需要变更时使用 `python3 scripts/configure_local.py --model 模型ID`，并重新验证工具调用。参考 [官方安装说明](https://docs.openclaw.ai/install/installer) 与 [DeepSeek provider 文档](https://docs.openclaw.ai/providers/deepseek)。

```text
把刚采集的位置记为“补给站”，别名“物资点”。
地图中有哪些地点和区域？
把我刚画好的区域设置为施工禁行区。
先去物资点，再回出发点。
查询当前任务结果。
停止
```

高层模型负责调用结构化工具，地图查询、任务受理、导航执行和停稳复核由本地代码完成。“已提交”与“已到达”是不同状态。地图未知或地点名有歧义时不能猜坐标。`停止`、`/stop`、`/status` 等本地命令不依赖云模型。

## 六类地图

| 地图 | 学习重点 | 主要产物 |
|---|---|---|
| 占据栅格地图 | 扫描、逆传感器模型、未知/自由/占据 | PGM、YAML、NPY |
| SLAM 位姿图 | 关键帧、相邻约束、回环、优化 | 原生 `.posegraph` 与 `.data` |
| 全局/局部代价地图 | 机器人包络、膨胀、实时障碍 | ROS costmap 与会话快照 |
| 语义地图 | 地点、别名、房间、对象、接近位姿 | `semantic.json` |
| 拓扑地图 | 节点与经 Nav2 校验的单向连接 | 路径、距离、校验状态 |
| 规则地图 | 人工禁行与限速、多边形栅格化 | keepout/speed 掩膜 |

地图保存到 `maps/<地图ID>/rev_XXX/`，地图 ID 使用字母、数字、下划线或短横线；地点名称可以用中文。几何版本和语义版本分开记录。继续建图会生成新几何版本，原语义需重新审核。

## 数据与控制链路

```text
MuJoCo 虚拟水平激光 → /scan → RF2O → 估计里程计与 odom→base_footprint
                                     ↓
建图：SLAM Toolbox → 栅格 / 位姿图 / map→odom
定位：已保存地图 + AMCL → map→odom（与建图进程互斥）
                                     ↓
人工语义与规则 → OpenClaw 工具（可选）→ Nav2 路径/速度
                                     ↓
                           本地仲裁 → DUET → 关节 PD → 物理
```

相邻 RF2O 估计位姿差分补全其原始节点缺失的侧向速度，再发布 `/odom`。仿真世界位姿仅进入独立评测文件；导航不读取它。二维扫描使用虚拟水平传感器，理想 IMU 仅提供角速度/重力；它们不是现实人形机器人三维状态估计的完整模型。

详细解释见 [架构与代码导读](docs/ARCHITECTURE.md) 和 [论文与开源实现依据](docs/RESEARCH_AND_FEASIBILITY.md)。

## 验证与常用命令

```bash
bash 一键启动.sh --check             # 检查基础依赖，不启动窗口
bash 一键启动.sh --check --with-agent
bash 一键启动.sh --record-bag        # 记录 ROS bag
bash 一键启动.sh --map maps/lab_floor_1/rev_001

.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python scripts/validate_local.py
.venv/bin/python scripts/check_deadman.py

bash 一键验证.sh                    # 实际 ROS 建图、定位、Nav2 回归
bash 一键验证.sh --cloud            # 另验证真实 OpenClaw + DeepSeek 导航
```

GitHub Actions 配置检查源文件、资产哈希、Python/本地 RPC、实际 MuJoCo 与测距；**CI 不调用云 API，也不代表 Nav2 或桌面交互已验收**。仓库尚未上传时，配置的 CI 没有远端运行记录。

日志在 `runs/setup/` 与 `runs/session_*/`；整链路结论在 `runs/integration_*/result.json`。回归驾驶输入仅用于测试，日常建图始终由学生键盘驾驶。

## 目录

```text
g1_lab/             仿真、界面、地图、ROS 网关、Agent 终端
assets/             G1 模型、网格、预训练策略与校验清单
config/             SLAM/Nav2/RViz 参数与本机配置示例
openclaw_plugin/    有限地图/导航工具
scripts/            安装、校验、回放与发布脚本
tests/              数据、里程计转换、Tk 和文件 RPC 检查
docs/               操作、实验、原理、故障排查、阅读资料
examples/           实验报告模板
.github/            CI、Issue 与 PR 模板
```

## 范围、许可与发布

当前主线是平地二维经典导航。三维点云、OctoMap、高程图、接触辅助 InEKF、自动视觉语义地图、楼梯与足步规划不在本版实现范围内。人形步态会有平移/转向耦合，参数还需真实 ROS 场景校准。

项目自有代码使用 [Apache-2.0](LICENSE)。机器人资产、DUET 社区权重和上游参数保留各自许可，见 [第三方声明](vendor/ASSET_NOTICES.md)。该策略**不是宇树官方发布的 G1 23DoF 预训练权重**，本项目不声称重新训练过它。

[故障排查](docs/TROUBLESHOOTING.md) · [贡献说明](CONTRIBUTING.md) · [上传 GitHub / 生成 ZIP](docs/PUBLISHING.md) · [更新记录](CHANGELOG.md)
