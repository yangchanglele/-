#!/usr/bin/env bash
# Install inside this checkout; no author's Python environment is required.
set -euo pipefail
LAB_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$LAB_ROOT"
umask 077
export PATH="/usr/bin:/bin:$PATH"
unset PYTHONHOME PYTHONPATH CONDA_PREFIX CONDA_DEFAULT_ENV
if [[ ! -f /opt/ros/humble/setup.bash || ! -f ros_ws/install/setup.bash ]]; then
  bash scripts/install_dependencies.sh
fi
if ! /usr/bin/python3 -m venv --help >/dev/null 2>&1; then
  echo '请先安装 python3-venv。'; exit 2
fi
if [[ ! -x .venv/bin/python ]]; then /usr/bin/python3 -m venv .venv; fi
mkdir -p runs/setup
G1_PIP_LOG="runs/setup/python_$(date +%Y%m%d_%H%M%S).log"
.venv/bin/python -m pip install -r requirements.txt 2>&1 | tee "$G1_PIP_LOG"
/usr/bin/python3 scripts/configure_local.py
/usr/bin/python3 scripts/verify_assets.py
/usr/bin/python3 scripts/doctor.py
echo '基础环境安装完成。运行 bash 一键启动.sh，默认无需 API Key。'
