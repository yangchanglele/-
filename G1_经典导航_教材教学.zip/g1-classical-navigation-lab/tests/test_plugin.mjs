import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,readFile,writeFile,readdir,rename,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {rpc} from '../openclaw_plugin/bridge.mjs';

test('file RPC transports explicit operation, arguments and control epoch',async()=>{
  const dir=await mkdtemp(join(tmpdir(),'g1-slam-plugin-'));
  await mkdir(join(dir,'inbox'));await mkdir(join(dir,'responses'));
  await writeFile(join(dir,'status.json'),JSON.stringify({running:true,updated_wall:Date.now()/1000,epoch:7}));
  process.env.G1_SLAM_SESSION=dir;process.env.G1_CONTROL_EPOCH='7';let busy=false;
  const timer=setInterval(async()=>{
    if(busy)return;busy=true;
    try{
      for(const name of await readdir(join(dir,'inbox'))){
        if(!name.endsWith('.json'))continue;
        const request=JSON.parse(await readFile(join(dir,'inbox',name),'utf8'));
        const reply=request.epoch===7?{ok:true,result:{operation:request.operation,parameters:request.parameters,epoch:request.epoch}}:{ok:false,error:'STALE_CONTROL_EPOCH'};
        const temporary=join(dir,'responses',name+'.tmp');await writeFile(temporary,JSON.stringify(reply));await rename(temporary,join(dir,'responses',name));
        await rm(join(dir,'inbox',name));
      }
    }finally{busy=false;}
  },5);
  try{
    const value=await rpc('semantic_query',{query:'补给站'});
    assert.equal(value.operation,'semantic_query');assert.equal(value.parameters.query,'补给站');assert.equal(value.epoch,7);
    process.env.G1_CONTROL_EPOCH='6';await assert.rejects(rpc('mission_submit',{goal_ids:['known-id']}),/STALE_CONTROL_EPOCH/);
    await writeFile(join(dir,'status.json'),JSON.stringify({running:true,updated_wall:0,epoch:7}));
    await assert.rejects(rpc('mapping_status'),/已过期/);
  }finally{clearInterval(timer);await new Promise(r=>setTimeout(r,20));await rm(dir,{recursive:true,force:true});delete process.env.G1_SLAM_SESSION;delete process.env.G1_CONTROL_EPOCH;}
});

test('plugin manifest exactly matches registered tool declarations',async()=>{
  const source=await readFile(new URL('../openclaw_plugin/index.mjs',import.meta.url),'utf8');
  const manifest=JSON.parse(await readFile(new URL('../openclaw_plugin/openclaw.plugin.json',import.meta.url),'utf8'));
  const declared=[...source.matchAll(/^ \['([a-z_]+)',/gm)].map(x=>x[1]).sort();
  assert.deepEqual(declared,[...manifest.contracts.tools].sort());assert.equal(new Set(declared).size,declared.length);
});
