"""Regression: the actual simulation interpreter must load the Xft Tk backend."""
import json
from pathlib import Path
import os
import subprocess
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]

class TkRuntimeTest(unittest.TestCase):
    @unittest.skipUnless(sys.platform.startswith('linux'),'Ubuntu desktop runtime')
    def test_actual_gui_import_loads_xft_and_matching_tcl(self):
        result=subprocess.run([sys.executable,'-c',
            'import json; from g1_lab.gui import Window; '
            'from g1_lab.tk_backend import inspect_backend; '
            'print(json.dumps(inspect_backend()))'],cwd=ROOT,
            env={**os.environ,'PYTHONPATH':str(ROOT)},capture_output=True,text=True,timeout=20)
        self.assertEqual(result.returncode,0,result.stderr)
        data=json.loads(result.stdout)
        self.assertTrue(data['xft_loaded'])
        self.assertTrue(data['fontconfig_loaded'])
        self.assertIn('CJK SC',data['fontconfig_family'])
        self.assertTrue(Path(data['font_file']).is_file())
        self.assertFalse(data['display_checked'])
        # Loading a Conda Tk alongside system Tk would make resolution ambiguous.
        loaded_tk=[p for p in data['loaded_libraries'] if 'libtk8.6' in p]
        self.assertEqual(loaded_tk,[str(Path(data['tk_library']).resolve())])

if __name__=='__main__':unittest.main()
