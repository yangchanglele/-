import json
import os
from pathlib import Path
import subprocess
import sys
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from check_release import public_files,inspect_bytes,forbidden

class DistributionTest(unittest.TestCase):
    def test_config_resolves_from_another_working_directory(self):
        env={**os.environ,'PYTHONPATH':str(ROOT)}
        env.pop('G1_SIM_PYTHON',None);env.pop('G1_DEEPSEEK_MODEL',None)
        r=subprocess.run([sys.executable,'-c','import json; from g1_lab.common import local_settings; print(json.dumps(local_settings()))'],
            cwd='/tmp',env=env,capture_output=True,text=True,check=True)
        settings=json.loads(r.stdout)
        self.assertEqual(settings['simulation_python'],str(ROOT/'.venv/bin/python'))
        self.assertEqual(settings['key_file'],str(ROOT/'config/deepseek.key'))
    def test_private_material_cannot_enter_default_release(self):
        selected={str(p.relative_to(ROOT)) for p in public_files()}
        self.assertIn('config/local.example.json',selected)
        for name in ('config/local.json','config/deepseek.key','.env','runs/a.json','.openclaw-state/a.json','ros_ws/install/setup.bash'):
            self.assertTrue(forbidden(name));self.assertNotIn(name,selected)
    def test_scanner_rejects_credentials_without_echoing_them(self):
        value=('sk'+'-'+'x'*32).encode()
        self.assertEqual(inspect_bytes('README.md',value),['credential-like bytes'])
    def test_launcher_help_works_before_runtime_installation(self):
        # Real parser in a child process: no ROS/physics starts for --help.
        r=subprocess.run([sys.executable,'-m','g1_lab.launcher','--help'],cwd=ROOT,capture_output=True,text=True)
        self.assertEqual(r.returncode,0);self.assertIn('--with-agent',r.stdout)

if __name__=='__main__':unittest.main()
