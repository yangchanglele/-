import json
import math
from pathlib import Path
import tempfile
import unittest
import numpy as np
from g1_lab.maps import Grid,MapStore,astar
from g1_lab.teaching import transform,icp,ray_cells,OccupancyBuilder,optimize_pose_graph,relative
from g1_lab.common import write_json,body_velocity_between

class OdometryTest(unittest.TestCase):
    def test_sideways_velocity_uses_robot_frame(self):
        np.testing.assert_allclose(body_velocity_between([0,0,math.pi/2],[-.02,0,math.pi/2],.1),[0,.2,0],atol=1e-10)
    def test_wraparound_and_invalid_timestamps(self):
        self.assertAlmostEqual(body_velocity_between([0,0,math.pi-.01],[0,0,-math.pi+.01],.1)[2],.2)
        for dt in (0,-.1,1.,float('nan')):
            with self.assertRaises(ValueError):body_velocity_between([0,0,0],[0,0,0],dt)

class MapsTest(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        data=np.zeros((100,100),dtype=int);data[:3]=100;data[-3:]=100;data[:,:3]=100;data[:,-3:]=100
        self.grid=Grid(data,.1,[0.,0.,0.]);self.store=MapStore(self.root)
        self.bundle=self.store.create('test',self.grid);m=json.loads((self.bundle/'manifest.json').read_text());m['complete']=True
        write_json(self.bundle/'manifest.json',m);self.store.activate(self.bundle)
    def tearDown(self):self.temp.cleanup()
    def test_rotated_grid_coordinate_roundtrip(self):
        g=Grid(np.zeros((20,30)),.2,[2.,-3.,.7])
        for x,y in [(0,0),(29,19),(10,8)]:self.assertEqual(g.cell(*g.world(x,y)),(x,y))
    def test_save_roundtrip_preserves_unknown_and_hash(self):
        self.grid.data[20:30,20:30]=-1;self.grid.save(self.root/'roundtrip');loaded=Grid.load(self.root/'roundtrip')
        np.testing.assert_array_equal(loaded.data,self.grid.data);self.assertEqual(loaded.digest(),self.grid.digest())
    def test_geometry_tampering_rejected(self):
        g=Grid.load(self.bundle/'occupancy');g.data[50,50]=100;g.save(self.bundle/'occupancy')
        with self.assertRaisesRegex(ValueError,'hash'):self.store.activate(self.bundle)
    def test_saved_pgm_unknown_is_not_loaded_as_free(self):
        from PIL import Image
        import yaml
        self.grid.data[20,20]=-1;self.grid.save(self.root/'pgm')
        cfg=yaml.safe_load((self.root/'pgm/map.yaml').read_text())
        pixels=np.flipud(np.asarray(Image.open(self.root/'pgm/map.pgm')))
        occupancy=1.-pixels[20,20]/255.
        self.assertGreater(occupancy,cfg['free_thresh']);self.assertLess(occupancy,cfg['occupied_thresh'])
    def test_nav2_image_tampering_rejected(self):
        p=self.bundle/'occupancy/map.pgm';p.write_bytes(p.read_bytes()+b'changed')
        with self.assertRaisesRegex(ValueError,'hash'):self.store.activate(self.bundle)
    def test_incomplete_map_rejected(self):
        p=self.store.create('incomplete',self.grid)
        with self.assertRaisesRegex(ValueError,'未完成'):self.store.activate(p)
    def test_path_traversal_rejected(self):
        with self.assertRaises(ValueError):self.store.create('../escape',self.grid)
    def test_unknown_space_not_free(self):
        self.grid.data[50,50]=-1;self.assertFalse(self.grid.free([5.,5.]))
    def test_place_aliases_and_duplicate(self):
        p=self.store.add_place('补给站',['物资点'],[2.,2.,0.],'snapshot')
        self.assertEqual(self.store.resolve('物资点')['id'],p['id'])
        with self.assertRaises(ValueError):self.store.add_place('物资点',[],[3.,3.,0.],'s')
        self.assertEqual(self.store.query('不存在'),[])
    def test_stale_version_rejected(self):
        old=self.store.versions();self.store.add_place('站点',[],[2.,2.,0.],'s')
        with self.assertRaisesRegex(ValueError,'STALE'):self.store.require(old)
    def test_obstacle_goal_rejected(self):
        with self.assertRaises(ValueError):self.store.add_place('墙内',[],[.1,.1,0],'s')
    def test_keepout_mask_expands_for_body(self):
        self.store.region('施工','keepout',[[4,4],[5,4],[5,5],[4,5]])
        keep,speed=self.store.masks()
        self.assertEqual(int(keep[45,37]),100);self.assertEqual(int(keep[45,30]),0)
        with self.assertRaises(ValueError):self.store.add_place('禁区',[],[4.5,4.5,0],'s')
    def test_speed_overlap_uses_lower_limit_and_zero_outside(self):
        poly=[[2,2],[5,2],[5,5],[2,5]];self.store.region('慢行','speed_limit',poly,.25)
        self.store.region('更慢','speed_limit',[[3,3],[4,3],[4,4],[3,4]],.15)
        _,speed=self.store.masks();self.assertEqual(speed[35,35],15);self.assertEqual(speed[25,25],25);self.assertEqual(speed[80,80],0)
    def test_topology_is_invalidated_by_rule_change(self):
        a=self.store.add_place('甲',[],[2,2,0],'a');b=self.store.add_place('乙',[],[7,7,0],'b')
        self.store.connect(a['id'],b['id'],[[2,2],[2,7],[7,7]])
        self.store.region('禁区','keepout',[[4,4],[5,4],[5,5],[4,5]])
        self.assertEqual(self.store.document['topology']['edges'][0]['status'],'pending_revalidation')
    def test_astar_cannot_cross_wall(self):
        self.grid.data[:,50]=100
        with self.assertRaises(ValueError):astar(self.grid,[2,5],[7,5])
    def test_astar_route_around_obstacle(self):
        self.grid.data[40:60,40:60]=100
        path=astar(self.grid,[2,5],[8,5]);self.assertGreater(sum(math.dist(a,b) for a,b in zip(path,path[1:])),6.)
        self.assertTrue(all(self.grid.free(x) for x in path))
    def test_icp_recovers_measured_relative_transform(self):
        rng=np.random.default_rng(2);p=rng.uniform(-2,2,(400,2));expected=np.array([.08,-.03,.025])
        current=transform([-expected[0],-expected[1],0],p)
        current=transform([0,0,-expected[2]],current)
        estimate,rmse,fraction=icp(p,current)
        np.testing.assert_allclose(estimate,expected,atol=.003)
    def test_ray_update_distinguishes_free_hit_and_unknown(self):
        b=OccupancyBuilder(.1,100,100,(0,0,0));scan={'ranges':[2.0],'angle_min':0.,'angle_increment':.1,'range_min':.05,'range_max':10.}
        b.update(scan,[1,1,0]);g=b.result();self.assertLess(g.data[10,20],50);self.assertGreater(g.data[10,30],50);self.assertEqual(g.data[80,80],-1)
    def test_loop_constraint_corrects_accumulated_error(self):
        initial=np.array([[0,0,0],[1.1,0,0],[1.1,1.1,0],[.2,1.1,0],[.2,.2,0]])
        edges=[(i,i+1,relative(initial[i],initial[i+1]),[.1,.1,.1]) for i in range(4)]
        edges.append((0,4,[0,0,0],[.01,.01,.01]));poses,metrics=optimize_pose_graph(initial,edges)
        self.assertLess(np.linalg.norm(poses[-1,:2]),.02);np.testing.assert_array_equal(poses[0],initial[0])

if __name__=='__main__':unittest.main()
