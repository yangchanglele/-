# 贡献说明

先阅读 README 与验证状态。提交改动时说明具体触发条件、修改后的行为和实际执行的检查。未执行的桌面、ROS 或云端检查要明确列出。

基础检查使用 `.venv/bin/python -m unittest discover -s tests -v`；物理变更另运行 `scripts/validate_local.py`，控制超时变更另运行 `scripts/check_deadman.py`。Agent 文件 RPC 可以用 `node --test tests/test_plugin.mjs` 检查；CLI/provider 实际加载和云端调用应另做验证。

不要将仿真世界位姿接入导航来掩盖里程计问题。改变传感模型、步态、坐标系或地图编码时，说明假设与对教学结论的影响。新数据与上游资产必须附来源和适用许可。

提交前运行 `python3 scripts/check_release.py --tracked`。保留 Key、用户配置与运行目录的忽略规则。为行为性修复增加有意义的回归检查，不用固定输出或模拟通过来替代实际执行证据。
