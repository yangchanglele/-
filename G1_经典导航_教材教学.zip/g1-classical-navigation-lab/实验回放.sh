#!/usr/bin/env bash
set -euo pipefail
G1_LAB_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ ! -f /opt/ros/humble/setup.bash ]]; then echo '请先安装 ROS 2 Humble'; exit 2; fi
unset PYTHONHOME PYTHONPATH
set +u
source /opt/ros/humble/setup.bash
set -u
exec /usr/bin/python3 "$G1_LAB_ROOT/scripts/replay_slam.py" "$@"
